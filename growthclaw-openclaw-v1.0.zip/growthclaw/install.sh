#!/usr/bin/env bash
# ============================================================================
# install.sh - GrowthClaw Installer for OpenClaw
# ============================================================================
# Installs the GrowthClaw marketing skills pack into your OpenClaw instance.
#
# Usage:
#   ./install.sh                    Install to ~/.openclaw/skills/growthclaw/
#   ./install.sh --claude-only      Skip the creative skill (no Replicate needed)
#   ./install.sh --target PATH      Install to a custom location
#
# ============================================================================
set -euo pipefail

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
INSTALL_DIR="$INSTALL_HOME/skills/growthclaw"
CLAUDE_ONLY=false
VERSION="1.0"

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --claude-only)
      CLAUDE_ONLY=true
      shift
      ;;
    --target)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --help|-h)
      echo "Usage: $0 [--claude-only] [--target PATH]"
      echo ""
      echo "Options:"
      echo "  --claude-only   Skip the creative skill (requires Replicate API)"
      echo "  --target PATH   Install to a custom directory"
      echo "  --help          Show this help message"
      exit 0
      ;;
    *)
      echo "Error: Unknown option '$1'"
      exit 1
      ;;
  esac
done

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
CYAN="\033[0;36m"
DIM="\033[2m"
RESET="\033[0m"

info()    { echo -e "  ${CYAN}[info]${RESET}  $1"; }
success() { echo -e "  ${GREEN}[done]${RESET}  $1"; }
warn()    { echo -e "  ${YELLOW}[warn]${RESET}  $1"; }

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  GrowthClaw v${VERSION} - OpenClaw Marketing Skills${RESET}"
echo -e "  ─────────────────────────────────────────────"
echo ""
info "Source:  $SCRIPT_DIR"
info "Target:  $INSTALL_DIR"
if $CLAUDE_ONLY; then
  warn "Mode:    Claude-only (creative skill excluded)"
else
  info "Mode:    Full suite"
fi
echo ""

# ---------------------------------------------------------------------------
# Validate source directory
# ---------------------------------------------------------------------------
if [[ ! -f "$SCRIPT_DIR/_vibe-system/SKILL.md" ]]; then
  echo "  Error: Cannot find GrowthClaw source at $SCRIPT_DIR"
  echo "  Run this script from inside the growthclaw/ directory."
  exit 1
fi

# ---------------------------------------------------------------------------
# Build list of skills to install
# ---------------------------------------------------------------------------
SKILLS=(
  "_vibe-system"
  "start-here"
  "brand-voice"
  "positioning-angles"
  "direct-response-copy"
  "keyword-research"
  "seo-content"
  "email-sequences"
  "lead-magnet"
  "newsletter"
  "content-atomizer"
  "stack-key-advisor"
)

if ! $CLAUDE_ONLY; then
  SKILLS+=("creative")
fi

# ---------------------------------------------------------------------------
# Create target directory structure
# ---------------------------------------------------------------------------
info "Creating directory structure..."
mkdir -p "$INSTALL_DIR/schemas"
for skill in "${SKILLS[@]}"; do
  mkdir -p "$INSTALL_DIR/$skill"
  if [[ -d "$SCRIPT_DIR/$skill/references" ]]; then
    mkdir -p "$INSTALL_DIR/$skill/references"
  fi
  if [[ -d "$SCRIPT_DIR/$skill/modes" ]]; then
    mkdir -p "$INSTALL_DIR/$skill/modes"
  fi
done
success "Directory structure ready"

# ---------------------------------------------------------------------------
# Copy files
# ---------------------------------------------------------------------------
copy_tree() {
  local src="$1"
  local dst="$2"
  if command -v rsync &>/dev/null; then
    rsync -a --exclude='.DS_Store' --exclude='.git' "$src/" "$dst/"
  else
    cp -R "$src/" "$dst/"
    find "$dst" -name '.DS_Store' -delete 2>/dev/null || true
  fi
}

# --- Skills ---
INSTALLED_COUNT=0
for skill in "${SKILLS[@]}"; do
  info "Installing: $skill"
  copy_tree "$SCRIPT_DIR/$skill" "$INSTALL_DIR/$skill"
  INSTALLED_COUNT=$((INSTALLED_COUNT + 1))
  success "$skill"
done

# --- Schemas ---
info "Installing schemas..."
copy_tree "$SCRIPT_DIR/schemas" "$INSTALL_DIR/schemas"
success "schemas/ ($(ls "$SCRIPT_DIR/schemas" 2>/dev/null | wc -l | tr -d ' ') files)"

# --- Create workspace/brand/ directory ---
WORKSPACE_BRAND="$INSTALL_HOME/workspace/brand"
if [[ ! -d "$WORKSPACE_BRAND" ]]; then
  info "Creating brand memory directory..."
  mkdir -p "$WORKSPACE_BRAND"
  success "Created $WORKSPACE_BRAND"
else
  info "Brand memory directory already exists at $WORKSPACE_BRAND"
fi

# --- Create workspace/campaigns/ directory ---
WORKSPACE_CAMPAIGNS="$INSTALL_HOME/workspace/campaigns"
if [[ ! -d "$WORKSPACE_CAMPAIGNS" ]]; then
  mkdir -p "$WORKSPACE_CAMPAIGNS"
  success "Created $WORKSPACE_CAMPAIGNS"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
TOTAL_FILES=$(find "$INSTALL_DIR" -type f | wc -l | tr -d ' ')
echo ""
echo -e "${BOLD}  Installation Complete${RESET}"
echo -e "  ─────────────────────"
echo ""
success "$INSTALLED_COUNT skills installed"
success "$TOTAL_FILES total files"
success "Location: $INSTALL_DIR"
success "Brand memory: $WORKSPACE_BRAND"
echo ""

if ! $CLAUDE_ONLY; then
  if [[ -z "${REPLICATE_API_TOKEN:-}" ]]; then
    warn "REPLICATE_API_TOKEN not set (creative skill will use prompt-only mode)"
  fi
fi

echo -e "  ${DIM}Run doctor.sh to verify:${RESET}"
echo -e "  ${DIM}  $SCRIPT_DIR/doctor.sh${RESET}"
echo ""
echo -e "  ${DIM}Then try:${RESET}"
echo -e "  ${DIM}  /start-here    Marketing dashboard${RESET}"
echo -e "  ${DIM}  /brand-voice   Define your brand voice${RESET}"
echo ""
