---
name: seo-content
description: "Create SEO-optimized content that ranks AND reads like a human wrote it. Performs live SERP analysis, integrates People Also Ask, generates schema markup, and writes publication-ready articles."
metadata:
  openclaw:
    emoji: "📝"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# SEO Content -- Publication-Ready SEO Content

SEO content has a reputation problem. Most of it is garbage -- keyword-stuffed, AI-sounding, says nothing new. It ranks for a month, then dies.

This skill creates content that ranks AND builds trust. Content that sounds like an expert sharing what they know, not a content mill churning out filler.

The goal: Would someone bookmark this? Would they share it? Would they come back?

If yes, Google will reward it. If no, no amount of optimization saves it.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

---

## Brand Memory Integration

**Reads:** `keyword-plan.md`, `positioning.md`, `audience.md`, `voice-profile.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

| File | What it provides | How it shapes output |
|------|-----------------|---------------------|
| `workspace/brand/voice-profile.md` | Tone, personality, vocabulary, rhythm | Directly shapes the writing style -- a "direct, proof-heavy" voice writes differently than a "warm, story-driven" voice |
| `workspace/brand/keyword-plan.md` | Prioritized keywords, content briefs, SERP data | Provides target keyword, cluster, intent, content type, and any pre-gathered SERP analysis |
| `workspace/brand/audience.md` | Buyer profiles, sophistication level, pain points | Informs how technical to write, what examples to use, what pain points to address |
| `workspace/brand/positioning.md` | Market angles, differentiators | Shapes the unique angle for the piece -- how your perspective differs from everyone else ranking |
| `workspace/brand/competitors.md` | Named competitors, their positioning | Identifies what angle competitors take so you can differentiate |
| `workspace/brand/learnings.md` | Past performance data | Reveals what content approaches worked before -- long-form vs short, story-driven vs data-driven |

### Writes

| File | What it contains |
|------|-----------------|
| `workspace/campaigns/content/{keyword-slug}.md` | The publication-ready article with frontmatter |
| `workspace/brand/assets.md` | Appends entry for the created content piece |
| `workspace/brand/learnings.md` | Appends findings after feedback collection |

### Context Loading Behavior

1. Check whether `workspace/brand/` exists.
2. If it exists, read `voice-profile.md`, `keyword-plan.md`, `audience.md`, `positioning.md`, `competitors.md`, and `learnings.md` if present.
3. If loaded, show the user what you found:
   ```
   Brand context loaded:
   -- Voice Profile   "{tone summary}"
   -- Keyword Plan    {N} pillars, {N} briefs
   -- Audience        "{audience summary}"
   -- Positioning     "{primary angle}"
   -- Competitors     {N} competitors profiled
   -- Learnings       {N} entries

   Using this to shape content strategy and voice.
   ```
4. If files are missing, proceed without them. Note at the end:
   ```
   --> /brand-voice would let me match your exact tone
   --> /keyword-research would provide a content brief
   --> /positioning-angles would sharpen the angle
   ```
5. If no brand directory exists at all:
   ```
   No brand profile found -- this skill works standalone.
   I'll ask what I need as we go. Run /start-here or
   /brand-voice later to unlock personalization.
   ```

---

## Iteration Detection

Before starting, check whether a content file already exists for this keyword.

### If content file EXISTS --> Content Refresh Mode

Do not start from scratch. Instead:

1. Read the existing article at `workspace/campaigns/content/{keyword-slug}.md`.
2. Present a summary of the current content:
   ```
   EXISTING CONTENT FOUND
   "{article title}"
   Published {date from frontmatter}

   Target keyword: {keyword}
   Word count: {N}
   Sections: {N}
   Last updated: {date}

   What would you like to do?

   1. Refresh -- analyze SERP changes and update
   2. Rewrite -- full rewrite with new angle
   3. Expand -- add new sections or depth
   4. Start fresh -- ignore existing, write new
   ```

3. **If Refresh (option 1):**
   - Search the target keyword to get current SERP state
   - Compare current SERP against the article
   - Present specific refresh recommendations with actionable changes
   - If confirmed, apply updates and save

4. Before overwriting, show what changed and confirm.

For detailed content refresh methodology, load `references/seo-methodology.md`.

### If content file DOES NOT EXIST --> Full Creation Mode

Proceed to the full workflow below.

---

## The Core Job

Transform a keyword target into **publication-ready content** that:
- Answers the search intent completely
- Sounds like a knowledgeable human wrote it
- Is structured for both readers and search engines
- Includes proper on-page optimization
- Passes the "would I actually read this?" test
- Includes Article + FAQ JSON-LD schema markup
- Is saved to disk with proper frontmatter

---

## Required Inputs

Before writing, gather:

1. **Target keyword** -- Primary keyword to rank for
2. **Keyword cluster** -- Related keywords to include naturally
3. **Search intent** -- Informational / Commercial / Transactional
4. **Content type** -- Pillar guide / How-to / Comparison / Listicle / etc.
5. **Brand voice profile** -- (from voice-profile.md, if available)
6. **Unique angle** -- What perspective makes this different?

If coming from /keyword-research skill, most of this is already defined in the content brief at `workspace/campaigns/content-plan/{keyword-slug}.md`.

### Pre-Fill from Brand Memory

When brand memory files exist, pre-fill inputs automatically:

```
  From your brand profile and keyword plan:

  -- Keyword      "{from keyword-plan.md or content brief}"
  -- Cluster      {N} supporting keywords loaded
  -- Intent       {from content brief}
  -- Content type {from content brief}
  -- Voice        "{tone summary from voice-profile.md}"
  -- Angle        "{from positioning.md}"
  -- Audience     "{from audience.md}"

  Does this look right? Anything to adjust
  before I start researching?
```

If no content brief exists, ask the user for the target keyword and gather the rest through conversation or inference.

---

## The Workflow

```
RESEARCH --> BRIEF --> OUTLINE --> DRAFT --> HUMANIZE --> OPTIMIZE --> SCHEMA --> REVIEW --> SAVE
```

---

## Phase 1: Research

Before writing a word, understand what you are competing against.

**This is a research-dependent skill.** Phase 1 requires live web search to perform SERP analysis, capture People Also Ask questions, and identify competitor gaps.

- **If web search tools are available:** Show `RESEARCH MODE --> Data quality: LIVE` and proceed with full SERP analysis.
- **If web search tools are NOT available:** Show `RESEARCH MODE --> Data quality: ESTIMATED`. Flag this to the user and ask whether to proceed with conceptual analysis. If proceeding, prefix all SERP-derived claims with `~` to indicate estimates, and skip to Phase 2 using brand context and user input instead of live data.

### SERP Analysis

Search the target keyword using web search tools and analyze the top 5 results. For each result, capture: title, URL, content type, word count, structure, unique angles, gaps, freshness, and domain type.

Extract from SERP features: People Also Ask questions, Featured Snippet format, AI Overview presence.

### People Also Ask Integration

Pull ALL People Also Ask questions for the target keyword via web search. These become mandatory sections in your content.

- Each PAA question becomes an H2 or FAQ entry
- Answer PAA questions directly (Featured Snippet format)
- PAA phrasing is used in headers (matches how people search)
- Questions that deserve depth become full sections
- Questions that need brief answers go in the FAQ section

### Gap Analysis

After reviewing competitors and PAA, identify:

1. **What is missing?** -- Questions unanswered, angles unexplored
2. **What is outdated?** -- Old information, deprecated methods
3. **What is generic?** -- Surface-level advice anyone could give
4. **What is your edge?** -- Unique data, experience, perspective (informed by positioning.md)

Your content should fill these gaps.

For detailed SERP analysis templates, PAA capture methodology, and output formats, load `references/seo-methodology.md`.

---

## Phase 2: Content Brief

Before drafting, create a brief. If a content brief already exists from /keyword-research (at `workspace/campaigns/content-plan/{keyword-slug}.md`), load it and enhance with live SERP data from Phase 1.

```
# Content Brief: [Title]

## Target Keyword
Primary: [keyword]
Secondary: [keyword], [keyword], [keyword]

## Search Intent
[Informational / Commercial / Transactional]

## Content Type
[Pillar Guide / How-To / Comparison / Listicle / etc.]

## Target Word Count
[Based on competitor analysis]

## Audience
Who is searching this? What do they need?
[Enhanced by audience.md if loaded]

## Unique Angle
What makes our take different?
[Informed by positioning.md if loaded]

## Key Points to Cover
- [Point 1]
- [Point 2]
- [Point 3]

## Questions to Answer (from PAA)
- [Question 1]
- [Question 2]
- [Question 3]

## Competitor Gaps to Fill
- [Gap 1]
- [Gap 2]

## Internal Links
- Link to: [related content on site]
- Link from: [existing content that should link here]

## CTA
What action should readers take?
```

---

## Phase 3: Outline

Structure the content based on content type. Each type has a specific structure template optimized for that format.

For detailed structure templates (Pillar Guide, How-To Tutorial, Comparison, Listicle), load `references/seo-methodology.md`.

**Key structural principles across all types:**

- Answer the title question in the first 150-300 words
- Include a Quick Answer / TL;DR section for skimmers
- Map PAA questions to H2 headers
- Include an FAQ section with schema-ready format (5-10 questions)
- End with a clear CTA

---

## Phase 4: Draft

Write the first draft following these principles:

### Voice Calibration from Brand Memory

If voice-profile.md is loaded, calibrate the writing to match:

- **Tone:** Match the documented tone (direct, warm, technical, casual, etc.)
- **Personality:** Write as the persona described in the profile
- **Pacing:** Follow the documented rhythm patterns
- **Vocabulary:** Use the "words to use" list, avoid the "words to avoid" list
- **Examples:** Match the on-brand example style

If voice-profile.md is NOT loaded, default to: direct, conversational, specific, opinionated. The kind of writing a smart friend who happens to be an expert would produce.

### The First Paragraph Rule

Answer the search query in the first 2-3 sentences. Do not make them scroll.

**Bad:** "In today's rapidly evolving digital landscape, marketers are increasingly turning to artificial intelligence..."

**Good:** "AI marketing tools can automate 60-80% of repetitive marketing tasks. Here are the 10 that actually work, based on testing them across 50+ client accounts."

### The "So What?" Chain

For every point you make, ask "so what?" until you hit something the reader actually cares about. Write from the bottom of the chain, not the top.

### Specificity Over Generality

**Weak:** "This tool saves time."
**Strong:** "This tool cut our email outreach from 4 hours to 15 minutes per day."

Numbers, examples, specifics. Always.

### Positioning-Informed Angle

If positioning.md is loaded, use the brand's positioning to shape the angle:

- **"The Anti-Agency"** angle: Write from the perspective of someone who has seen the agency model fail
- **"Practitioner, Not Theorist"** angle: Lead with real implementation stories
- **"Data-First"** angle: Lead every section with numbers and evidence

The positioning does not change WHAT you write about (the keyword dictates that). It changes HOW you write about it.

---

## Phase 5: Humanize

AI-generated content has tells. Remove them ruthlessly.

The goal is not "sounds okay." It is "sounds like a specific person wrote this based on real experience."

**Key humanization steps:**

1. **Kill AI words** -- delve, comprehensive, crucial, leverage, landscape, streamline, robust, utilize, facilitate, unlock, unleash, supercharge, game-changer, tapestry, myriad, nuanced, seamless
2. **Kill AI phrases** -- "In today's fast-paced world", "It's important to note", "Let's dive in", "Whether you're a... or a...", "Without further ado", "This comprehensive guide"
3. **Break structural patterns** -- Not everything in threes. Vary bullet point lengths. Commit to positions instead of hedging.
4. **Inject voice** -- Personal experience with specifics, opinions with reasoning, admission of limitations, uncertainty where honest, tangents and asides
5. **Vary rhythm** -- Short punch. Then longer sentences. Fragments for emphasis. Parenthetical asides. Questions left hanging.
6. **Run the detection checklist** -- Before publishing, verify no AI tells remain

For the complete AI detection pattern guide, before/after examples, voice injection techniques, and the full detection checklist, load `references/seo-methodology.md`.

For 20 best-in-class examples of human-written content across verticals (Paul Graham, Wait But Why, Stratechery, Matt Levine, and more), load `references/eeat-examples.md`.

---

## Phase 6: Optimize

### On-Page SEO Essentials

- Primary keyword in title (front-loaded), H1, first 100 words, and at least one H2
- Secondary keywords distributed naturally across H2s
- Meta description under 160 characters with primary keyword and a compelling hook
- Internal links (4-8) and external citations (2-4) per piece
- Featured Snippet optimization matching the dominant snippet format

For the complete SEO checklist, title optimization formulas, meta description templates, header structure guide, and internal linking strategy, load `references/seo-methodology.md`.

---

## Phase 7: Schema Markup Generation

After the article is drafted and optimized, generate JSON-LD schema markup. This is output alongside the article content.

### Required Schema Types

**Article schema** -- Generate for every content piece. Includes headline, description, author, dates, publisher, and keywords.

**FAQ schema** -- Generate for every article with an FAQ section (which should be all of them). Each PAA question becomes a schema entry.

**HowTo schema** -- Generate for how-to tutorial content. Each step becomes a schema entry.

Schema markup is included in the article's YAML frontmatter so the user can copy it directly into their CMS.

For complete schema JSON-LD templates, load `references/seo-methodology.md`.

---

## Phase 8: Quality Review

### Content Quality Checklist

```
[ ] Answers title question in first 300 words
[ ] At least 3 specific examples or numbers
[ ] At least 1 personal experience or unique insight
[ ] Unique angle present (not just aggregation)
[ ] All claims supported by evidence or experience
[ ] No generic advice (could apply to anyone)
[ ] Would I bookmark this? Would I share it?
[ ] PAA questions answered (all of them)
[ ] SERP gaps addressed (from Phase 1 analysis)
```

### Voice Quality Checklist

```
[ ] Reads naturally out loud
[ ] No AI-isms (delve, landscape, comprehensive)
[ ] No corporate speak (leverage, synergy)
[ ] Sentence length varies
[ ] Personality present
[ ] Would I actually say this to someone?
[ ] Matches voice-profile.md (if loaded)
[ ] Positioning angle visible (if loaded)
```

### SEO Quality Checklist

```
[ ] Primary keyword in title, H1, first paragraph
[ ] Secondary keywords in H2s naturally
[ ] Meta description compelling and <160 chars
[ ] Internal links included (4-8)
[ ] External citations for claims (2-4)
[ ] Headers create logical structure
[ ] FAQ section with schema-ready format
[ ] Schema markup generated (Article + FAQ)
```

### E-E-A-T Signals Checklist

```
[ ] Experience shown (real examples, specific results)
[ ] Expertise demonstrated (depth, accuracy, nuance)
[ ] Author credentials visible
[ ] Sources cited for factual claims
[ ] Updated date visible
[ ] No misleading claims
```

---

## File Output Format

All content is saved to disk as a markdown file with YAML frontmatter.

### File Location

```
workspace/campaigns/content/{keyword-slug}.md
```

**Slug rules:** Lowercase kebab-case. Remove stop words if slug exceeds 60 characters.

### Directory Creation

If `workspace/campaigns/content/` does not exist, create it before saving.

For the complete frontmatter format and article body template, load `references/seo-methodology.md`.

---

## Chain to /content-atomizer

After content creation, offer to atomize the article into social distribution assets:

```
  DISTRIBUTE THIS CONTENT

  Your article is {N} words of original content.
  That is enough raw material for:

  -- 3-5 LinkedIn posts
  -- 8-12 Twitter/X posts
  -- 2-3 Instagram carousel concepts
  -- 1 email newsletter excerpt
  -- 1 thread (Twitter or LinkedIn)

  --> "Atomize" to run /content-atomizer now
  --> "Not yet" to save the article and stop here
```

If the user says "atomize" or similar, hand off to /content-atomizer with:
- The article file path
- The article title and primary keyword
- Brand voice context (already loaded)
- Key takeaways and quotable passages from the article

---

## How This Connects to Other Skills

**Input from:**
- **keyword-research** --> Provides target keyword, cluster, intent, content type, and content briefs
- **positioning-angles** --> Provides unique angle for differentiation
- **brand-voice** --> Provides voice profile for consistent tone
- **direct-response-copy** --> For CTAs and conversion elements within content

**Chains to:**
- **content-atomizer** --> Turns the article into social posts, email excerpts, threads

**The flow:**
1. /keyword-research identifies the opportunity and creates content briefs
2. /positioning-angles finds the unique angle
3. /brand-voice defines how it should sound
4. **/seo-content creates the actual piece** (you are here)
5. /content-atomizer distributes it across channels

---

## Complete Invocation Flow

```
  /seo-content invoked
  |
  +-- Check workspace/brand/ directory
  |   +-- Load voice-profile.md (if exists)
  |   +-- Load keyword-plan.md (if exists)
  |   +-- Load audience.md (if exists)
  |   +-- Load positioning.md (if exists)
  |   +-- Load competitors.md (if exists)
  |   +-- Load learnings.md (if exists)
  |
  +-- Check for existing content file
  |   +-- EXISTS --> Content Refresh Mode
  |   |   +-- Read existing article
  |   |   +-- Present summary + options
  |   |   +-- If Refresh: re-run SERP, compare, recommend
  |   |   +-- If Rewrite: full process with new angle
  |   |   +-- If Expand: add sections, keep existing
  |   |   +-- If Fresh: ignore existing, full process
  |   |   +-- Show diff, confirm overwrite
  |   |   +-- Save updated article
  |   |
  |   +-- DOES NOT EXIST --> Full Creation Mode
  |       +-- Gather inputs (pre-fill from brand memory)
  |       +-- Phase 1: Research (SERP analysis, PAA, gap analysis)
  |       +-- Phase 2: Content Brief (load or create)
  |       +-- Phase 3: Outline (structure based on content type)
  |       +-- Phase 4: Draft (voice from brand memory, angle from positioning)
  |       +-- Phase 5: Humanize (AI detection removal, voice injection)
  |       +-- Phase 6: Optimize (on-page SEO, title, meta, links)
  |       +-- Phase 7: Schema Markup (Article + FAQ + HowTo if applicable)
  |       +-- Phase 8: Quality Review (content, voice, SEO, E-E-A-T)
  |
  +-- Save outputs
  |   +-- workspace/campaigns/content/{keyword-slug}.md
  |   +-- workspace/brand/assets.md (append entry)
  |
  +-- Present formatted output
  +-- Chain offer: Atomize into social with /content-atomizer?
  +-- Feedback Collection
```

---

## Error States

### Web search not available

```
  SERP ANALYSIS UNAVAILABLE

  Web search tools are not available in this
  environment. I can still write the article
  using brand context and content brief --
  but without live SERP analysis, PAA data,
  or competitor gap validation.

  --> Continue without SERP data
  --> Provide competitor URLs manually
```

When web search is unavailable, skip SERP analysis in Phase 1. Proceed with the brief-based approach (Phase 2 onward). Note in the output that SERP validation was not performed and recommend the user manually check top results for the target keyword.

### No target keyword provided

```
  NEED A TARGET KEYWORD

  I need a keyword to write for. Options:

  --> Tell me the keyword to target
  --> /keyword-research to find the right one
  --> Point me to a content brief
```

### Voice profile not found

```
  BRAND VOICE NOT FOUND

  I can write this article, but without your
  voice profile I will use a default style:
  direct, conversational, specific.

  --> /brand-voice  Build your profile (~10 min)
  --> Continue with defaults
```

### Content directory not writable

```
  CANNOT SAVE CONTENT

  Could not write to workspace/campaigns/content/.
  The article is generated and displayed above --
  you can copy it manually.

  --> Check directory permissions
  --> Save to a different location
```

---

## Implementation Notes for the LLM

When executing this skill, follow these rules precisely:

1. **Never skip SERP analysis when web search is available.** The differentiator is live SERP research. Phase 1 is not optional. Search the target keyword, capture PAA questions, analyze competitors.

2. **Always check for existing content first.** The iteration detection enables content refresh mode, which is one of the most valuable features. Never start from scratch when an article already exists.

3. **Always generate schema markup.** Article + FAQ JSON-LD is mandatory for every piece of content. HowTo schema is mandatory for how-to tutorials. Schema markup is included in the frontmatter of the saved file.

4. **Always save to disk.** Content is saved to `workspace/campaigns/content/{keyword-slug}.md` with proper YAML frontmatter. Create the directory if it does not exist. The saved file IS the deliverable -- not the terminal output.

5. **Use brand memory visibly.** When voice-profile.md is loaded, mention how it shaped the writing style. When positioning.md is loaded, mention the angle used. The user should see their brand context working.

6. **PAA questions are mandatory sections.** Every People Also Ask question captured in Phase 1 MUST appear in the content -- either as an H2 section or in the FAQ section. This is non-negotiable.

7. **Preserve the humanization process.** Phase 5 is the soul of this skill. Never skip it. Run every draft through the AI detection checklist, inject voice points, vary rhythm. The content should sound like a human expert, not a language model.

8. **Always offer the /content-atomizer chain.** After creating an article, the natural next step is social distribution. Always present the chain prompt.

9. **Write the content brief if one does not exist.** If the user provides a keyword but no content brief exists from /keyword-research, create one as part of Phase 2.

10. **Respect the file output format exactly.** The frontmatter schema is specific. The slug format is specific. The directory location is specific. Get these right so other skills can find and parse the content files.

11. **When web search is unavailable, gracefully degrade.** Fall back to the brief-based approach without SERP analysis. Note the limitation. The skill should still produce valuable content -- it just will not have live competitive data or PAA integration.

12. **Content refresh is about specifics, not generalities.** When refreshing an article, do not say "update the content." Say "add a section on {specific topic} after the {specific section} because {specific SERP evidence}."

13. **Feedback closes the loop.** Always present the feedback prompt after saving. Always log feedback to learnings.md.

14. **Register every content piece.** After saving the article, append an entry to `workspace/brand/assets.md` with the file path, type, date, and status.

---

## The Test

Before publishing, ask:

1. **Does it answer the query better than what is ranking?**
2. **Would an expert in this field approve of the accuracy?**
3. **Would a reader bookmark or share this?**
4. **Does it sound like a person, not a content mill?**
5. **Is there at least one thing here they cannot find elsewhere?**
6. **Does it pass the AI detection checklist?** (Phase 5)
7. **Does it match the quality bar of the E-E-A-T examples?**
8. **Does it answer ALL People Also Ask questions?**
9. **Is the schema markup valid and complete?**
10. **Is it saved to disk with proper frontmatter?**

If any answer is no, revise before publishing.

---

## Feedback Collection

After the article is saved and presented, offer the standard feedback prompt:

```
  How did this land?

  a) Great -- ready to publish as-is
  b) Good -- made minor edits
  c) Rewrote significantly
  d) Have not published yet

  (You can answer later -- just run
  /seo-content again and tell me.)
```

### Processing Feedback

**If (a) "Great":**
- Log to `workspace/brand/learnings.md` under "What Works"

**If (b) "Good -- minor edits":**
- Ask: "What did you change? Even small details help me improve."
- Log the change to learnings.md. If it reveals a voice/tone issue, suggest updating voice-profile.md.

**If (c) "Rewrote significantly":**
- Ask: "Can you share what you changed or paste the final version? I will learn from the diff."
- If the rewrite reveals a pattern, suggest re-running /brand-voice.

**If (d) "Have not published yet":**
- Note it. Do not log yet.
- Optionally remind them next time: "Last time I wrote an article on '{keyword}'. Did you ever publish it?"
