# SEO Content Methodology Reference

Detailed SERP analysis examples, content structure templates, humanization techniques, and schema markup templates for the seo-content skill. The main SKILL.md contains the core workflow -- this file provides depth.

---

## SERP Analysis Detail (Phase 1)

### What to Capture Per Result

For each of the top 5 results, document:
- Title and URL
- Content type (guide, listicle, tool page, etc.)
- Approximate word count
- Structure (headers, sections)
- Unique angles or data
- What they do well
- What they miss or get wrong
- How recent (publish/update date)
- Domain type (major publication, niche site, personal blog)

### SERP Features to Extract

- People Also Ask questions (answer ALL of these)
- Featured Snippet format (match it to win it)
- AI Overview presence (what it includes/excludes)

### SERP Analysis Output Template

```
  SERP ANALYSIS: "{target keyword}"

  Top 5 results:
  -- 1. {Title} -- {domain}
        {content type}, ~{N} words, {date}
        Angle: {their angle}
        Gap: {what they miss}

  -- 2. {Title} -- {domain}
        {content type}, ~{N} words, {date}
        Angle: {their angle}
        Gap: {what they miss}

  -- 3. {Title} -- {domain}
        {content type}, ~{N} words, {date}
        Angle: {their angle}
        Gap: {what they miss}

  -- 4. {Title} -- {domain}
        {content type}, ~{N} words, {date}
        Angle: {their angle}
        Gap: {what they miss}

  -- 5. {Title} -- {domain}
        {content type}, ~{N} words, {date}
        Angle: {their angle}
        Gap: {what they miss}

  SERP FEATURES

  -- Featured Snippet    {format or "none"}
  -- People Also Ask     {N} questions captured
  -- AI Overview         {present/absent, summary}

  OPPORTUNITY ASSESSMENT

  {1-3 sentence summary of the gap your content
  will fill and why it can win}
```

---

## People Also Ask Integration Detail

### How to Capture PAA

1. Search the target keyword
2. Record every PAA question shown
3. Click/expand each PAA to get second-level questions
4. Record those too
5. Search 2-3 keyword variations to find additional PAA questions

### How PAA Shapes the Content

- Each PAA question becomes an H2 or FAQ entry
- Answer PAA questions directly (Featured Snippet format)
- PAA phrasing is used in headers (matches how people search)
- Questions that deserve depth become full sections
- Questions that need brief answers go in the FAQ section

### PAA Output Template

```
  PEOPLE ALSO ASK

  Full sections (answer as H2):
  -- "{question 1}" -- high search signal
  -- "{question 2}" -- aligns with content type
  -- "{question 3}" -- competitive gap

  FAQ entries (answer briefly):
  -- "{question 4}"
  -- "{question 5}"
  -- "{question 6}"
  -- "{question 7}"
```

---

## Content Structure Templates (Phase 3)

### Pillar Guide Structure (5,000-8,000 words)

```
1. Hook Intro (150-250 words)
   - Answer the title question immediately
   - Why this matters NOW
   - Who this is for (and who it's not for)

2. Quick Answer Section (200-300 words)
   - Direct answer for Featured Snippet
   - TL;DR for skimmers

3. Core Sections (3-5 major sections)
   - Each 800-1,500 words
   - Each answers a major sub-question
   - H2 headers with keyword variations
   - PAA questions as H2s where appropriate

4. Implementation / How to Apply (300-500 words)
   - Specific actionable steps
   - Decision framework if applicable

5. FAQ Section (5-10 questions)
   - From PAA research
   - Schema-ready format (used for JSON-LD)

6. Conclusion with CTA (150-200 words)
   - Summarize key takeaway
   - Clear next action
```

### How-To Tutorial Structure (2,000-3,000 words)

```
1. What You'll Achieve (150-200 words)
   - End result shown first
   - Time estimate
   - Prerequisites

2. Why This Method (200-300 words)
   - Context and alternatives
   - Why this approach works

3. Step-by-Step Instructions (1,200-2,000 words)
   - Numbered steps
   - One action per step
   - Troubleshooting inline

4. Variations / Advanced Tips (300-400 words)

5. Common Mistakes (200-300 words)

6. FAQ (3-5 questions from PAA)

7. Next Steps with CTA (100-150 words)
```

### Comparison Structure (2,500-4,000 words)

```
1. Quick Verdict (200-300 words)
   - Bottom line recommendation
   - "Choose X if... Choose Y if..."

2. Comparison Table
   - 8-12 key differentiators
   - Pricing, best for, key features

3. Deep Dive: Option A (800-1,000 words)
   - What it is
   - Key features
   - Pros/cons
   - Best for
   - Real example

4. Deep Dive: Option B (800-1,000 words)
   - Same structure

5. Head-to-Head Comparison (300-500 words)
   - Specific scenarios
   - When to pick each

6. FAQ (3-5 questions from PAA)

7. Final Recommendation with CTA
```

### Listicle Structure (2,000-3,000 words)

```
1. Intro with Context (150-200 words)
   - Why this list matters
   - How items were selected

2. Quick Summary Table/List
   - All items at a glance
   - For skimmers

3. Individual Items (150-300 words each)
   - What it is
   - Why it's included
   - Best for / Use case
   - Limitations (honesty builds trust)

4. How to Choose (200-300 words)
   - Decision framework

5. FAQ (3-5 questions from PAA)

6. Conclusion with CTA
```

---

## Humanization Detail (Phase 5)

### The AI Detection Patterns

AI content fails in predictable ways. Learn to spot them:

**1. Word-Level Tells**

Kill these immediately:
- delve, dive into, dig into
- comprehensive, robust, cutting-edge
- utilize (just say "use")
- leverage (as a verb)
- crucial, vital, essential
- unlock, unleash, supercharge
- game-changer, revolutionary
- landscape, navigate, streamline
- tapestry, multifaceted, myriad
- foster, facilitate, enhance
- realm, paradigm, synergy
- embark, journey (for processes)
- plethora, myriad, bevy
- nuanced, intricate, seamless

**2. Phrase-Level Tells**

These scream "AI wrote this":
- "In today's fast-paced world..."
- "In today's digital age..."
- "It's important to note that..."
- "When it comes to..."
- "In order to..." (just say "to")
- "Whether you're a... or a..."
- "Let's dive in" / "Let's explore"
- "Without further ado"
- "At the end of the day"
- "It goes without saying"
- "In conclusion" (especially at the end)
- "This comprehensive guide will..."
- "Are you looking for..." (fake questions)
- "Look no further"

**3. Structure-Level Tells**

AI has recognizable structural patterns:

- **The Triple Pattern**: Everything in threes. Three benefits. Three examples. Three subpoints. Humans are messier.
- **Perfect Parallelism**: Every bullet point same length, same structure. Too clean.
- **The Hedge Stack**: "While X, it's important to consider Y, but also Z." Never commits.
- **Fake Objectivity**: "Some experts say... others believe..." without taking a position.
- **Summary Sandwich**: Intro summarizes, body covers, conclusion summarizes again. Boring.
- **Empty Transitions**: "Now that we've covered X, let's move on to Y." Adds nothing.

**4. Voice-Level Tells**

The hardest to fix:

- **No Opinions**: Everything balanced, nothing claimed. Real experts have takes.
- **No Mistakes Mentioned**: Never wrong about anything, ever. Suspicious.
- **Generic Examples**: "For example, a business might..." instead of a real story.
- **Distance from Subject**: Writing about, not from experience of.
- **Uniform Certainty**: Every statement equally confident. Humans hedge where uncertain, commit where sure.

### Before/After Examples

**AI Version:**
> "Email marketing remains a crucial component of any comprehensive digital marketing strategy. When it comes to improving open rates, it's important to consider several key factors."

**Human Version:**
> "I ignored email for two years. Social media was sexier. Then I looked at the numbers: email drove 3x the revenue of all social combined. Here's what actually moves open rates--the stuff that worked when we tested it across 12 client accounts."

---

**AI Version:**
> "In today's fast-paced business landscape, professionals are increasingly turning to automation tools to streamline their workflows and enhance productivity."

**Human Version:**
> "Most automation tools are shelfware. You buy them, set them up, use them twice, forget they exist. Here are the three that actually stuck after a year of testing--and the 14 I wasted money on."

---

**AI Version:**
> "Whether you're a seasoned marketer or just starting your journey, understanding SEO fundamentals is crucial for success."

**Human Version:**
> "SEO advice is 90% outdated garbage. The tactics that worked in 2019 will get you penalized now. I'm going to show you what's actually ranking right now--pulled from 300+ sites we analyzed last month."

### Voice Injection Points

Human content has these. AI content does not. Add them:

**Personal experience with specifics:**
> "I made this mistake for two years. Cost me roughly $40K in lost revenue before someone on Twitter pointed out what I was doing wrong."

**Opinion with reasoning:**
> "Honestly, most SEO advice is written by people who've never ranked anything. They're regurgitating what they read somewhere else."

**Admission of limitations:**
> "This won't work for everyone. If you're in YMYL niches, ignore this entirely--different rules apply."

**Specific examples from real work:**
> "When we implemented this for an e-commerce brand selling outdoor gear, their organic traffic went from 12K to 89K monthly in four months."

**Uncertainty where honest:**
> "I'm not 100% sure why this works. Best guess: the semantic density signals topical authority. But I've seen it work across 40+ sites, so I stopped questioning it."

**Tangents and asides:**
> "This is the part where most guides tell you to 'create quality content.' (Useless advice.) What does that actually mean?"

### Rhythm Variation

AI writes in monotonous rhythm--similar sentence lengths, parallel structures, predictable patterns. Fix it:

- Vary sentence length. Short punch. Then longer explanatory sentences that build out the context.
- Use fragments. For emphasis. Or drama.
- Start sentences with "And" or "But" when natural.
- Include parenthetical asides (the kind of thing you would say out loud).
- Ask questions. Then answer them. Or do not.
- One-word paragraphs.

Really.

### The Detection Checklist

Before publishing, run through:

```
[ ] No AI words (delve, comprehensive, crucial, leverage, landscape)
[ ] No AI phrases (in today's world, it's important to note, let's dive in)
[ ] Not everything in threes
[ ] At least one personal opinion stated directly
[ ] At least one specific number from real experience
[ ] At least one admission of limitation or uncertainty
[ ] Sentence lengths vary (some under 5 words, some over 20)
[ ] Would I say this out loud to a smart friend?
[ ] Does it sound like a specific person, or a committee?
[ ] Can I identify whose voice this is?
```

---

## On-Page SEO Detail (Phase 6)

### Full SEO Checklist

```
[ ] Primary keyword in title (front-loaded if possible)
[ ] Primary keyword in H1 (can match title)
[ ] Primary keyword in first 100 words
[ ] Primary keyword in at least one H2
[ ] Secondary keywords in H2s naturally
[ ] Primary keyword in meta description
[ ] Primary keyword in URL slug
[ ] Image alt text includes relevant keywords
[ ] Internal links to related content (4-8 per piece)
[ ] External links to authoritative sources (2-4 per piece)
```

### Title Optimization

**Format:** [Primary Keyword]: [Benefit or Hook] ([Year] if relevant)

**Examples:**
- "AI Marketing Tools: 10 That Actually Work (2025)"
- "What is Agentic AI Marketing? The Complete Guide"
- "n8n vs Zapier: Which Automation Tool is Right for You?"

**Title rules:**
- Under 60 characters (or it gets cut off)
- Front-load the keyword
- Include a hook or differentiator
- Match search intent

### Meta Description

**Format:** [Direct answer to query]. [Proof/credibility]. [CTA or hook].

**Example:**
> "AI marketing tools can automate 60-80% of repetitive tasks. We tested 23 tools over 6 months to find the 10 that actually deliver. See the results."

**Meta rules:**
- 150-160 characters
- Include primary keyword
- Compelling enough to click
- Match what the content delivers

### Header Structure

```
H1: Main title (one per page)
  H2: Major section (keyword variation)
    H3: Subsection
    H3: Subsection
  H2: Major section (keyword variation)
    H3: Subsection
  H2: FAQ (if included)
    H3: Question 1
    H3: Question 2
```

### Featured Snippet Optimization

**For definition snippets:**
- Put definition in first paragraph
- Format: "[Keyword] is [definition in 40-50 words]"

**For list snippets:**
- Use H2 for the question
- Immediately follow with numbered or bulleted list
- Keep list items concise (one line each)

**For table snippets:**
- Use actual HTML tables
- Include clear headers
- Keep data concise

### Internal Linking Strategy

**Link TO this content from:**
- Related pillar content
- Blog posts on similar topics
- Resource pages

**Link FROM this content to:**
- Deeper dives on subtopics mentioned
- Related tools or resources
- Conversion pages (where appropriate)

**Anchor text:**
- Use descriptive text, not "click here"
- Vary anchor text naturally
- Include keywords where natural

---

## Schema Markup Templates (Phase 7)

### Article Schema

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "{SEO-optimized title}",
  "description": "{meta description}",
  "author": {
    "@type": "Person",
    "name": "{author name from brand context or user input}"
  },
  "datePublished": "{YYYY-MM-DD}",
  "dateModified": "{YYYY-MM-DD}",
  "publisher": {
    "@type": "Organization",
    "name": "{brand name from brand context or user input}"
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "{URL placeholder -- user fills in}"
  },
  "keywords": ["{primary keyword}", "{secondary 1}", "{secondary 2}"]
}
```

### FAQ Schema

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "{FAQ question 1 from PAA}",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "{Answer text}"
      }
    },
    {
      "@type": "Question",
      "name": "{FAQ question 2 from PAA}",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "{Answer text}"
      }
    }
  ]
}
```

### HowTo Schema (for how-to content)

```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "{title}",
  "description": "{meta description}",
  "step": [
    {
      "@type": "HowToStep",
      "name": "{Step 1 title}",
      "text": "{Step 1 description}"
    },
    {
      "@type": "HowToStep",
      "name": "{Step 2 title}",
      "text": "{Step 2 description}"
    }
  ]
}
```

### Schema Output Location

Schema markup is included in the article's frontmatter as a code block so the user can copy it directly into their CMS:

```markdown
---
schema_article: |
  {Article JSON-LD}
schema_faq: |
  {FAQ JSON-LD}
---
```

---

## Content Refresh Mode Detail

Content refresh mode is triggered when:
1. The user points to an existing article (`workspace/campaigns/content/{slug}.md`)
2. The user says "refresh" or "update" referring to a published article
3. The iteration detection finds an existing file for the target keyword

### The Refresh Process

1. **Read the existing article** -- Load the frontmatter and content.

2. **Re-run SERP analysis** -- Search the target keyword again with web search.

3. **Compare SERP state** -- Identify what changed since the article was published (using `serp_snapshot_date` from frontmatter):

   **New signals to check:**
   - New competitors in top 5 that were not there before
   - New PAA questions not covered in the article
   - Featured Snippet format changes
   - New content angles appearing in results
   - Search intent shifts (informational --> commercial, etc.)
   - New related topics Google associates with this keyword
   - AI Overview changes (new information included/excluded)

4. **Generate update recommendations** -- Specific, actionable changes:

   ```
   CONTENT REFRESH ANALYSIS

   Article: "{title}"
   Published: {date}
   Days since: {N}

   SERP changes detected:

   New competitors (not in original SERP):
   -- {new URL 1} -- {what they cover that you do not}
   -- {new URL 2} -- {what they cover that you do not}

   New PAA questions:
   -- "{new question 1}" -- not in your FAQ
   -- "{new question 2}" -- not in your FAQ

   Content gaps opened:
   -- {topic/section competitors now cover}
   -- {outdated stat or claim in your article}
   -- {new angle that is gaining traction}

   Recommended updates:
   -- 1. Add section: "{new H2}"
         Reason: {why}
         Placement: after "{existing H2}"
   -- 2. Update section: "{existing H2}"
         Reason: {what changed}
         Specific: {what to update}
   -- 3. Add FAQ: "{new PAA question}"
         Answer: {brief answer to add}
   -- 4. Update stats: {specific claim}
         Old: {old stat}
         New: {updated stat}
   -- 5. Update schema: add {N} new FAQ entries

   Apply these updates? (y/n)
   ```

5. **Apply and save** -- If confirmed, make the changes, update the `last_updated` and `serp_snapshot_date` in frontmatter, and save.

---

## File Output Format Detail

### File Location

```
workspace/campaigns/content/{keyword-slug}.md
```

**Slug rules:**
- Lowercase kebab-case
- "What is AI marketing" --> `what-is-ai-marketing.md`
- "Best marketing automation tools 2026" --> `best-marketing-automation-tools-2026.md`
- Remove stop words from slug if over 60 characters

### Frontmatter Format

```yaml
---
title: "{SEO-Optimized Title}"
meta_description: "{150-160 character meta description}"
primary_keyword: "{target keyword}"
secondary_keywords:
  - "{keyword 1}"
  - "{keyword 2}"
  - "{keyword 3}"
content_type: "{pillar-guide / how-to / comparison / listicle / etc.}"
search_intent: "{informational / commercial / transactional}"
target_word_count: {number}
actual_word_count: {number}
author: "{author name}"
date_created: "{YYYY-MM-DD}"
last_updated: "{YYYY-MM-DD}"
status: "draft"
serp_snapshot_date: "{YYYY-MM-DD}"
paa_questions_answered: {number}
schema_article: |
  {Article JSON-LD here}
schema_faq: |
  {FAQ JSON-LD here}
---
```

### Article Body

After the frontmatter, the full article content in markdown:

```markdown
# {SEO-Optimized Title}

{Full article content with proper H2/H3 structure}

---

## Frequently Asked Questions

### {PAA Question 1}
{Answer}

### {PAA Question 2}
{Answer}

### {PAA Question 3}
{Answer}

---

**Internal links included:**
- {Link 1 to related content}
- {Link 2 to related content}
```

### Directory Creation

If `workspace/campaigns/content/` does not exist, create it before saving.

---

## Full Terminal Output Template

```
  SEO CONTENT ARTICLE
  Generated {Mon DD, YYYY}

  {If brand context was loaded:}
  Brand context:
  -- Voice          "{tone summary}"
  -- Positioning    "{angle used}"
  -- Audience       "{audience summary}"
  -- Keyword Plan   content brief loaded

  SERP ANALYSIS

  Target: "{primary keyword}"
  Top results analyzed: {N}
  PAA questions captured: {N}
  Featured snippet: {format or "none"}

  Opportunity: {1-sentence assessment}

  ARTICLE SUMMARY

  Title: {title}
  Word count: {N}
  Sections: {N}
  FAQ questions: {N}
  Internal links: {N}
  External citations: {N}

  SCHEMA MARKUP

  -- Article schema    generated
  -- FAQ schema        {N} questions
  -- HowTo schema     {generated / not applicable}

  QUALITY CHECKS

  -- Content quality   {N}/{N} checks passed
  -- Voice quality     {N}/{N} checks passed
  -- SEO quality       {N}/{N} checks passed
  -- E-E-A-T signals   {N}/{N} checks passed

  FILES SAVED

  workspace/campaigns/content/{slug}.md         (new)
  workspace/brand/assets.md                     (1 entry added)

  WHAT'S NEXT

  Your article is ready for review and publishing.

  --> /creative           Build featured image,
                          social cards, or visual
                          assets (~15 min)
  --> /content-atomizer   Distribute across social --
                          LinkedIn, Twitter, Instagram,
                          TikTok, and more (~10 min)
  --> /newsletter         Feature this article in your
                          next newsletter edition (~15 min)
  --> /email-sequences    Nurture readers who find this
                          into subscribers (~15 min)
  --> /seo-content        Write the next article from
                          your keyword plan (~20 min)
  --> "Refresh" to update this article later

  Or tell me what you are working on and
  I will route you.
```

---

## Complete Example: "What is Agentic AI Marketing"

### Input from /keyword-research:

```
Target: "what is agentic AI marketing"
Cluster: agentic AI, AI marketing agents, autonomous marketing
Intent: Informational
Content type: Pillar guide
Priority: Critical (category definition opportunity)
Content brief: workspace/campaigns/content-plan/what-is-agentic-ai-marketing.md
```

### Brand memory loaded:

```
  Brand context loaded:
  -- Voice Profile   "Direct, proof-heavy, zero jargon"
  -- Keyword Plan    5 pillars, 12 briefs
  -- Audience        "Funded startups, 10-50 employees"
  -- Positioning     "Practitioner, not theorist"
  -- Competitors     3 competitors profiled
```

### SERP analysis findings:

- TechCrunch: General AI explainer, ~800 words, no marketing depth
- Forbes: Enterprise use cases, ~1,200 words, no how-to
- HubSpot: Product page, ~600 words, biased
- Reddit: Practitioner questions, no structured answer
- Neil Patel: General automation, ~2,000 words, not agentic-specific

**Opportunity:** Reddit in top 5 confirms major content gap. No comprehensive practitioner guide exists. Category definition opportunity is real.

### Content approach:

- 5,000+ word pillar guide
- Unique angle: Practitioner perspective with real implementations
- Include: Definition, examples, tools, how to implement, future outlook
- Answer all 8 PAA questions
- Target Featured Snippet with clear definition
- CTA to community/resources

### Schema generated:

- Article JSON-LD with full metadata
- FAQPage JSON-LD with 8 questions and answers
