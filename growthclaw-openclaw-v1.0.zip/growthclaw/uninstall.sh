#!/usr/bin/env bash
# ==========================================================================
# uninstall.sh - GrowthClaw Uninstaller for OpenClaw
# ==========================================================================
# Removes the GrowthClaw skills directory from your OpenClaw home.
# Safe by default: does NOT delete your workspace/brand or workspace/campaigns
# folders (your generated assets/memory).
#
# Usage:
#   ./uninstall.sh
#   ./uninstall.sh --purge-workspace   # also removes ~/.openclaw/workspace/brand + campaigns
#   ./uninstall.sh --target PATH       # uninstall from a custom location
# ==========================================================================
set -euo pipefail

INSTALL_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
INSTALL_DIR="$INSTALL_HOME/skills/growthclaw"
PURGE_WORKSPACE=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge-workspace)
      PURGE_WORKSPACE=true
      shift
      ;;
    --target)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --help|-h)
      echo "Usage: $0 [--purge-workspace] [--target PATH]"
      exit 0
      ;;
    *)
      echo "Error: Unknown option '$1'"
      exit 1
      ;;
  esac
done

BOLD="\033[1m"; GREEN="\033[0;32m"; YELLOW="\033[0;33m"; CYAN="\033[0;36m"; RESET="\033[0m"
info()    { echo -e "  ${CYAN}[info]${RESET}  $1"; }
success() { echo -e "  ${GREEN}[done]${RESET}  $1"; }
warn()    { echo -e "  ${YELLOW}[warn]${RESET}  $1"; }

echo ""
echo -e "${BOLD}  GrowthClaw - Uninstall${RESET}"
echo -e "  ─────────────────────"
echo ""
info "Target: $INSTALL_DIR"

if [[ ! -d "$INSTALL_DIR" ]]; then
  warn "Nothing to uninstall (directory not found)."
  exit 0
fi

rm -rf "$INSTALL_DIR"
success "Removed skills directory"

if $PURGE_WORKSPACE; then
  warn "Purging workspace brand/campaigns directories"
  rm -rf "$INSTALL_HOME/workspace/brand" || true
  rm -rf "$INSTALL_HOME/workspace/campaigns" || true
  success "Purged workspace directories"
else
  info "Kept workspace directories (brand/campaigns)"
fi

echo ""
success "Uninstall complete"
