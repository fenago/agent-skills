#!/usr/bin/env bash
# ============================================================================
# doctor.sh - GrowthClaw Installation Verifier
# ============================================================================
# Checks that all skills, references, and schemas are properly installed.
#
# Usage:
#   ./doctor.sh                                 Check default location
#   OPENCLAW_HOME=/tmp/test ./doctor.sh          Check custom location
# ============================================================================
set -euo pipefail

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
INSTALL_HOME="${OPENCLAW_HOME:-$HOME/.openclaw}"
INSTALL_DIR="$INSTALL_HOME/skills/growthclaw"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
BOLD="\033[1m"
GREEN="\033[0;32m"
RED="\033[0;31m"
YELLOW="\033[0;33m"
CYAN="\033[0;36m"
DIM="\033[2m"
RESET="\033[0m"

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

check_pass() {
  echo -e "  ${GREEN}\xe2\x9c\x93${RESET}  $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

check_fail() {
  echo -e "  ${RED}\xe2\x9c\x97${RESET}  $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
}

check_warn() {
  echo -e "  ${YELLOW}!${RESET}  $1  ${DIM}(optional)${RESET}"
  WARN_COUNT=$((WARN_COUNT + 1))
}

check_file() {
  local filepath="$1"
  local label="${2:-$1}"
  if [[ -f "$INSTALL_DIR/$filepath" ]]; then
    check_pass "$label"
  else
    check_fail "$label  ${DIM}(missing: $filepath)${RESET}"
  fi
}

check_dir() {
  local dirpath="$1"
  local label="$2"
  local min_files="${3:-1}"
  if [[ -d "$INSTALL_DIR/$dirpath" ]]; then
    local count
    count=$(find "$INSTALL_DIR/$dirpath" -type f | wc -l | tr -d ' ')
    if [[ "$count" -ge "$min_files" ]]; then
      check_pass "$label ($count files)"
    else
      check_fail "$label (found $count files, need >= $min_files)"
    fi
  else
    check_fail "$label  ${DIM}(directory missing: $dirpath)${RESET}"
  fi
}

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  GrowthClaw - Doctor${RESET}"
echo -e "  ────────────────────"
echo ""
echo -e "  ${DIM}Install location: $INSTALL_DIR${RESET}"
echo ""

# ---------------------------------------------------------------------------
# Check 1: Install directory exists
# ---------------------------------------------------------------------------
echo -e "${BOLD}  System${RESET}"
if [[ ! -d "$INSTALL_DIR" ]]; then
  check_fail "Install directory exists"
  echo ""
  echo -e "  ${RED}GrowthClaw not found at $INSTALL_DIR${RESET}"
  echo -e "  Run install.sh first."
  exit 1
fi
check_pass "Install directory exists"
check_file "_vibe-system/SKILL.md" "Vibe system (always-on)"

# ---------------------------------------------------------------------------
# Check 2: Core skills
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  Core Skills${RESET}"
CORE_SKILLS=(
  "start-here"
  "brand-voice"
  "positioning-angles"
  "direct-response-copy"
  "keyword-research"
  "seo-content"
  "email-sequences"
  "lead-magnet"
  "newsletter"
  "content-atomizer"
  "stack-key-advisor"
)

for skill in "${CORE_SKILLS[@]}"; do
  check_file "$skill/SKILL.md" "Skill: $skill"
done

# ---------------------------------------------------------------------------
# Check 3: Creative skill
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  Creative Skill${RESET}"
if [[ -d "$INSTALL_DIR/creative" ]]; then
  check_file "creative/SKILL.md" "Skill: creative"
  check_file "creative/references/MODEL_REGISTRY.md" "Model registry"
  check_file "creative/references/VISUAL_INTELLIGENCE.md" "Visual intelligence"
  check_dir  "creative/modes" "Creative modes" 5
else
  check_warn "Creative skill not installed (--claude-only mode)"
fi

# ---------------------------------------------------------------------------
# Check 4: Reference files
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  Reference Libraries${RESET}"
check_dir "positioning-angles/references" "Positioning references" 5
check_file "direct-response-copy/references/COPYWRITING_PLAYBOOK.md" "Copywriting playbook"
check_file "seo-content/references/eeat-examples.md" "SEO E-E-A-T examples"
check_dir "lead-magnet/references" "Lead magnet references" 5
check_file "newsletter/references/newsletter-examples.md" "Newsletter examples"
check_file "content-atomizer/references/platform-playbook.md" "Platform playbook"

# ---------------------------------------------------------------------------
# Check 5: Schemas
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  Schemas${RESET}"
check_file "schemas/voice-profile.schema.json" "Voice profile schema"
check_file "schemas/campaign-brief.schema.json" "Campaign brief schema"

# ---------------------------------------------------------------------------
# Check 6: Workspace directories
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  Workspace${RESET}"
if [[ -d "$INSTALL_HOME/workspace/brand" ]]; then
  check_pass "Brand memory directory"
else
  check_warn "Brand memory directory not created (run install.sh or create ~/.openclaw/workspace/brand/)"
fi

if [[ -d "$INSTALL_HOME/workspace/campaigns" ]]; then
  check_pass "Campaigns directory"
else
  check_warn "Campaigns directory not created"
fi

# ---------------------------------------------------------------------------
# Check 7: Optional API keys
# ---------------------------------------------------------------------------
echo ""
echo -e "${BOLD}  API Keys (optional)${RESET}"
if [[ -n "${REPLICATE_API_TOKEN:-}" ]]; then
  check_pass "REPLICATE_API_TOKEN set"
else
  check_warn "REPLICATE_API_TOKEN not set (creative skill uses prompt-only mode)"
fi

if [[ -n "${BRAVE_API_KEY:-}" ]]; then
  check_pass "BRAVE_API_KEY set"
else
  check_warn "BRAVE_API_KEY not set (research skills use estimated data)"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
TOTAL=$((PASS_COUNT + FAIL_COUNT))
echo ""
echo -e "  ────────────────────"
echo ""

if [[ "$FAIL_COUNT" -eq 0 ]]; then
  echo -e "  ${GREEN}${BOLD}All $PASS_COUNT checks passed.${RESET}"
  if [[ "$WARN_COUNT" -gt 0 ]]; then
    echo -e "  ${YELLOW}$WARN_COUNT optional warnings.${RESET}"
  fi
  echo ""
  exit 0
else
  echo -e "  ${RED}${BOLD}$FAIL_COUNT of $TOTAL checks failed.${RESET}"
  if [[ "$WARN_COUNT" -gt 0 ]]; then
    echo -e "  ${YELLOW}$WARN_COUNT optional warnings.${RESET}"
  fi
  echo ""
  echo -e "  Run ${CYAN}install.sh${RESET} to fix missing files."
  echo ""
  exit 1
fi
