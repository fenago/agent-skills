# Voice Frameworks Reference

Deep reference material for voice extraction, archetype analysis, and voice DNA patterns. Loaded by the brand-voice skill when deeper framework context is needed.

---

## Voice Extraction Framework (6 Dimensions)

When analyzing existing content in Extract mode, examine all six dimensions systematically.

### 1. Tone Patterns

- Formal <-> Casual (contractions? slang? sentence fragments?)
- Serious <-> Playful (humor? lightness? gravity?)
- Reserved <-> Bold (hedging? strong claims? confidence?)
- Distant <-> Intimate (we/they vs I/you? personal stories?)

### 2. Vocabulary Patterns

- Industry jargon level (heavy, light, translated?)
- Signature words or phrases they repeat
- Words they seem to avoid
- Curse words or edgy language?
- Formal words vs everyday words

### 3. Rhythm Patterns

- Average sentence length
- Paragraph length
- Mix of short punchy vs longer flowing
- Use of fragments
- List usage

### 4. Structural Patterns

- How they open (story? question? statement?)
- How they transition
- How they close (CTA style? summary? open loop?)
- Headers and formatting preferences

### 5. Personality Signals

- Self-deprecating or confident?
- Teacher or peer?
- Polished or raw?
- Optimistic or realistic?
- References and examples they use

### 6. POV Patterns

- First person (I) or plural (we)?
- How they address reader (you? folks? friends?)
- Direct address or general statements?

---

## Platform Adaptation Guide

Defines how a brand voice should flex across channels. Use this to fill the Platform Adaptations table in every voice profile.

### Email

- **Tone shift:** Warmer, more personal. This is a 1:1 conversation. The reader gave you their email address -- honor that with intimacy.
- **Structure:** Short paragraphs (1-3 sentences). One clear CTA. Personal greetings when appropriate.
- **Length:** 150-300 words for regular sends. Up to 500 for story-driven sequences.
- **Adaptations:** More contractions. More "I" and "you." Okay to start sentences with "And" or "But." Sign-offs should match personality.

### LinkedIn

- **Tone shift:** More professional, expertise-forward. Not stiff -- but the audience expects substance. Lead with insight, not personality.
- **Structure:** Single-idea posts. Line breaks between every sentence or thought (LinkedIn formatting). Hook in the first line (before "see more").
- **Length:** 100-200 words for regular posts. Up to 300 for deep posts.
- **Adaptations:** Fewer contractions than email. More "framework" language. End with a question or CTA for engagement. No hashtag spam.

### Twitter/X

- **Tone shift:** Punchiest version of the voice. More opinionated. Shorter. Hot takes welcome (if on-brand). Maximum signal, zero filler.
- **Structure:** One idea per tweet. Threads for longer stories (each tweet must stand alone). No fluffy intros.
- **Length:** Under 280 characters per tweet. Threads: 5-15 tweets.
- **Adaptations:** Fragments are fine. Single-sentence tweets. Strong opening words. Numbers and specifics always.

### Blog/SEO

- **Tone shift:** Same personality, more depth. The voice is present but not performing -- it's teaching, sharing, or arguing at length.
- **Structure:** Headers, subheads, bulleted lists. Longer paragraphs OK (3-5 sentences). Examples and proof throughout.
- **Length:** 1500-2500 words for standard posts. Up to 4000 for pillar content.
- **Adaptations:** Can use more nuance. Okay to be more thorough. Still no jargon without explanation. Maintain rhythm even at length.

### Landing Page

- **Tone shift:** Most urgent, most benefit-focused. The voice is selling, not chatting. Direct response energy with brand personality.
- **Structure:** Short sentences. Benefit-driven headlines. Social proof blocks. Clear, repeated CTAs. Above-the-fold hook must land.
- **Length:** Varies by section. Hero: 20-40 words. Feature sections: 50-100 words each. Full page: 800-2000 words.
- **Adaptations:** More power words. Stronger CTAs. Pain points more explicit. Proof points prominent. Voice stays but urgency increases.

---

## Example: Extracted Voice Profile (Marc Lou)

Input analyzed: Website copy, 10 tweets, 3 newsletter editions from a SaaS founder.

### Voice Summary

Sounds like a friend who's been in the trenches, figured some things out, and is sharing what actually worked -- not what should work in theory. Self-deprecating but confident. Casual but sharp. Makes you feel like you're getting the real story, not the polished version.

### Core Personality Traits

- **Self-deprecating confidence:** Admits failures freely but backs claims with specific results. Not arrogant, but clearly knows what works.
- **Builder energy:** Everything framed around shipping, making, creating. Impatient with theory. Values speed and action.
- **Radical transparency:** Shares real numbers ($45K/month), real failures (0 users), real timelines. Nothing hidden.
- **Accessible expertise:** Knows a lot but explains simply. Never talks down. Peer, not guru.

### Tone Spectrum

| Dimension | Position | Notes |
|-----------|----------|-------|
| Formal <-> Casual | Very casual | Contractions, fragments, emoji |
| Serious <-> Playful | Playful with serious points | Humor to disarm, but real substance |
| Reserved <-> Bold | Bold | Strong claims, specific numbers, no hedging |
| Simple <-> Sophisticated | Simple | Short words, clear sentences |
| Warm <-> Direct | Direct but warm | Friendly but doesn't waste words |

### Vocabulary

**Words/phrases to USE:**
- "Ship" -- core action verb
- "Madman" -- intensity descriptor
- Specific numbers always ($45K, 16 startups, 2 years)
- "Hey, it's [name]" -- signature opener

**Words/phrases to AVOID:**
- "Comprehensive" / "robust" / corporate speak
- "I think" / "maybe" / hedging language
- "Passionate about" / empty descriptors
- Anything that sounds like a LinkedIn post

**Jargon level:** Light -- uses "MRR" but explains concepts simply

**Profanity:** Occasional, casual (not aggressive)

### Rhythm & Structure

**Sentences:** Short. Punchy. Often fragments. Longest sentences are lists.
**Paragraphs:** 1-2 sentences. Lots of breathing room.
**Openings:** Personal intro or bold claim.
**Formatting:** Minimal headers. Emoji as punctuation. Numbers stand out.

### POV & Address

**First person:** I (never "we" unless referring to a group)
**Reader address:** You, direct
**Relationship stance:** Peer who's slightly ahead.

---

## Example: Built Voice Profile (Coach)

Inputs: New coaching business. Personality: direct, warm, no-BS. Audience: overwhelmed entrepreneurs. Positioning: experienced peer, not guru. Admires: Sahil Bloom's clarity, James Clear's simplicity. Hates: hustle culture, fake positivity.

### Voice Summary

The supportive friend who's direct enough to tell you what you need to hear, not what you want to hear. Warm but efficient. Experienced but not preachy. Makes complex things simple without dumbing them down. Anti-hustle, pro-sustainable success.

### Core Personality Traits

- **Warm directness:** Cares about you AND will tell you straight. No toxic positivity, no harsh criticism. Honest but kind.
- **Calm confidence:** Been through it, figured things out. Doesn't need to prove anything. Shares from experience, not theory.
- **Simplifier:** Takes complicated concepts and makes them actionable. Values clarity over cleverness.
- **Anti-hustle:** Success doesn't require suffering. Sustainable beats unsustainable. Rest is productive.

### Tone Spectrum

| Dimension | Position | Notes |
|-----------|----------|-------|
| Formal <-> Casual | Casual-professional | Warm, approachable, but not sloppy |
| Serious <-> Playful | Mostly serious | Occasional lightness, but grounded |
| Reserved <-> Bold | Measured bold | Clear opinions, not aggressive |
| Simple <-> Sophisticated | Simple | Everyday words, accessible |
| Warm <-> Direct | Both | Direct message, warm delivery |

### Vocabulary

**Words/phrases to USE:**
- "Here's the thing" -- transition into real talk
- "What actually works" -- contrast to theory/hype
- "Sustainable" -- key value
- "You don't have to" -- permission-giving

**Words/phrases to AVOID:**
- "Hustle" / "grind" / "crush it"
- "10x" / "scale" / growth-bro language
- "Just" (minimizing)
- "Amazing" / "incredible" / empty superlatives

**Jargon level:** Very light -- explains everything in plain language

**Profanity:** Rare, only for emphasis

### Example Phrases

**On-brand:**
- "You don't have to burn out to build something meaningful."
- "Here's the thing about productivity advice: most of it assumes you have unlimited energy. You don't."
- "I tried the hustle approach for 3 years. It worked -- until it didn't. Here's what I do instead."

**Off-brand:**
- "Ready to 10x your productivity and CRUSH your goals?!" -- Hustle culture, hype-y
- "In this comprehensive guide, you'll learn..." -- Corporate, distant
- "Just wake up at 5am!" -- Oversimplified, "just" minimizes difficulty

---

## Example: Auto-Scrape Process

When a user provides a URL, the Auto-Scrape mode gathers content automatically.

### Scrape Targets

From the provided URL, search for and pull:
- `{url}` -- Homepage content
- `{url}/about` or `{url}/about-us` -- About page
- `{url}/blog` -- Recent blog posts (grab 2-3)
- `site:{domain} linkedin.com` -- LinkedIn profile/company page
- `site:{domain} twitter.com` OR `site:{domain} x.com` -- Twitter/X presence
- `{brand name} {founder name}` -- Any podcast appearances, interviews, guest posts

### Progress Display

```
  Scraping brand presence...

  |-- Homepage copy             searching...
  |-- About page                searching...
  |-- Blog posts (recent 3)     searching...
  |-- LinkedIn bio + posts      searching...
  |-- Twitter/X bio + tweets    searching...
  |-- Any other public content  searching...
```

### Supplementary Questions

After automated extraction, ask 2-3 targeted questions to fill gaps:

1. Is there anything about your current voice you want to change or evolve?
2. Any words or phrases you love or hate that might not show up in your public content?
3. Who do you admire voice-wise? (a brand, creator, or writer)

Merge answers with extracted data and produce the final voice profile.

---

## Voice Profile JSON Schema

The structured JSON block at the bottom of every voice-profile.md must include:

```json
{
  "brand_name": "{name}",
  "last_updated": "{YYYY-MM-DD}",
  "updated_by": "/brand-voice",
  "tone": {
    "summary": "{one-sentence tone summary}",
    "spectrum": [
      {
        "dimension": "Formality",
        "left_pole": "Casual",
        "right_pole": "Formal",
        "position": "{1-10}",
        "notes": "{context}"
      },
      {
        "dimension": "Energy",
        "left_pole": "Serious",
        "right_pole": "Playful",
        "position": "{1-10}",
        "notes": "{context}"
      },
      {
        "dimension": "Confidence",
        "left_pole": "Reserved",
        "right_pole": "Bold",
        "position": "{1-10}",
        "notes": "{context}"
      },
      {
        "dimension": "Complexity",
        "left_pole": "Simple",
        "right_pole": "Sophisticated",
        "position": "{1-10}",
        "notes": "{context}"
      },
      {
        "dimension": "Warmth",
        "left_pole": "Warm",
        "right_pole": "Direct",
        "position": "{1-10}",
        "notes": "{context}"
      }
    ]
  },
  "vocabulary": {
    "preferred": [
      { "term": "{word}", "context": "{when to use}" }
    ],
    "avoid": [
      { "term": "{word}", "reason": "{why}", "alternative": "{use instead}" }
    ]
  },
  "personality_traits": ["{trait 1}", "{trait 2}", "{trait 3}", "{trait 4}"],
  "examples": {
    "on_brand": [
      { "text": "{example}", "source": "{origin}", "why": "{what makes it on-brand}" }
    ],
    "off_brand": [
      { "text": "{example}", "source": "{origin}", "why": "{what makes it off-brand}" }
    ]
  },
  "platform_adaptations": {
    "email": {
      "tone_shift": "{description}",
      "format_preferences": "{structure notes}",
      "length": "{typical length}",
      "dos": ["{do this}"],
      "donts": ["{avoid this}"]
    },
    "linkedin": {
      "tone_shift": "{description}",
      "format_preferences": "{structure notes}",
      "length": "{typical length}",
      "dos": ["{do this}"],
      "donts": ["{avoid this}"]
    },
    "twitter": {
      "tone_shift": "{description}",
      "format_preferences": "{structure notes}",
      "length": "{typical length}",
      "dos": ["{do this}"],
      "donts": ["{avoid this}"]
    },
    "blog": {
      "tone_shift": "{description}",
      "format_preferences": "{structure notes}",
      "length": "{typical length}",
      "dos": ["{do this}"],
      "donts": ["{avoid this}"]
    },
    "landing_page": {
      "tone_shift": "{description}",
      "format_preferences": "{structure notes}",
      "length": "{typical length}",
      "dos": ["{do this}"],
      "donts": ["{avoid this}"]
    }
  },
  "audience_awareness": {
    "sophistication_level": "{beginner|intermediate|advanced|mixed}",
    "jargon_tolerance": "{none|light|moderate|heavy}",
    "reading_level": "{target level}",
    "notes": "{additional context}"
  },
  "signature_phrases": [
    { "phrase": "{catchphrase}", "usage": "{when to use}" }
  ]
}
```
