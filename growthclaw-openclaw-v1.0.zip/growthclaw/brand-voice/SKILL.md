---
name: brand-voice
description: "Define or extract a consistent brand voice. Three modes — Extract (analyze existing content), Build (construct from scratch), or Auto-Scrape (provide a URL). Outputs a voice profile to workspace/brand/voice-profile.md that all content skills reference."
metadata:
  openclaw:
    emoji: "🎤"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Brand Voice Engine

Generic copy converts worse than copy with a distinct voice. Not because the words are different -- because the reader feels like they're hearing from a PERSON, not a marketing team.

This skill defines that voice. Either by extracting it from existing content, building it strategically from scratch, or auto-scraping a URL to analyze a brand's public presence.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

For detailed voice extraction frameworks, archetype references, and voice DNA analysis examples, load `references/voice-frameworks.md`.

---

## Brand Memory Integration

On every invocation, check for existing brand context.

### Reads (if they exist)

| File | What it provides | How it shapes output |
|------|-----------------|---------------------|
| workspace/brand/positioning.md | Market angles, differentiators | Informs voice positioning -- a rebel brand sounds different from a trusted advisor |
| workspace/brand/audience.md | Buyer profiles, sophistication level | Jargon tolerance, formality level, cultural references |

### Writes

| File | What it contains |
|------|-----------------|
| workspace/brand/voice-profile.md | The complete voice profile (markdown + embedded JSON) |

### Context Loading Behavior

1. Check whether `workspace/brand/` exists.
2. If it exists, read `positioning.md` and `audience.md` if present.
3. If loaded, show the user what you found:
   ```
   Brand context loaded:
   |-- Positioning    [check] "{primary angle summary}"
   |-- Audience       [check] "{audience summary}"

   Using this to shape your voice profile.
   ```
4. If files are missing, proceed without them. Note at the end:
   ```
   -> /positioning-angles would sharpen this profile
   -> /audience-research would tune jargon level
   ```
5. If `workspace/brand/` does not exist:
   - Skip brand loading entirely. Do not error.
   - Note: "No brand profile found -- this skill works standalone. You can run /start-here or /brand-voice later to unlock personalization."

---

## Iteration Detection

Before starting any mode, check whether `workspace/brand/voice-profile.md` already exists.

### If voice-profile.md EXISTS -> Update Mode

Do not start from scratch. Instead:

1. Read the existing profile.
2. Present a summary of the current voice:
   ```
   EXISTING VOICE PROFILE
   Last updated {date} by {skill}

   Voice summary: {current summary}

   Tone spectrum:
   |-- Formal <-> Casual:        {position}
   |-- Serious <-> Playful:      {position}
   |-- Reserved <-> Bold:        {position}
   |-- Simple <-> Sophisticated: {position}
   |-- Warm <-> Direct:          {position}

   What would you like to change?

   1. Refine the tone (adjust the spectrum)
   2. Update vocabulary (add/remove words)
   3. Add new content samples (re-extract)
   4. Full rebuild (start from scratch)
   5. Auto-scrape my site for fresh data
   ```

3. Process the user's choice:
   - Options 1-2: Targeted update to specific sections
   - Option 3: Run Extract mode on new content, merge results
   - Option 4: Full Build or Extract mode from scratch
   - Option 5: Auto-Scrape mode with existing profile as baseline

4. Before overwriting, show a diff of what changed and only overwrite after explicit confirmation.

### If voice-profile.md DOES NOT EXIST -> Mode Selection

Proceed to the mode selection flow below.

---

## The Core Job

Create a **voice profile** that other skills can reference to produce on-brand output.

The profile should be specific enough that anyone (human or AI) could read it and write in a way that sounds consistent with the brand.

**Output format:** A voice profile document containing:
- Voice summary (2-3 sentences capturing the essence)
- Personality traits (with explanations)
- Tone spectrum (where they land on key dimensions)
- Vocabulary guide (words to use, words to avoid)
- Rhythm and structure patterns
- Example phrases (on-brand vs off-brand)
- Platform adaptation table (how voice flexes across channels)
- Do's and don'ts
- Structured JSON data block (for downstream automation)

---

## Three Modes

### Mode 1: Extract

**Use when:** They have existing content they're proud of -- website copy, emails, social posts, newsletters, video transcripts.

**Process:** Analyze the content for patterns across all 6 dimensions (tone, vocabulary, rhythm, structure, personality, POV), then codify what makes it distinctive.

Request 3-5 pieces of content they consider "most them":
- Website copy (especially About page, homepage)
- Emails they've sent
- Social posts that performed well
- Newsletter editions
- Video or podcast transcripts
- Anything where they felt "this sounds like me"

After analysis, produce the voice profile using the canonical format. Then proceed to the Voice Test Loop.

### Mode 2: Build

**Use when:** Starting fresh, existing content is weak/generic, or they want to evolve their voice strategically.

**Process:** Ask strategic questions, then construct a voice aligned with their identity, audience, and positioning.

**Strategic Questions:**

**Identity:**
1. What are 3-5 words that describe your personality?
2. What do you stand for? What's your core belief about your industry/topic?
3. What's your background? What shaped how you see things?
4. What makes you genuinely different from others in your space?

**Audience:**
5. Who are you talking to? (Be specific)
6. What tone resonates with them? (What do they respond to?)
7. What would make them trust you? What would turn them off?

**Positioning:**
8. Are you the expert, the peer, the rebel, the guide, the insider?
9. Where do you sit on accessible <-> exclusive?
10. Where do you sit on approachable <-> authoritative?

**Aspiration:**
11. Name 2-3 brands or people whose voice you admire. What specifically do you like about how they communicate?
12. What do you explicitly NOT want to sound like?

**Practical:**
13. Any words or phrases that are signature to you?
14. Any words or phrases you hate or want to avoid?
15. How do you feel about humor? Profanity? Hot takes?

From the answers, construct the voice profile. After building, proceed to the Voice Test Loop.

### Mode 3: Auto-Scrape

**Use when:** The user provides a URL or brand name. Available when web search tools are accessible.

**Process:** Automatically pull website copy, social bios, and recent posts. Feed all gathered content into Extract mode without requiring manual paste.

If web search is not available, fall back gracefully -- offer Extract or Build mode instead.

**Auto-Scrape Process:**

1. **Gather content** from the provided URL: homepage, about page, blog posts, LinkedIn, Twitter/X, podcast appearances
2. **Report what was found** with word counts
3. **Feed into Extract mode** -- run the full 6-dimension analysis
4. **Ask 2-3 supplementary questions** to fill gaps the scrape could not answer
5. Merge answers with extracted data and produce the final voice profile

**How to choose mode:**

Ask:
```
  Do you have existing content that represents
  how you want to sound?

  1. I have content I am proud of
     -> Extract mode (paste it in)
  2. No, I am starting fresh
     -> Build mode (I will ask questions)
  3. I have content but want to evolve
     -> Build mode (with existing as reference)
  4. Just give me your URL
     -> Auto-Scrape mode (I will research you)
```

If the user provides a URL in their initial message without being asked, skip mode selection and go directly to Auto-Scrape mode.

---

## Voice Test Loop

After generating the voice profile from ANY mode, run this validation step before saving.

### Step 1: Generate 3 Sample Paragraphs

Using the voice profile you just created, write three pieces of sample content in the brand's voice:

1. **Email opening** -- A 3-4 sentence email opening paragraph that demonstrates the voice. Should feel like a real email the brand would send.
2. **Social post** -- A LinkedIn or Twitter/X post in the brand's voice. Match the platform they are most active on.
3. **Landing page hero** -- A headline + subheadline + 1-2 supporting sentences. Show the brand's direct-response voice.

Present all three and ask:
```
  Does this sound like you?

  1. Yes, that nails it -> Save and finish
  2. Close but needs adjustment -> Tell me what
  3. Not quite right -> Show me what is wrong
```

### Step 2: Process Feedback

**If "Yes, that nails it":** Proceed to file output.

**If "Close but needs adjustment":** Ask what feels off (tone, vocabulary, rhythm, or something else). Adjust the relevant sections, regenerate samples, present again. Repeat until confirmed.

**If "Not quite right":** Ask for an example of something they've written that sounds right, or ask them to describe what's wrong. If they provide examples, run a focused Extract analysis. Rebuild and re-test.

### Step 3: Iteration Limit

If the user goes through 3 rounds without confirming:
```
  We have been through a few rounds. Sometimes
  the best approach is to save what we have and
  refine over time as you use other skills.

  1. Save current version (you can always re-run
     /brand-voice to update)
  2. One more round -- I think I know what to fix
  3. Start over with Build mode (answer the 15
     questions instead)
```

---

## The Voice Profile (Output Format)

This is the canonical format for voice-profile.md. Every field is required.

```markdown
## Last Updated
{YYYY-MM-DD} by /brand-voice

# {Brand/Person Name} Voice Profile

## Voice Summary
{2-3 sentences capturing the essence. What does this voice FEEL like to encounter?}

## Core Personality Traits
- **{Trait 1}:** {What this means in practice}
- **{Trait 2}:** {What this means in practice}
- **{Trait 3}:** {What this means in practice}
- **{Trait 4}:** {What this means in practice}

## Tone Spectrum

| Dimension | Position | Notes |
|-----------|----------|-------|
| Formal <-> Casual | {e.g., "Casual, but not sloppy"} | {specifics} |
| Serious <-> Playful | {e.g., "Mostly serious, occasional wit"} | {specifics} |
| Reserved <-> Bold | {e.g., "Bold, makes strong claims"} | {specifics} |
| Simple <-> Sophisticated | {e.g., "Simple words, sophisticated ideas"} | {specifics} |
| Warm <-> Direct | {e.g., "Direct but not cold"} | {specifics} |

## Vocabulary

**Words/phrases to USE:**
- {word/phrase} -- {why/when}

**Words/phrases to AVOID:**
- {word/phrase} -- {why}

**Jargon level:** {Heavy / Moderate / Light / Translated}

**Profanity:** {Yes / Occasional / Never}

## Rhythm & Structure

**Sentences:** {pattern}
**Paragraphs:** {pattern}
**Openings:** {pattern}
**Formatting:** {pattern}

## POV & Address

**First person:** {I / We / Mix}
**Reader address:** {You / Direct name / Folks / Friends / etc.}
**Relationship stance:** {Teacher / Peer / Guide / Insider / Rebel}

## Platform Adaptations

| Platform | Tone Shift | Structure | Length |
|----------|-----------|-----------|--------|
| Email | {shift} | {structure} | {length} |
| LinkedIn | {shift} | {structure} | {length} |
| Twitter/X | {shift} | {structure} | {length} |
| Blog/SEO | {shift} | {structure} | {length} |
| Landing Page | {shift} | {structure} | {length} |

## Example Phrases

**On-brand (sounds like us):**
- "{Example phrase}"

**Off-brand (doesn't sound like us):**
- "{Example phrase}" -- {why it's wrong}

## Do's and Don'ts

**DO:**
- {specific guidance}

**DON'T:**
- {specific guidance}

---

<details>
<summary>Structured Data (JSON)</summary>

{JSON block conforming to the voice profile schema}

</details>
```

---

## Formatted Output Structure

When presenting the completed voice profile to the user, use the premium formatting system for terminal output. The markdown file saved to disk uses standard markdown.

### Terminal Output Template

```
  BRAND VOICE PROFILE
  Generated {Mon DD, YYYY}

  Mode: {Extract | Build | Auto-Scrape}
  Brand: {name}

  {If brand context was loaded:}
  Brand context:
  |-- Positioning    [check] loaded
  |-- Audience       [check] loaded

  VOICE DNA

  Summary: {2-3 sentence voice summary}

  Personality:
  |-- {Trait 1}: {explanation}
  |-- {Trait 2}: {explanation}
  |-- {Trait 3}: {explanation}
  |-- {Trait 4}: {explanation}

  TONE SPECTRUM

  Formal <-> Casual:        {position}
  Serious <-> Playful:      {position}
  Reserved <-> Bold:        {position}
  Simple <-> Sophisticated: {position}
  Warm <-> Direct:          {position}

  VOCABULARY

  Words to use         Words to avoid
  |-- {word}           |-- {word}

  Jargon: {level}   Profanity: {level}

  RHYTHM

  Sentences:  {pattern}
  Paragraphs: {pattern}
  Openings:   {pattern}
  Formatting: {pattern}

  POV

  First person:     {I / We / Mix}
  Reader address:   {how they address the reader}
  Stance:           {Teacher / Peer / Guide / etc.}

  PLATFORM ADAPTATIONS

  Platform      Tone Shift       Length
  Email         {shift}          {length}
  LinkedIn      {shift}          {length}
  Twitter/X     {shift}          {length}
  Blog/SEO      {shift}          {length}
  Landing Page  {shift}          {length}

  VOICE TEST

  {Present the 3 sample paragraphs here}
  {Then the feedback prompt}

  FILES SAVED

  workspace/brand/voice-profile.md       [check]

  WHAT'S NEXT

  Your voice profile is set. Every content skill
  will reference it from here on.

  -> /positioning-angles   Find your market angle (~10 min)
  -> /direct-response-copy Write your first landing
                           page (~15 min)
  -> /start-here           See full project status

  Or tell me what you're working on and
  I will route you.
```

---

## File Output Protocol

After the voice test loop passes (user confirms the voice sounds right), write the profile to disk.

### Writing the File

1. Create the `workspace/brand/` directory if it does not exist.
2. Write the complete voice profile to `workspace/brand/voice-profile.md`.
3. Include the `## Last Updated` line at the top with today's date and `/brand-voice` as the author.
4. Include the structured JSON block at the bottom in a collapsible `<details>` section.

### If Overwriting

Follow the brand memory protocol:
1. Read the existing file first.
2. Show the user what will change (diff the key sections).
3. Ask for confirmation: "Replace the existing file? (y/n)"
4. Only overwrite after explicit confirmation.
5. Confirm what changed: "Updated voice profile. Changes: shifted tone from formal to casual, added 3 new signature phrases, updated platform adaptations."

### Confirmation Output

After saving:
```
  FILES SAVED

  workspace/brand/voice-profile.md       [check]
```

---

## How This Skill Connects to Others

The voice profile becomes an INPUT to other skills:

- **direct-response-copy + voice profile:** Write copy that matches tone, vocabulary, and style.
- **lead-magnet + voice profile:** Generate lead magnet concepts with hook and framing aligned to the voice.
- **email-sequences + voice profile:** Build sequences using the email-specific adaptations from the platform table.
- **seo-content + voice profile:** Write long-form guides using the blog/SEO adaptations to maintain voice at length.
- **content-atomizer + voice profile:** Repurpose content with platform-specific adaptations for each channel.
- **newsletter + voice profile:** Design newsletter editions matching email adaptations with extra personality.
- **creative + voice profile:** Generate ad copy with landing page adaptations -- urgent, benefit-focused, on-brand.

**The workflow:**
1. Run /brand-voice first (Extract, Build, or Auto-Scrape)
2. Confirm the voice through the test loop
3. Profile saves to workspace/brand/voice-profile.md
4. Every subsequent content skill reads this file automatically
5. Platform adaptations ensure voice flexes correctly per channel

---

## When to Revisit

Voice isn't static. Revisit the profile when:
- The brand evolves or pivots
- Audience changes significantly
- Current voice isn't converting
- New team members need onboarding
- Content starts feeling inconsistent
- Moving into a new platform (add adaptations)
- A/B tests reveal tone preferences

When the user revisits, the Iteration Detection system kicks in -- they see their current profile and choose what to update rather than starting from scratch.

---

## The Test

A good voice profile passes this test:

1. **Recognizable:** Could someone identify content as "theirs" without a byline?
2. **Actionable:** Could a writer (human or AI) produce on-brand content using only the profile?
3. **Differentiated:** Does it sound different from competitors?
4. **Authentic:** Does it feel true to who they are (or want to be)?
5. **Consistent:** Can it be applied across formats (social, email, long-form)?
6. **Adaptive:** Does the platform adaptation table give enough guidance to shift voice per channel without losing identity?

If any answer is no, the profile needs more specificity.

---

## Feedback Collection

After the voice test loop passes and the profile is saved, present the standard feedback prompt:

```
  How did this land?

  a) Great -- this is exactly how I sound
  b) Good -- made minor mental adjustments
  c) Needs significant rework
  d) Have not tested it in real content yet

  (You can answer later -- just run /brand-voice
  again and tell me.)
```

### Processing Feedback

**If (a) "Great":** Log to workspace/brand/learnings.md under "What Works".

**If (b) "Good -- minor adjustments":** Ask what they'd adjust. Log the change. Offer to update the profile.

**If (c) "Needs significant rework":** Ask what feels wrong or for an example that sounds right. Re-run Extract on new examples or suggest Build mode.

**If (d) "Have not tested yet":** Note it. Next time /brand-voice runs, remind them.

---

## Error States

### No content provided in Extract mode

Offer to paste content, switch to Build mode, or provide a URL for Auto-Scrape.

### Auto-Scrape finds insufficient content

If less than 500 words found, report what was gathered with a breakdown, then offer to paste additional content manually or switch to Build mode.

### Web search not available

Fall back to Extract mode (paste content) or Build mode (answer questions).

---

## Complete Invocation Flow

```
  /brand-voice invoked
  |
  |-- Check workspace/brand/ directory
  |   |-- Load positioning.md (if exists)
  |   |-- Load audience.md (if exists)
  |
  |-- Check workspace/brand/voice-profile.md
  |   |-- EXISTS -> Update Mode
  |   |   |-- Show current profile summary
  |   |   |-- Ask what to change
  |   |   |-- Process changes
  |   |   |-- Run Voice Test Loop
  |   |   |-- Show diff, confirm overwrite
  |   |   |-- Save updated profile
  |   |
  |   |-- DOES NOT EXIST -> Mode Selection
  |       |-- User has content -> Extract Mode
  |       |-- User starting fresh -> Build Mode
  |       |-- User provides URL -> Auto-Scrape Mode
  |
  |-- After save -> Feedback Collection
  |   |-- Present feedback prompt
  |   |-- Log to learnings.md if applicable
  |
  |-- Present WHAT'S NEXT section
```

---

## Implementation Notes

1. **Never skip the iteration check.** Always look for an existing voice-profile.md before starting a new profile.

2. **Never skip the voice test loop.** Every profile must be validated with 3 sample paragraphs before saving. The samples must be genuinely written in the extracted/built voice -- not generic marketing copy.

3. **Show your work.** When loading brand context, say what you loaded. When scraping, show what you found. When analyzing, name the patterns.

4. **Platform adaptations are mandatory.** Every voice profile must include the Platform Adaptations table.

5. **The JSON block is mandatory.** Every saved voice-profile.md must include the structured JSON at the bottom.

6. **Respect the brand memory protocol.** Read before write. Diff before overwrite. Confirm before save. Append to learnings.md, never overwrite.

7. **Auto-Scrape is best-effort.** If scraping finds less than 500 words, fall back gracefully.

8. **The voice test loop is a conversation.** Do not rush through it.

9. **Fill the platform adaptations table thoughtfully.** Each brand has different platform behaviors. Think about each adaptation individually.

10. **Write the file path correctly.** The profile saves to `workspace/brand/voice-profile.md`.
