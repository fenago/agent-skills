---
name: lead-magnet
description: "Generate compelling lead magnet concepts AND build the actual content -- checklists, templates, guides, quizzes, swipe files, challenges, calculators."
metadata:
  openclaw:
    emoji: "\U0001F9F2"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Lead Magnet Ideation + Build

The best lead magnets aren't about what you want to give away. They're about what your prospect desperately wants to consume -- and how that consumption naturally leads them toward your paid offer.

This skill generates lead magnet concepts that actually convert. And then it builds them.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

For best-in-class examples by format type, load `references/format-examples.md`.

For info product lead magnet strategies, load `references/info-product-magnets.md`.

For SaaS-specific patterns, load `references/saas-magnets.md`.

For agency and consulting strategies, load `references/services-magnets.md`.

For conversion psychology, load `references/psychology.md`.

---

## Brand Memory Integration

**Reads:** `voice-profile.md`, `positioning.md`, `audience.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

1. **`voice-profile.md`** -- Match tone and vocabulary in all lead magnet copy. Show: "Your voice is [tone summary]."
2. **`positioning.md`** -- Use positioning angle to frame the lead magnet and bridge to paid offer. Show: "Positioning: '[angle]'."
3. **`audience.md`** -- Match format complexity to audience preference; use their language. Show: "Writing for [audience summary]."
4. **Check existing lead magnets** in `workspace/campaigns/*/brief.md` or `workspace/brand/assets.md`. If found, ask: revise, create new, or generate additional concepts?
5. **If `workspace/brand/` does not exist** -- skip, proceed standalone. Note: "No brand profile yet. Run /start-here or /brand-voice first, or I'll work without it."

### Context Loading Display

```
Brand context loaded:
+-- Voice Profile     {Y/X} {summary}
+-- Positioning       {Y/X} {summary}
+-- Audience          {Y/X} {summary}
+-- Learnings         {Y/X} {summary}
```

---

## Competitive Research

Before generating concepts, use web search to find competitor lead magnets. This prevents generic ideas and reveals gaps.

1. **Identify niche** from user input + brand memory
2. **Search:** "[niche] free download", "[niche] lead magnet", "[competitor] free resource"
3. **Analyze:** formats used, hooks, gaps, what's overdone
4. **Display findings:**
   ```
   COMPETITIVE LANDSCAPE
   +-- [Competitor A]   "{title}" ({format})
   +-- [Competitor B]   "{title}" ({format})
   Gap: {what no one offers}
   Overdone: {what everyone does}
   Opportunity: {where to differentiate}
   ```
5. **Differentiate:** If everyone has PDFs, suggest quiz/calculator. If broad, go narrow.

If web search unavailable: note it, proceed with framework knowledge and reference files.

---

## Iteration Detection

Check if a lead magnet already exists in `workspace/campaigns/*/`. If found, present summary and ask: revise, create new, or generate additional concepts. If none exist, proceed to concept generation.

---

## The Core Job

Surface **3-5 compelling concepts** the user can choose from, each with:
- The concept (one sentence)
- The format (quiz, PDF, calculator, challenge, template, etc.)
- The hook (why someone would give their email for this)
- The bridge (how it leads to the paid offer)
- Implementation notes (difficulty, resources needed)

### Before Generating: Understand the Context

**Step 1: Identify business type.** Different types have different optimal formats:
- **Info Products:** Quizzes, challenges, PDF frameworks, video series, free chapters
- **SaaS:** Free tools, ROI calculators, templates, checklists
- **Services:** Audits, assessments, case studies, templates showcasing methodology

**Step 2: Identify what they sell.** Not the product -- the transformation. The lead magnet delivers a MICRO-VERSION of that transformation.

**Step 3: Identify the target.** Current situation, what they've tried, what they believe, what would make them say "this is exactly what I needed." Use `audience.md` if available; otherwise ask.

---

## The Lead Magnet Framework

### The Specificity Principle

**Narrow beats broad. Every time.** Push toward: specific outcome, specific timeframe, specific audience, specific method.

### The Bridge Principle

**The lead magnet must logically connect to the paid offer.** The best lead magnets are "Step 1" of what you sell. The bridge should be obvious: "If you liked this free thing, the paid thing is more/deeper/complete."

### The Quick Win Principle

**Solve one specific problem completely.** Checklists completable in 10 minutes, templates customizable in an hour, assessments with immediate scores and action items.

### The Value Equation

**Value = (Dream Outcome x Perceived Likelihood) / (Time Delay x Effort)**

Maximize dream outcome and perceived likelihood. Minimize time delay and effort.

---

## Format Selection Framework

| Format | Best For | Difficulty |
|--------|----------|-----------|
| Quizzes/Assessments | Personalization, segmentation | Medium |
| PDF Guides/Frameworks | Authority, complex topics | Low |
| Checklists/Templates | Quick wins, immediate utility | Low |
| Calculators/Tools | SaaS, ROI-focused offers | Medium-High |
| Challenges (5-7 day) | Community, transformation offers | Medium |
| Video Series | Teaching style, high-ticket | Medium |
| Swipe Files | Creative industries, copywriting | Low |

---

## Hook Generators

Every lead magnet needs a hook. Seven types:

1. **The Shortcut:** "Get [outcome] without [pain]"
2. **The Secret:** "The [hidden thing] that [result]"
3. **The System:** "The [named method] for [outcome]"
4. **The Specific Number:** "[N] [things] to [outcome]"
5. **The Assessment:** "Discover your [type/score/level]"
6. **The Transformation:** "How to go from [current] to [desired]"
7. **The Case Study:** "How [person] achieved [result]"

---

## Concept Output Format

```
LEAD MAGNET CONCEPTS
Generated {date}

BRAND CONTEXT
+-- Voice Profile     {Y/X} {summary}
+-- Positioning       {Y/X} {summary}
+-- Audience          {Y/X} {summary}

COMPETITIVE LANDSCAPE
+-- {Competitor}  "{title}" ({format})
Gap: {gap}  |  Overdone: {overdone}  |  Opportunity: {opp}

----------------------------------------------

1. {CONCEPT NAME}                  * recommended
"{Hook headline}"
Format: {type}  |  Bridge: {connection}
Effort: {level}  |  Best for: {situation}

----------------------------------------------

2-5. ...continue...

----------------------------------------------

QUICK PICK
* Concept 1 -- {rationale}

WHAT'S NEXT
-> "Build 1"  |  "Build 2"  |  "Tweak 3"  |  "More ideas"
```

---

## Build Mode

After the user selects a concept, this skill enters BUILD MODE and writes the actual lead magnet content. Not just the idea -- the thing itself.

### Activation

Any clear selection: "Build 1", "Let's go with concept 1", "Write the checklist", etc.

### Build Process

1. **Confirm** -- restate concept, hook, format
2. **Gather missing details** -- industry data, product details, pricing if needed
3. **Write the content** -- full lead magnet per format type
4. **Save** -- `workspace/campaigns/{magnet-name}/lead-magnet.md`
5. **Create brief** -- `workspace/campaigns/{magnet-name}/brief.md`
6. **Update assets** -- append to `workspace/brand/assets.md`
7. **Offer funnel chain** -- next skills in the funnel

### Build Specs by Format

**Checklists:** Title + hook, intro (2-3 sentences), 10-25 grouped items each with action/explanation/tip, "quick start" top 3, bridge section, CTA.

**Templates:** Title + instructions, fill-in sections using [BRACKETS], example fills, section-by-section guidance, completed example, bridge section.

**Guides:** Title + hook, TL;DR (3-5 bullets), 3-7 sections each with principle/why/how/example, actionable takeaways, "put it all together" section, bridge.

**Quizzes:** Title + description, 7-15 questions with 3-5 options each, scoring logic, 3-5 result profiles with descriptions/recommendations/per-profile bridges, implementation notes.

**Swipe Files:** Title + hook, intro, 20-50+ items by category each with example/context/why-it-works, usage tips, bridge.

**Challenges:** Title + hook + promise, day-by-day breakdown with topic/action/teaching-point/success-metric, engagement prompts, email subject lines, final-day bridge.

**Calculators:** Title + purpose, input fields with labels/placeholders/validation, calculation logic with formulas, output format, interpretation guide, result-to-offer bridges, implementation notes.

---

## File Output

### Directory Structure

```
workspace/campaigns/{magnet-name}/
  lead-magnet.md       <- The actual content
  brief.md             <- Campaign brief
```

**Naming:** lowercase-kebab-case from concept name.

### Lead Magnet File

```markdown
---
title: "{Title}"
subtitle: "{Hook subtitle}"
format: {type}
hook: "{One-line hook}"
bridge_to: "{Paid offer}"
target_audience: "{Who}"
estimated_consumption_time: "{time}"
status: draft
created_by: /lead-magnet
created_date: {YYYY-MM-DD}
---

# {Title}

{Full content -- varies by format}
```

### Campaign Brief

```markdown
# Campaign: {Name}

## Goal
{What this accomplishes}

## Format / Hook / Target Audience / Bridge / Paid Offer
{Fill each}

## Competitive Differentiation
{How this differs from competitors}

## Distribution Plan
{Landing page, social, ads, content upgrades}

## Status
draft
```

---

## Build Mode Output

```
LEAD MAGNET BUILT
Generated {date}

"{Title}"  |  Format: {type}  |  Hook: "{hook}"
Audience: {target}  |  Time: {estimate}

CONTENT SUMMARY
+-- {format-specific summary}

BRIDGE LOGIC
Delivers: {micro-transformation}
Creates desire for: {paid offer}

FILES SAVED
workspace/campaigns/{name}/lead-magnet.md    Y
workspace/campaigns/{name}/brief.md          Y
workspace/brand/assets.md                    Y (appended)

WHAT'S NEXT
-> /creative              PDF layout, cover design (~15 min)
-> /direct-response-copy  Landing page (~20 min)
-> /email-sequences       Delivery + welcome sequence (~15 min)
-> /content-atomizer      Social promotion (~15 min)
-> "Revise"               Edit specific sections

FUNNEL CHAIN
1. Lead Magnet        Y built
2. Landing Page       -> /direct-response-copy
3. Email Sequence     -> /email-sequences
4. Social Promotion   -> /content-atomizer

FEEDBACK
1. Does it feel genuinely valuable?
2. Does the bridge feel natural?
3. Is the scope right?
```

---

## The Test

Before delivering concepts:
1. Is it specific? 2. Does it solve one problem completely? 3. Is the bridge obvious? 4. Would the audience actually want this? 5. Is it feasible?

Before delivering built content, also:
6. Genuinely valuable? 7. Quick win delivered? 8. Bridge natural? 9. Voice consistent? 10. Right length?

---

## Recording Feedback

- **"Great -- shipped as-is"** -- Log to `workspace/brand/learnings.md` with format, title, hook, angle.
- **"Good -- minor edits"** -- Ask what changed, log it. If voice mismatch, suggest /brand-voice.
- **"Rewrote significantly"** -- Ask for final version, analyze diff, log findings.
- **"Haven't used yet"** -- Note it, don't log yet.

---

## How This Connects to Other Skills

**Uses:** brand-voice, positioning-angles, start-here

**Feeds:** direct-response-copy (landing page), email-sequences (delivery + welcome), content-atomizer (social promotion), newsletter (content strategy)

---

## Quick-Reference Checklists

**Pre-Generation:** Brand memory loaded, business type identified, paid offer identified, target audience identified, competitive research done, existing magnet check done.

**Build Mode:** Content valuable, quick win achievable, voice matches, bridge natural, length appropriate, frontmatter complete, files saved, assets updated, next steps offered.
