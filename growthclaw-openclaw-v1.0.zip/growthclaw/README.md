# GrowthClaw

Marketing skills pack for [OpenClaw](https://github.com/openclaw/openclaw). 12 specialized marketing skills that turn your OpenClaw instance into a full-stack marketing team.

## What You Get

| Skill | What It Does |
|-------|-------------|
| `/start-here` | Marketing dashboard — scans your project, routes you to the right skill |
| `/brand-voice` | Extract or build a consistent brand voice from your content |
| `/positioning-angles` | Find the angle that makes your product stand out (with live competitor research) |
| `/direct-response-copy` | Write landing pages, sales pages, emails, ads that convert |
| `/keyword-research` | Strategic keyword research and content roadmap (no expensive tools needed) |
| `/seo-content` | Write articles that rank AND read like a human wrote them |
| `/email-sequences` | Build welcome, nurture, and sales email sequences |
| `/lead-magnet` | Create lead magnets that build your list and convert to paid |
| `/newsletter` | Write newsletters people actually want to read |
| `/content-atomizer` | Turn one piece of content into platform-optimized posts everywhere |
| `/creative` | AI image and video generation for product photos, ads, social graphics |
| `/stack-key-advisor` | Audit your API keys and get setup recommendations for your goals |

## Quick Start

### Option A: Drop-in (simplest)

```bash
git clone https://github.com/thevibemarketer/growthclaw.git
cp -r growthclaw/ ~/.openclaw/skills/growthclaw/
```

### Option B: Install script

```bash
git clone https://github.com/thevibemarketer/growthclaw.git
cd growthclaw
./install.sh
```

### Option C: extraDirs (keep in your repo)

Add to `~/.openclaw/openclaw.json`:

```json
{
  "skills": {
    "load": {
      "extraDirs": ["/path/to/growthclaw"]
    }
  }
}
```

## API Keys (All Optional)

No keys required. Every skill works without API keys using graceful degradation.

See [KEYS.md](KEYS.md) for the full key matrix, or run `/stack-key-advisor` after install.

**Quick setup:**

```bash
cp .env.example .env
# Edit .env with your keys
```

| Key | What It Adds | Cost |
|-----|-------------|------|
| `BRAVE_API_KEY` | Live SERP data for 5+ skills | Free tier |
| `REPLICATE_API_TOKEN` | AI image/video generation | ~$0.02/image |
| ESP key (Mailchimp, etc.) | Email automation | Free tiers available |

## How It Works

### Brand Memory

GrowthClaw maintains persistent context in `workspace/brand/`:

```
workspace/brand/
├── voice-profile.md      ← Your brand voice (written by /brand-voice)
├── positioning.md        ← Your market angle (written by /positioning-angles)
├── audience.md           ← Your buyer profiles
├── competitors.md        ← Competitive landscape
├── creative-kit.md       ← Visual identity
├── keyword-plan.md       ← SEO strategy (written by /keyword-research)
├── stack.md              ← Connected tools and API status
├── assets.md             ← Registry of everything created (append-only)
└── learnings.md          ← What works, what doesn't (append-only)
```

Skills build on each other. Run `/brand-voice` first, and every subsequent skill uses your voice. Run `/positioning-angles`, and your copy skills write with your angle baked in.

### Graceful Degradation

Every skill works on day one with zero context:
- No brand files? Skill asks what it needs or uses smart defaults.
- No API keys? Skill generates portable output you can use anywhere.
- Partial setup? Skill uses what's available and suggests what to add next.

### Works Alongside Your Existing Skills

GrowthClaw adds marketing skills without touching your existing OpenClaw setup:
- Your AGENTS.md, SOUL.md, TOOLS.md remain untouched
- Your existing skills keep working
- Uninstall by removing the growthclaw directory

## Verify Installation

```bash
./doctor.sh
```

## Requirements

- OpenClaw (any recent version)
- Node >= 22 (OpenClaw requirement)

## License

MIT
