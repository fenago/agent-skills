# Keyword Research Methodology Reference

Detailed methodology, examples, and templates for the keyword-research skill. The main SKILL.md contains the core process -- this file provides depth for each phase.

---

## Expansion Techniques (Phase 2 Detail)

For each seed keyword, find variations using these pattern sets:

**Question patterns:**
- What is [keyword]?
- How to [keyword]?
- Why [keyword]?
- Best [keyword]?
- [keyword] vs [alternative]?
- [keyword] examples
- [keyword] for [audience]

**Modifier patterns:**
- [keyword] tools
- [keyword] templates
- [keyword] guide
- [keyword] strategy
- [keyword] 2026
- [keyword] for beginners
- [keyword] for [industry]

**Comparison patterns:**
- [keyword A] vs [keyword B]
- best [category]
- [tool] alternatives
- [tool] review

**Output:** Expanded list of 100-200 keywords from seed terms

---

## Google Autocomplete Mining (Phase 3 Detail)

For each seed and pillar keyword, search for autocomplete suggestions:

```
Search: "[keyword] a", "[keyword] b", ... "[keyword] z"
Search: "how to [keyword]"
Search: "best [keyword]"
Search: "why [keyword]"
Search: "[keyword] vs"
Search: "[keyword] for"
```

Capture every unique suggestion. These are real queries people type.

**What to look for:**
- Suggestions you did not think of (add to expanded list)
- Recurring modifiers (signals what people care about)
- Question patterns (signals informational intent)
- Brand/product mentions (signals commercial intent)
- Year modifiers ("2026") signal freshness demand

---

## People Also Ask Mining (Phase 3 Detail)

For each pillar keyword, search Google and capture the People Also Ask boxes:

```
Search: "[pillar keyword]"
--> Capture PAA questions
--> Click/expand each PAA to get follow-up PAAs
--> Capture the second-level questions too
```

**What PAA data reveals:**
- The exact questions your audience asks (use as H2s in content)
- Related subtopics Google associates with this keyword
- Content gaps -- if PAA answers are thin, opportunity exists
- Semantic relationships between topics

**How to use PAA data:**
- Add new questions to your expanded keyword list
- Map PAA questions to content sections within pillar articles
- Identify PAA questions that deserve standalone articles
- Use PAA phrasing in headers (matches how people search)

---

## SERP Analysis Detail (Phase 3)

For each priority keyword, examine the top search results:

```
Search: "[keyword]"
--> Analyze the top 5-10 results
--> Note: content type, word count, freshness, domain authority
```

**Capture for each result:**
- Title and URL
- Content type (guide, listicle, comparison, tool page, etc.)
- Freshness (when was it published/updated?)
- Quality assessment (comprehensive or thin?)
- Domain type (major publication, niche site, personal blog?)

**SERP signals that matter:**

| Signal | What it means |
|--------|--------------|
| Top results are 2+ years old | Freshness opportunity |
| Top results are thin (<1000 words) | Depth opportunity |
| Top results are all big brands (DR 80+) | Hard to win -- consider long-tail |
| Mixed results (big + small sites) | Winnable with great content |
| Forums/Reddit in top 5 | Huge content gap -- no good article exists |
| Featured snippet present | Optimize for snippet format |
| "People Also Ask" is extensive | Topic has depth worth covering |

---

## Competitor Content Analysis (Phase 3 Detail)

If `workspace/brand/competitors.md` is loaded (or competitors were provided), search for what they rank for:

```
Search: "site:{competitor-domain.com} [topic]"
Search: "{competitor name} [pillar keyword]"
Search: "{competitor name} blog"
```

**Build a competitor content map:**

For each competitor:
- What topics do they cover?
- What content types do they use?
- What keywords do they appear to target?
- Where are the gaps -- topics they do NOT cover?
- What is their content quality like?

**Content gap analysis:**

| Topic | You | Competitor A | Competitor B | Gap? |
|-------|-----|-------------|-------------|------|
| [topic 1] | No | Strong | Weak | Catch-up + improve |
| [topic 2] | No | No | No | Blue ocean opportunity |
| [topic 3] | Thin | Strong | No | Improve existing |

**Priority content gaps:**
1. Topics ALL competitors cover but you do not (catch-up)
2. Topics NO ONE covers well (blue ocean)
3. Topics where competitors are weak/outdated (improvement)

---

## Search Integration Output Template

After web search, present findings before clustering:

```
  WEB RESEARCH COMPLETE

  Autocomplete suggestions:   {N} unique terms
  People Also Ask questions:  {N} captured
  SERPs analyzed:             {N} keywords
  Competitor pages reviewed:  {N} pages

  TOP DISCOVERIES

  -- {discovery 1 -- e.g., "unexpected keyword
     with forum results dominating SERP"}
  -- {discovery 2 -- e.g., "competitor X has no
     content on {topic} -- wide open"}
  -- {discovery 3 -- e.g., "PAA reveals audience
     cares about {angle} more than expected"}

  NEW KEYWORDS ADDED FROM SEARCH

  -- {keyword from autocomplete}
  -- {keyword from PAA}
  -- {keyword from competitor gap}
  -- +{N} more added to expanded list
```

---

## Clustering Process Detail (Phase 4)

### Identifying Pillars (5-10 per business)

A pillar is a major topic area that could support:
- One comprehensive guide (3,000-8,000 words)
- 3-7 supporting articles
- Ongoing content expansion

Ask: "Could this be a complete guide that thoroughly covers the topic?"

### Clustering Steps

1. **Group by semantic similarity** -- Keywords that mean similar things
2. **Group by search intent** -- Keywords with same user goal
3. **Identify the pillar keyword** -- The broadest term in each group
4. **Identify supporting keywords** -- More specific variations
5. **Attach PAA questions** -- Map People Also Ask questions to the cluster they belong to
6. **Note competitor coverage** -- Mark which competitors cover this cluster

### Example Cluster (with search data)

**Pillar:** AI Marketing Automation

**Clusters:**
- What is AI marketing automation (definitional)
  - PAA: "Is AI marketing worth it?", "How does AI help marketing?"
  - SERP: Top results are thin, 2024-dated. Opportunity.
- AI marketing tools (commercial/comparison)
  - PAA: "What is the best AI marketing tool?", "Are AI marketing tools free?"
  - SERP: Dominated by listicles. Can win with practitioner angle.
- AI marketing examples (proof/validation)
  - Competitor gap: None of the 3 competitors have case study content.
- Building AI marketing workflows (how-to)
  - PAA: "How to automate marketing with AI?", "Can I automate my marketing?"
  - SERP: Reddit in top 5. Major content gap.
- AI vs traditional automation (comparison)

---

## Pillar Validation Details (Phase 5)

### 1. Search Volume Test

Does this pillar have >1,000 monthly searches across its keyword cluster?

- If YES: Valid pillar
- If NO: Not a pillar. It may be a single article or should not be created at all.

Use web search to estimate volume. Check Google autocomplete richness (more suggestions = more search interest), check whether Google shows "About X results" for the query, and check SERP competitiveness as a proxy for search demand.

Example failure: "Claude marketing" (zero search volume) chosen as pillar because the product uses Claude. Market searches "AI marketing" instead.

### 2. Product vs. Market Test

Is this pillar something the MARKET searches for, or something YOU want to talk about?

| Product-Centric (Wrong) | Market-Centric (Right) |
|-------------------------|------------------------|
| "Our methodology" | "Marketing automation" |
| "[Your tool name] tutorials" | "[Category] tutorials" |
| "Why we're different" | "[Problem] solutions" |
| Features of your product | Outcomes people search for |

The market does not search for your product name (unless you are famous). They search for solutions to their problems.

If positioning.md is loaded, cross-reference. The positioning angle should INFORM keyword selection, not dictate it. Your angle is how you write about market topics, not the topics themselves.

### 3. Competitive Reality Test

Can you actually win here?

Check the top 3 results for the pillar keyword (from SERP data):
- All DR 80+ sites (Forbes, HubSpot, etc.)? Find adjacent pillar.
- Mix of authority and smaller sites? Winnable with great content.
- Thin content from unknown sites? High opportunity.
- Reddit/forums in results? Huge opportunity -- no good article exists.

Do not choose pillars where you have no realistic path to page 1.

### 4. Proprietary Advantage Test

Do you have unique content, data, or expertise for this pillar?

| Advantage | Priority |
|-----------|----------|
| Proprietary data others do not have | Prioritize highly |
| Unique methodology or framework | Prioritize highly |
| Practitioner experience (done it, not read about it) | Prioritize |
| Same info everyone else has | Deprioritize |

If positioning.md is loaded, the proprietary advantage test automatically checks your stated differentiators against each pillar.

### Validation Output Format

For each proposed pillar, document:

```
Pillar: [Name]
Search volume test: PASS/FAIL -- [evidence from web search]
Market-centric test: PASS/FAIL -- [evidence]
Competitive test: PASS/FAIL -- [SERP evidence]
Proprietary advantage: YES/NO -- [what advantage]
VERDICT: VALID PILLAR / DEMOTE TO CLUSTER / REMOVE
```

**If a pillar fails 2+ tests, it is not a pillar.** Either demote it to a single article within another pillar, or remove it entirely.

---

## Content Brief Template (Phase 8)

```markdown
# Content Brief: {Article Title}

## Last Updated
{YYYY-MM-DD} by /keyword-research

## Target Keyword
Primary: {main keyword}
Secondary: {2-5 supporting keywords}
Long-tail: {3-5 long-tail variations}

## Search Intent
{Informational / Commercial / Transactional}

## Content Type
{Pillar Guide / How-To / Comparison / Listicle / Use Case / Definition}

## Target Word Count
{range}

## SERP Snapshot
Top 3 current results:
1. {Title} -- {Domain} -- {Content type} -- {Assessment}
2. {Title} -- {Domain} -- {Content type} -- {Assessment}
3. {Title} -- {Domain} -- {Content type} -- {Assessment}

Content gap to exploit: {what is missing from current results}

## People Also Ask
- {PAA question 1}
- {PAA question 2}
- {PAA question 3}
- {PAA question 4}

## Recommended Outline
H1: {Title}
  H2: {Section from PAA or logical flow}
  H2: {Section}
  H2: {Section}
  H2: {Section}
  H2: {Section}

## Angle
{How to approach this topic given the brand's positioning}
{Reference workspace/brand/positioning.md if loaded}

## Differentiation
{What makes this piece different from what already ranks}
{Proprietary data, unique methodology, practitioner experience}

## Internal Links
- Links TO: {other pieces in the content plan this should link to}
- Links FROM: {other pieces that should link to this one}

## CTA
{What action the reader should take after reading}

## Priority
{DO FIRST / DO SECOND / DO THIRD / QUICK WIN / LONG PLAY}

## Status
planning
```

### Brief Naming Convention

Use lowercase-kebab-case: `{keyword-slug}.md`
- "What is AI marketing" --> `what-is-ai-marketing.md`
- "Best marketing automation tools" --> `best-marketing-automation-tools.md`

### How Many Briefs to Generate

- Generate briefs for all Tier 1 keywords (DO FIRST items)
- Generate briefs for Quick Wins
- Offer to generate Tier 2 briefs if user wants them
- Do not auto-generate Tier 3 or Tier 4 briefs (save for later)

---

## Keyword Plan File Format

The keyword plan saved to `workspace/brand/keyword-plan.md` uses this format:

```markdown
# Keyword Plan

## Last Updated
{YYYY-MM-DD} by /keyword-research

## Business Context
- Offer: {what they sell}
- Audience: {who they serve}
- Goal: {traffic / leads / sales / authority}
- Positioning: {angle from brand memory or user input}

## Pillar Overview

### Pillar 1: {Name} -- Priority: {Critical/High/Medium/Low}
Validation: {PASS/FAIL summary}
Clusters: {N}
Content pieces planned: {N}

| Cluster | Priority | Intent | Content Type | Status |
|---------|----------|--------|--------------|--------|
| {name}  | {H/M/L}  | {type} | {format}     | {status} |
| {name}  | {H/M/L}  | {type} | {format}     | {status} |

### Pillar 2: {Name} -- Priority: {level}
...

## Competitive Landscape
{Summary of competitor content analysis}
{Key gaps identified}

## 90-Day Content Calendar

### Month 1
- Week 1-2: {Flagship piece} -- {Target keyword cluster}
- Week 3: {Supporting piece} -- {Target keyword cluster}
- Week 4: {Supporting piece} -- {Target keyword cluster}

### Month 2
- Week 5-6: {Second pillar piece} -- {Target keyword cluster}
- Week 7: {Supporting piece} -- {Target keyword cluster}
- Week 8: {Supporting piece} -- {Target keyword cluster}

### Month 3
- Week 9-10: {Third pillar piece} -- {Target keyword cluster}
- Week 11: {Supporting piece} -- {Target keyword cluster}
- Week 12: {Supporting piece} -- {Target keyword cluster}

## Content Briefs Generated
| Brief | Path | Priority | Status |
|-------|------|----------|--------|
| {title} | workspace/campaigns/content-plan/{slug}.md | {priority} | planning |

## Search Data Summary
- Autocomplete terms captured: {N}
- PAA questions captured: {N}
- SERPs analyzed: {N}
- Competitor pages reviewed: {N}
- Date of search: {YYYY-MM-DD}
```

---

## Full Terminal Output Template

When presenting the completed keyword plan to the user, use premium formatting:

```
  KEYWORD RESEARCH PLAN
  Generated {Mon DD, YYYY}

  Brand: {name}
  Goal: {traffic / leads / sales / authority}

  {If brand context was loaded:}
  Brand context:
  -- Positioning    loaded
  -- Audience       loaded
  -- Competitors    {N} profiled

  RESEARCH MODE
  -- Web search      {connected | not available}
  -- Data quality:   {LIVE | ESTIMATED}
  -- {If ESTIMATED: "Using estimated data based on
      brand context and training data. Volumes and
      rankings are directional, not verified."}

  RESEARCH SUMMARY

  Seeds generated:          {N}
  Keywords expanded:        {N}
  Autocomplete terms:       {N}
  PAA questions captured:   {N}
  SERPs analyzed:           {N}
  Competitor pages reviewed: {N}

  CONTENT PILLARS

  1. {PILLAR NAME}                    critical
     {N} clusters, {N} content pieces
     Validation: search + market + competitive
     Top keyword: "{keyword}"
     SERP status: {opportunity assessment}

  2. {PILLAR NAME}                      high
     {N} clusters, {N} content pieces
     ...

  TOP OPPORTUNITIES

  Keyword                    Opp    Speed
  {keyword 1}                5/5    Fast
  {keyword 2}                4/5    Fast
  {keyword 3}                4/5    Medium

  COMPETITIVE GAPS

  -- {gap 1 -- topic no competitor covers}
  -- {gap 2 -- topic with weak coverage}
  -- {gap 3 -- topic where you have advantage}

  90-DAY CONTENT CALENDAR

  Month 1
  -- Wk 1-2  {Flagship piece}  --> {target keyword}
  -- Wk 3    {Supporting piece} --> {target keyword}
  -- Wk 4    {Supporting piece} --> {target keyword}

  Month 2
  -- Wk 5-6  {Second pillar}   --> {target keyword}
  -- Wk 7    {Supporting piece} --> {target keyword}
  -- Wk 8    {Supporting piece} --> {target keyword}

  Month 3
  -- Wk 9-10 {Third pillar}    --> {target keyword}
  -- Wk 11   {Supporting piece} --> {target keyword}
  -- Wk 12   {Supporting piece} --> {target keyword}

  START HERE

  {Specific first piece of content to create
  and why -- based on highest opportunity score,
  fastest speed to win, and strongest alignment
  with business goals}

  CONTENT BRIEFS GENERATED

  -- {brief 1}    workspace/campaigns/content-plan/{slug}.md
  -- {brief 2}    workspace/campaigns/content-plan/{slug}.md
  -- {brief 3}    workspace/campaigns/content-plan/{slug}.md

  FILES SAVED

  workspace/brand/keyword-plan.md
  workspace/campaigns/content-plan/{slug-1}.md   (new)
  workspace/campaigns/content-plan/{slug-2}.md   (new)
  workspace/campaigns/content-plan/{slug-3}.md   (new)
  workspace/brand/assets.md                      ({N} entries added)

  WHAT'S NEXT

  Your keyword plan is set with {N} prioritized
  clusters and {N} content briefs ready to write.

  --> /seo-content        Write your first article
                           with your top cluster (~20 min)
  --> /content-atomizer   Repurpose across social
                           channels (~10 min)
  --> /newsletter         Build an edition around
                           your top topics (~15 min)

  Or tell me what you are working on and
  I will route you.
```

---

## Complete Example: Keyword Research for "AI Marketing Consultant"

### Context Gathered

- **Business:** AI marketing consulting for startups
- **Audience:** Funded startups, 10-50 employees, no marketing hire yet
- **Goal:** Leads for consulting engagements
- **Timeline:** Mix of quick wins and authority building
- **Brand memory:** positioning.md loaded (angle: "Practitioner, not theorist"), audience.md loaded, competitors.md loaded (3 competitors profiled)

### Seed Keywords Generated (brand-informed)

- AI marketing consultant
- AI marketing strategy
- Marketing automation
- Startup marketing
- Fractional CMO
- AI marketing tools
- Marketing for funded startups (from audience.md)
- Practitioner marketing (from positioning.md)

### Expanded via 6 Circles (sample)

**Circle 1 (What you sell):** AI marketing consultant, AI marketing strategy, AI marketing audit, marketing automation setup

**Circle 2 (Problems):** startup marketing overwhelm, no time for marketing, marketing not working, can not hire marketing team

**Circle 3 (Outcomes):** automated lead generation, consistent content, marketing ROI, scalable marketing

**Circle 4 (Positioning -- from positioning.md):** practitioner marketing, marketing without theory, real-world marketing strategy, marketing from someone who does it

**Circle 5 (Adjacent -- from audience.md):** startup growth strategies, product-led growth, indie hacker marketing, Series A marketing playbook

**Circle 6 (Entities):** Claude AI marketing, n8n marketing automation, HubSpot alternatives

### Web Search Findings (sample)

**Autocomplete discoveries:**
- "AI marketing consultant" -> "AI marketing consultant for startups", "AI marketing consultant near me", "AI marketing consultant cost"
- "startup marketing" -> "startup marketing strategy 2026", "startup marketing budget", "startup marketing without a team"

**People Also Ask:**
- "How much does an AI marketing consultant cost?"
- "Do I need a marketing team for my startup?"
- "What is fractional marketing?"
- "Can AI replace a marketing team?"

**SERP analysis:**
- "AI marketing consultant": Thin results, no definitive guide. Opportunity.
- "startup marketing strategy": Competitive but top results are 2023-dated.
- "fractional CMO": Moderate competition, mix of agencies and solo consultants.
- "marketing automation for startups": Reddit in top 5. Major content gap.

**Competitor content gaps:**
- Competitor A has no content on "AI marketing for startups"
- Competitor B covers "fractional CMO" but nothing on automation
- None of the 3 competitors have comparison content (vs pages)

### Clustered into Pillars

**Pillar 1: AI Marketing Strategy** (Priority: Critical)
- Validation: search + market + competitive + advantage
- What is AI marketing
- AI marketing examples
- AI marketing tools
- AI marketing for startups
- PAA: "Can AI replace a marketing team?" (standalone article)

**Pillar 2: Marketing Automation** (Priority: High)
- Validation: search + market + competitive + advantage
- Marketing automation for startups
- No-code marketing automation
- n8n vs Zapier for marketing
- Marketing workflow templates
- SERP: Reddit ranking = confirmed content gap

**Pillar 3: Fractional Marketing** (Priority: Medium)
- Validation: search + market + competitive partial + advantage partial
- What is a fractional CMO
- Fractional CMO vs agency
- When to hire fractional marketing
- How much does a fractional CMO cost (from PAA)

### Top 3 Recommendations

**1. "Marketing Automation for Startups" (Do First -- Quick Win)**
- Reddit in top 5 = confirmed content gap
- Specific audience match (from audience.md)
- Competitor B has nothing here
- How-to guide, 2,500+ words

**2. "What is AI Marketing?" (Do Second -- Category Play)**
- Category definition opportunity
- Top results are thin and dated
- Practitioner angle (from positioning.md) differentiates
- Pillar guide, 5,000+ words

**3. "AI Marketing Tools 2026" (Do Third -- Commercial Intent)**
- Commercial intent, close to purchase
- Existing content is generic/outdated
- Unique angle: practitioner reviews, not affiliate lists
- Comparison listicle, 3,000+ words

---

## Free Tools to Supplement

If the user needs additional data validation beyond web search:

- **Google Trends** (trends.google.com) -- Trend direction, seasonality
- **Google Search Console** -- Your actual ranking data
- **Google Search** -- SERP analysis, autocomplete, People Also Ask
- **AnswerThePublic** (free tier) -- Question-based keywords
- **AlsoAsked** (free tier) -- PAA relationship mapping
- **Reddit/Quora search** -- Real user questions and language
- **Ahrefs free tools** -- Limited keyword data
- **Ubersuggest free tier** -- Basic keyword metrics
