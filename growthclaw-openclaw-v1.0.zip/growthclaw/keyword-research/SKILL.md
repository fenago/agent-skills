---
name: keyword-research
description: "Strategic keyword research powered by web search and brand context. Uses the 6 Circles Method to build prioritized content plans from live SERP data."
metadata:
  openclaw:
    emoji: "🔍"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Keyword Research -- Data-Backed Keyword Strategy

Most keyword research is backwards. People start with tools, get overwhelmed by data, and end up with a spreadsheet they never use.

This skill starts with strategy. What does your business need? Who are you trying to reach? What would make them find you? Then it validates with live search data and builds a content plan that actually makes sense.

No expensive tools required. Systematic thinking plus web search.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

---

## Brand Memory Integration

**Reads:** `positioning.md`, `audience.md`, `competitors.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

| File | What it provides | How it shapes output |
|------|-----------------|---------------------|
| `workspace/brand/positioning.md` | Market angles, differentiators | Aligns keyword selection with brand positioning -- a rebel brand targets different keywords than a trusted advisor |
| `workspace/brand/audience.md` | Buyer profiles, sophistication level | Informs search intent mapping -- beginner audience means more "what is" and "how to" keywords |
| `workspace/brand/competitors.md` | Named competitors, their positioning | Seeds competitive content gap analysis -- search what they rank for, find what they miss |

### Writes

| File | What it contains |
|------|-----------------|
| `workspace/brand/keyword-plan.md` | The complete prioritized keyword plan (create-or-overwrite) |
| `workspace/campaigns/content-plan/*.md` | Individual content briefs for top-priority keywords |
| `workspace/brand/assets.md` | Appends entries for each content brief created |

### Context Loading Behavior

1. Check whether `workspace/brand/` exists.
2. If it exists, read `positioning.md`, `audience.md`, and `competitors.md` if present.
3. If loaded, show the user what you found:
   ```
   Brand context loaded:
   -- Positioning     "{primary angle summary}"
   -- Audience        "{audience summary}"
   -- Competitors     {N} competitors profiled

   Using this to shape keyword strategy.
   ```
4. If files are missing, proceed without them. Note at the end:
   ```
   --> /positioning-angles would sharpen keyword alignment
   --> /audience-research would tune intent mapping
   --> /competitive-intel would unlock gap analysis
   ```
5. If no brand directory exists at all:
   ```
   No brand profile found -- this skill works standalone.
   I'll ask what I need as we go. Run /start-here or
   /brand-voice later to unlock personalization.
   ```

---

## Iteration Detection

Before starting, check whether `workspace/brand/keyword-plan.md` already exists.

### If keyword-plan.md EXISTS --> Refresh Mode

Do not start from scratch. Instead:

1. Read the existing plan.
2. Present a summary of the current keyword strategy:
   ```
   EXISTING KEYWORD PLAN
   Last updated {date} by /keyword-research

   Pillars:
   -- {Pillar 1}    {N} clusters    Priority: {level}
   -- {Pillar 2}    {N} clusters    Priority: {level}
   -- {Pillar 3}    {N} clusters    Priority: {level}

   Top keywords:
   -- {keyword 1}   {priority}
   -- {keyword 2}   {priority}
   -- {keyword 3}   {priority}

   Content briefs: {N} created, {N} published

   What would you like to do?

   1. Refresh with new SERP data
   2. Add a new topic area
   3. Re-prioritize existing clusters
   4. Full rebuild from scratch
   5. Generate briefs for top keywords
   ```

3. Process the user's choice:
   - Option 1 --> Re-run web search for existing keywords, update priorities based on fresh data
   - Option 2 --> Gather new seed keywords, run full expansion, merge into existing plan
   - Option 3 --> Re-score all clusters with updated business context
   - Option 4 --> Full process from scratch
   - Option 5 --> Skip to content brief generation for highest-priority unfilled clusters

4. Before overwriting, show a diff of what changed:
   ```
   Changes to keyword plan:

   New clusters added:
   -- "AI email marketing" (Pillar: AI Marketing)
   -- "automated content creation" (Pillar: AI Marketing)

   Priority changes:
   -- "marketing automation" High --> Critical
   -- "fractional CMO" Medium --> Low

   Removed:
   -- "our methodology" (failed validation)

   Save these changes? (y/n)
   ```

5. Only overwrite after explicit confirmation.

### If keyword-plan.md DOES NOT EXIST --> Full Research Mode

Proceed to the full process below.

---

## The Core Job

Transform a business context into a **prioritized content plan** with:
- Keyword clusters organized by topic
- Priority ranking based on opportunity and live SERP data
- Content type recommendations
- Individual content briefs for top keywords
- A clear "start here" action

**Output format:** Clustered keywords mapped to content pieces, prioritized by business value, competitive opportunity, and search demand. Saved to disk as a keyword plan and individual content briefs.

---

## The Process

```
SEED --> EXPAND --> SEARCH --> CLUSTER --> VALIDATE --> PRIORITIZE --> MAP --> BRIEF
```

1. **Seed** -- Generate initial keywords from business context and brand memory
2. **Expand** -- Use the 6 Circles Method to build comprehensive list
3. **Search** -- Pull live SERP data: autocomplete, People Also Ask, competitor rankings
4. **Cluster** -- Group related keywords into content pillars
5. **Validate** -- Run 4-check pillar validation with live competitive data
6. **Prioritize** -- Score by opportunity, business value, and search evidence
7. **Map** -- Assign clusters to specific content pieces
8. **Brief** -- Generate individual content briefs for top priorities

---

## Before Starting: Gather Context

Get these inputs before generating anything. If brand memory files exist, pre-fill what you can and confirm with the user.

1. **What do you sell/offer?** (1-2 sentences)
   - Pre-fill from: `workspace/brand/positioning.md`
2. **Who are you trying to reach?** (Be specific)
   - Pre-fill from: `workspace/brand/audience.md`
3. **What is your website?** (To understand current content)
4. **Who are 2-3 competitors?** (Or help identify them)
   - Pre-fill from: `workspace/brand/competitors.md`
5. **What is the goal?** (Traffic? Leads? Sales? Authority?)
6. **Timeline?** (Quick wins or long-term plays?)

If brand memory supplies 3+ of these, present what you found and ask for confirmation rather than re-asking:

```
  From your brand profile:

  -- Offer       "{from positioning.md}"
  -- Audience    "{from audience.md}"
  -- Competitors {list from competitors.md}
  -- Positioning "{angle from positioning.md}"

  Does this still look right? And two more
  questions:

  1. What is the goal -- traffic, leads, sales,
     or authority?
  2. Timeline -- quick wins or long-term plays?
```

---

## Phase 1: Seed Generation

From the business context (and brand memory if loaded), generate 20-30 seed keywords covering:

**Direct terms** -- What you actually sell
> "AI marketing automation", "fractional CMO", "marketing workflows"

**Problem terms** -- What pain you solve
> "can't keep up with content", "marketing team too small", "don't understand AI"

**Outcome terms** -- What results you deliver
> "faster campaign execution", "10x content production", "marketing ROI"

**Category terms** -- Broader industry terms
> "marketing automation", "AI marketing", "growth marketing"

**Brand-aligned terms** -- From positioning if loaded
> If positioning is "The Anti-Agency" --> seed "agency alternatives", "in-house marketing", "DIY marketing strategy"
> If positioning is "AI-First Marketing" --> seed "AI marketing tools", "automated campaigns", "machine learning marketing"

---

## Phase 2: Expand (The 6 Circles Method)

For each seed keyword, expand using 6 different lenses:

### Circle 1: What You Sell
Products, services, and solutions you offer directly.
> Example: "AI marketing automation", "marketing workflow templates", "fractional CMO services"

### Circle 2: Problems You Solve
Pain points and challenges your audience faces.
> Example: "marketing team overwhelmed", "can't measure marketing ROI", "content takes too long"

### Circle 3: Outcomes You Deliver
Results and transformations customers achieve.
> Example: "automated lead generation", "consistent content publishing", "marketing that runs itself"

### Circle 4: Your Unique Positioning
What makes you different from alternatives.
> Example: "no-code marketing", "AI-first approach", "community-driven marketing"

If `workspace/brand/positioning.md` is loaded, use the actual positioning angles here instead of generic examples. The user's real differentiators should drive Circle 4.

### Circle 5: Adjacent Topics
Related areas where your audience spends time.
> Example: "startup growth", "indie hackers", "solopreneur tools", "productivity systems"

If `workspace/brand/audience.md` is loaded, use the audience's actual communities, interests, and adjacent problems to populate Circle 5.

### Circle 6: Entities to Associate With
People, tools, frameworks, concepts you want to be connected to.
> Example: "Claude AI", "n8n automation", specific thought leaders, industry frameworks

For detailed expansion techniques (question patterns, modifier patterns, comparison patterns), load `references/keyword-methodology.md`.

---

## Phase 3: Web Search Validation

This is the data-backed research layer. For each pillar-level keyword and the top 30-50 expanded keywords, pull live search data.

**This phase has four steps:**

1. **Google Autocomplete Mining** -- Search variations of each keyword to capture real queries people type
2. **People Also Ask Mining** -- Capture PAA questions and second-level follow-ups for each pillar keyword
3. **SERP Analysis** -- Analyze top 5-10 results for priority keywords (content type, freshness, quality, domain authority)
4. **Competitor Content Analysis** -- Map what competitors rank for and identify content gaps

For detailed methodology, search templates, and signal interpretation for each step, load `references/keyword-methodology.md`.

### Search Integration Output

After web search, present findings before clustering:

```
  WEB RESEARCH COMPLETE

  Autocomplete suggestions:   {N} unique terms
  People Also Ask questions:  {N} captured
  SERPs analyzed:             {N} keywords
  Competitor pages reviewed:  {N} pages

  TOP DISCOVERIES

  -- {discovery 1}
  -- {discovery 2}
  -- {discovery 3}

  NEW KEYWORDS ADDED FROM SEARCH

  -- {keyword from autocomplete}
  -- {keyword from PAA}
  -- {keyword from competitor gap}
  -- +{N} more added to expanded list
```

---

## Phase 4: Cluster

Group expanded keywords (including web search discoveries) into content pillars using the hub-and-spoke model:

```
                    [PILLAR]
                 Main Topic Area
                      |
        +-------------+-------------+
        |             |             |
   [CLUSTER 1]   [CLUSTER 2]   [CLUSTER 3]
    Subtopic       Subtopic       Subtopic
        |             |             |
    Keywords      Keywords      Keywords
```

For each cluster, capture:
- Semantic grouping of related keywords
- Search intent alignment
- The pillar keyword (broadest term)
- Supporting keywords (more specific variations)
- Associated PAA questions
- Competitor coverage status

For detailed clustering process and examples, load `references/keyword-methodology.md`.

---

## Phase 5: Pillar Validation (Critical Step)

**Before finalizing pillars, run these 4 checks.** Most keyword research fails because pillars are chosen based on what the business WANTS to talk about, not what the market ACTUALLY searches for. Live search data validates this.

**1. Search Volume Test** -- Does this pillar have >1,000 monthly searches across its keyword cluster?

**2. Product vs. Market Test** -- Is this pillar something the MARKET searches for, or something YOU want to talk about? The market does not search for your product name (unless you are famous). They search for solutions to their problems.

**3. Competitive Reality Test** -- Can you actually win here? Check the top 3 results. All DR 80+ sites? Find adjacent pillar. Reddit/forums in results? Huge opportunity.

**4. Proprietary Advantage Test** -- Do you have unique content, data, or expertise for this pillar? Proprietary data and unique methodology should be prioritized highly.

**If a pillar fails 2+ tests, it is not a pillar.** Either demote it to a single article within another pillar, or remove it entirely.

For detailed validation criteria, example outputs, and the Product vs. Market comparison table, load `references/keyword-methodology.md`.

---

## Phase 6: Prioritize

Not all keywords are equal. Score each cluster using both strategic assessment AND live search evidence from Phase 3.

### Business Value (High / Medium / Low)

**High:** Direct path to revenue -- commercial intent keywords, close to purchase decision, your core offering.

**Medium:** Indirect path -- builds trust and authority, captures leads, educational content.

**Low:** Brand awareness only -- top of funnel, tangentially related, nice to have.

### Opportunity (High / Medium / Low)

**High opportunity signals (from web search data):**
- No good content exists (you would define the category)
- Existing content is outdated (2+ years old in SERP)
- Existing content is thin (surface-level, generic)
- You have unique angle competitors miss
- Reddit/forums in top results (content gap confirmed)
- Growing trend (autocomplete suggestions expanding)
- Competitors have not covered this topic

**Low opportunity signals:**
- Dominated by major authority sites (DR 80+)
- Excellent comprehensive content already exists
- Highly competitive commercial terms
- Declining interest
- All competitors have strong content here

### Speed to Win (Fast / Medium / Long)

**Fast (3 months):** Low competition confirmed by SERP, unique expertise/data, content gap is clear.

**Medium (6 months):** Moderate competition, requires comprehensive content, differentiation path exists.

**Long (9-12 months):** High competition, requires authority building, may need link building.

### Priority Matrix

| Business Value | Opportunity | Speed | Priority |
|---------------|-------------|-------|----------|
| High | High | Fast | DO FIRST |
| High | High | Medium | DO SECOND |
| High | Medium | Fast | DO THIRD |
| Medium | High | Fast | QUICK WIN |
| High | Low | Any | LONG PLAY |
| Low | Any | Any | BACKLOG |

---

## Phase 7: Map to Content

For each priority cluster, assign content type and calendar placement.

### Content Type

| Type | When to Use | Word Count |
|------|-------------|------------|
| Pillar Guide | Comprehensive topic coverage | 5,000-8,000 |
| How-To Tutorial | Step-by-step instructions | 2,000-3,000 |
| Comparison | X vs Y, Best [category] | 2,500-4,000 |
| Listicle | Tools, examples, tips | 2,000-3,000 |
| Use Case | Industry or scenario specific | 1,500-2,500 |
| Definition | What is [term] | 1,500-2,500 |

### Intent Matching

| Intent | Keyword Signals | Content Approach | CTA Type |
|--------|-----------------|------------------|----------|
| Informational | what, how, why, guide | Educate thoroughly | Newsletter, resource |
| Commercial | best, vs, review, compare | Help them decide | Free trial, demo |
| Transactional | buy, pricing, get, hire | Make it easy | Purchase, contact |

### Content Calendar Placement

**Tier 1 (Publish in weeks 1-4):** Highest priority, category-defining
**Tier 2 (Publish in weeks 5-8):** High priority, supporting pillars
**Tier 3 (Publish in weeks 9-12):** Medium priority, depth content
**Tier 4 (Backlog):** Lower priority, future opportunities

### PAA-Driven Content Structure

For each content piece, use PAA questions to build the outline:

```
Article: "What is AI Marketing Automation?"

  Sections derived from PAA:
  -- H2: How does AI help marketing?
  -- H2: Is AI marketing automation worth it?
  -- H2: What are the best AI marketing tools?
  -- H2: How to get started with AI marketing
```

Each PAA question becomes an H2. This aligns your content structure with what Google knows people are asking.

---

## Phase 8: Content Brief Generation

For each top-priority keyword cluster, generate an individual content brief and save it to `workspace/campaigns/content-plan/`.

For the complete content brief template, naming conventions, and generation rules, load `references/keyword-methodology.md`.

---

## Chain to /seo-content

After presenting the keyword plan, actively offer to chain into content creation for the top-priority keyword:

```
  READY TO WRITE?

  Your top-priority keyword is "{keyword}" with
  a content brief ready at
  workspace/campaigns/content-plan/{slug}.md

  I can write this article now using /seo-content.
  It will use your brand voice, the content brief,
  and the SERP data I just gathered.

  --> "Write it" to start /seo-content now
  --> "Not yet" to save the plan and stop here
```

If the user says "write it" or similar, hand off to /seo-content with:
- The content brief file path
- The keyword plan context
- The SERP analysis from Phase 3
- Brand memory context already loaded

---

## What This Skill Does NOT Do

This skill provides **strategic direction backed by search data**, not:
- Exact search volume numbers (use paid tools like Ahrefs for precision)
- Automated rank tracking (different tool category)
- Content writing (use /seo-content skill after brief generation)
- Technical SEO audits (different skill set)
- Link building strategy (separate from content strategy)

The output is a validated, prioritized plan with content briefs. Execution is handled by /seo-content and other downstream skills.

---

## How This Skill Connects to Others

**keyword-research** identifies WHAT to write about and creates the content plan.

Then:
- **/seo-content** --> Writes individual articles using the content briefs
- **/positioning-angles** --> Finds the angle for each piece (or informs keyword selection)
- **/brand-voice** --> Ensures consistent voice across all content
- **/direct-response-copy** --> Writes landing pages for commercial-intent keywords
- **/content-atomizer** --> Repurposes pillar content into social, email, etc.
- **/lead-magnet** --> Creates lead magnets aligned with top-of-funnel keywords

The keyword research creates the content strategy. Other skills execute it.

---

## Complete Invocation Flow

```
  /keyword-research invoked
  |
  +-- Check workspace/brand/ directory
  |   +-- Load positioning.md (if exists)
  |   +-- Load audience.md (if exists)
  |   +-- Load competitors.md (if exists)
  |
  +-- Check workspace/brand/keyword-plan.md
  |   +-- EXISTS --> Refresh Mode
  |   |   +-- Show current plan summary
  |   |   +-- Ask what to change
  |   |   +-- Process choice (refresh / add / re-prioritize / rebuild / brief)
  |   |   +-- Run web search for changes
  |   |   +-- Show diff, confirm overwrite
  |   |   +-- Save updated plan + new briefs
  |   |
  |   +-- DOES NOT EXIST --> Full Research Mode
  |       +-- Gather context (pre-fill from brand memory)
  |       +-- Phase 1: Seed Generation (20-30 seeds)
  |       +-- Phase 2: Expand (6 Circles Method, 100-200 keywords)
  |       +-- Phase 3: Web Search Validation
  |       +-- Phase 4: Cluster (5-10 pillars, hub-and-spoke)
  |       +-- Phase 5: Pillar Validation (4 checks)
  |       +-- Phase 6: Prioritize (business value x opportunity x speed)
  |       +-- Phase 7: Map to Content (type, intent, calendar tier)
  |       +-- Phase 8: Content Brief Generation (Tier 1 + Quick Wins)
  |
  +-- Save outputs
  |   +-- workspace/brand/keyword-plan.md
  |   +-- workspace/campaigns/content-plan/*.md (briefs)
  |   +-- workspace/brand/assets.md (append brief entries)
  |
  +-- Present formatted output
  +-- Chain offer: Write top article with /seo-content?
  +-- Feedback Collection
```

---

## Error States

### Web search not available

```
  WEB SEARCH UNAVAILABLE

  Web search tools are not available in this
  environment. I can still build a keyword
  plan using the 6 Circles Method and
  strategic analysis -- but without live
  SERP validation.

  --> Continue without search data
  --> Provide competitor URLs and I will work
      with what you give me
```

When web search is unavailable, skip Phase 3 and run the process without live data (Phases 1, 2, 4-7). Show the RESEARCH MODE signal with "Data quality: ESTIMATED". Tell the user you are using estimated data based on training knowledge rather than live search results. Prefix all volume and ranking estimates with ~ to indicate they are directional. Recommend the user manually check top results for priority keywords.

### No business context available

```
  NEED BUSINESS CONTEXT

  I need to understand your business before
  researching keywords. No brand profile
  found and no context provided.

  --> Tell me what you sell and who you serve
  --> /start-here to build your full profile
  --> /brand-voice to start with voice
```

### Competitor URLs not accessible

```
  COMPETITOR ANALYSIS LIMITED

  Could not access content from {N} of {M}
  competitor URLs. Proceeding with available
  data.

  Accessible:
  -- {competitor 1}    accessible
  -- {competitor 2}    blocked

  --> Continue with partial data
  --> Provide alternative competitor URLs
```

---

## Implementation Notes for the LLM

When executing this skill, follow these rules precisely:

1. **Never skip the iteration check.** Always look for an existing keyword-plan.md before starting a new plan.

2. **Never skip web search when available.** The differentiator is data-backed research. If web search tools are available, use them. Phase 3 is not optional -- it is what makes this skill worth paying for.

3. **Show your work.** When loading brand context, say what you loaded. When searching, show what you found. When analyzing SERPs, name the patterns. The user should feel like they are working with a senior content strategist, not a keyword generator.

4. **Preserve the 6 Circles Method.** This is the strategic core. Web search enhances it, does not replace it. Always run 6 Circles expansion before web search validation.

5. **Pillar validation is mandatory.** Do not skip the 4-check validation. With live SERP data, the validation is even more powerful -- use it. If a pillar fails 2+ tests, demote or remove it regardless of how "on-brand" it feels.

6. **Generate content briefs for top priorities.** Do not just list keywords. The briefs in `workspace/campaigns/content-plan/` are what make this skill actionable. Every Tier 1 keyword should have a brief.

7. **Respect the brand memory protocol.** Read before write. Diff before overwrite. Confirm before save. Append to assets.md, never overwrite.

8. **PAA questions are gold.** People Also Ask questions are real queries from real people. Always capture them and map them to content outlines. They become H2s in your content briefs.

9. **The chain to /seo-content is the handoff.** Always offer it. The keyword plan is strategy. /seo-content is execution. The faster the user moves from plan to content, the more value they get.

10. **Write file paths correctly.** The plan saves to `workspace/brand/keyword-plan.md`. Briefs save to `workspace/campaigns/content-plan/{slug}.md`. The exact paths matter for cross-skill references.

11. **When web search is unavailable, gracefully degrade.** Fall back to the process without live data (6 Circles + strategic analysis). Note the limitation. The skill should still produce valuable output without search data -- it just will not have SERP validation.

12. **Use brand positioning to differentiate, not to dictate topics.** The positioning angle tells you HOW to write about a topic, not WHAT topics to target. "The Anti-Agency" writes about "marketing strategy" (market term) with an anti-agency angle -- it does not target "anti-agency" as a keyword.

---

## The Test

A good keyword research output:

1. **Data-backed** -- Claims are supported by SERP evidence, not just intuition
2. **Actionable** -- Clear "start here" recommendation with a content brief ready
3. **Prioritized** -- Not just a list, but ranked by opportunity and evidence
4. **Realistic** -- Acknowledges competition based on actual SERP analysis
5. **Strategic** -- Connects to business goals and brand positioning
6. **Specific** -- Content types, angles, and outlines, not just keywords
7. **Executable** -- Content briefs ready to hand to /seo-content

If the output is "here's 500 keywords, good luck" -- it failed.

---

## Feedback Collection

After the keyword plan is saved and content briefs are generated, present the standard feedback prompt:

```
  How did this land?

  a) Great -- plan is clear and actionable
  b) Good -- made some priority adjustments
  c) Needs significant rework
  d) Have not started executing yet

  (You can answer later -- just run
  /keyword-research again and tell me.)
```

### Processing Feedback

**If (a) "Great":**
- Log to `workspace/brand/learnings.md` under "What Works"

**If (b) "Good -- made adjustments":**
- Ask: "What did you change? Even small priority shifts help me calibrate."
- Log the change to learnings.md.
- Offer to update the plan.

**If (c) "Needs significant rework":**
- Ask: "What felt off? Was it the topics, the priorities, the competitive analysis, or something else?"
- If topics were wrong, suggest re-running with different seed keywords.
- If priorities were off, suggest re-running Phase 6 with updated business context.

**If (d) "Have not started executing":**
- Note it. Do not log yet.
- Next time /keyword-research runs, remind: "Last time I built a keyword plan with {N} briefs. Have you started writing?"
