---
name: email-sequences
description: "Build email sequences that convert subscribers into customers â welcome, nurture, sales, launch, and re-engagement."
metadata:
  openclaw:
    emoji: "ð§"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Email Sequences

Most lead magnets die in the inbox. Someone downloads your thing, gets one "here's your download" email, and never hears from you again. Or worse -- they get blasted with "BUY NOW" emails before you've earned any trust.

The gap between "opted in" and "bought" is where money is made or lost. This skill builds sequences that bridge that gap.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

---

## Brand Memory Integration

This skill reads brand context to make every email sound like your brand and align with your positioning. It also checks whether a lead magnet has already been created, so it can build the sequence around specific deliverable details rather than generic placeholders.

**Reads:** `voice-profile.md`, `positioning.md`, `audience.md`, `creative-kit.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

1. **Load `voice-profile.md`** (if exists):
   - Match the brand's tone, vocabulary, sentence rhythm in every email
   - Apply the voice DNA: sentence length patterns, jargon level, formality register
   - Show: "Your voice is [tone summary]. All emails will match that register."

2. **Load `positioning.md`** (if exists):
   - Use the chosen angle as the narrative spine of the sequence
   - Show: "Your positioning angle is '[angle]'. Building the sequence around that frame."

3. **Load `audience.md`** (if exists):
   - Know who is receiving these emails: their awareness level, sophistication, pain points
   - Use audience data to inform send timing recommendations (B2B vs B2C, timezone, habits)
   - Show: "Writing for [audience summary]. Awareness: [level]."

4. **Load `creative-kit.md`** (if exists):
   - Pull brand colors for HTML email templates if ESP integration is active
   - Show: "Creative kit loaded -- brand colors and visual identity available for templates."

5. **Check for lead magnet output** (if `workspace/campaigns/*/brief.md` or `workspace/brand/assets.md` references a lead magnet):
   - If /lead-magnet was already run, use the actual lead magnet name, format, and delivery URL
   - Show: "Found lead magnet: '[name]'. Building delivery email around the actual asset."

6. **If `workspace/brand/` does not exist:**
   - Skip brand loading entirely. Do not error.
   - Proceed without it -- this skill works standalone.
   - Note: "I don't see a brand profile yet. You can run /start-here or /brand-voice first to set one up, or I'll work without it."

### Context Loading Display

Show the user what was loaded using the standard tree format:

```
Brand context loaded:
âââ Voice Profile     â "{tone summary}"
âââ Positioning       â "{primary angle}"
âââ Audience          â "{audience summary}"
âââ Creative Kit      â loaded
âââ Lead Magnet       â "{lead magnet name}" (from /lead-magnet)
âââ Learnings         â {N} entries
```

If files are missing, show them as â with a suggestion:

```
âââ Voice Profile     â not found
â   â /brand-voice to create one (~10 min)
```

---

## ESP Detection

Before generating the sequence, check for email service provider integrations. This determines the output format.

### Detection Order

1. **Check `workspace/brand/stack.md`** (if exists) -- look for ESP entries in the Connected Tools table.
2. **Check `.env`** -- scan for these environment variables:
   - `MAILCHIMP_API_KEY` or `MAILCHIMP_SERVER_PREFIX` -- Mailchimp
   - `CONVERTKIT_API_KEY` or `CONVERTKIT_API_SECRET` -- ConvertKit
   - `HUBSPOT_API_KEY` or `HUBSPOT_ACCESS_TOKEN` -- HubSpot
   - `SENDGRID_API_KEY` -- SendGrid
   - `ACTIVECAMPAIGN_API_KEY` -- ActiveCampaign
3. **Check for MCP servers** -- query available MCP tools for email-related capabilities.

### Output Based on Detection

**If ESP detected:**
```
ESP Detection
âââ Mailchimp         â connected (API key found)
â
â   I can create this automation directly in
â   Mailchimp. Want me to set it up, or output
â   copy-paste-ready files?
â
â   â "Set it up"     Create automation via API
â   â "Just the copy" Output as markdown files
```

**If no ESP detected:**
```
ESP Detection
âââ Mailchimp         â not found
âââ ConvertKit        â not found
âââ HubSpot           â not found
âââ No ESP connected

Outputting in copy-paste-ready format.
Each email saved as a separate .md file you
can paste into any email platform.

â To connect an ESP, add your API key to .env
```

---

## Iteration Detection

Before starting, check if an email sequence already exists for this project.

### If campaign email files exist in `workspace/campaigns/{name}/emails/`

Do not start from scratch. Instead:

1. Read the existing email files.
2. Present a summary of what exists.
3. Ask: "Do you want to revise this sequence, add emails, or start a new one?"

### If no campaign email files exist

Proceed directly to sequence generation.

---

## The Core Job

Transform a lead magnet subscriber into a customer through a **strategic email sequence** that:
- Delivers immediate value (the lead magnet)
- Builds trust and relationship
- Creates desire for the paid offer
- Converts without being sleazy

**Output format:** Complete email sequences with subject line A/B variants, preview text, full copy, send timing with specific day/time recommendations, and CTAs. Each email saved as an individual file.

---

## Sequence Types

| Sequence | Purpose | Length | When to Use |
|----------|---------|--------|-------------|
| **Welcome** | Deliver value, build relationship | 5-7 emails | After opt-in |
| **Nurture** | Provide value, build trust | 4-6 emails | Between welcome and pitch |
| **Conversion** | Sell the product | 4-7 emails | When ready to pitch |
| **Launch** | Time-bound campaign | 6-10 emails | Product launch |
| **Re-engagement** | Win back cold subscribers | 3-4 emails | Inactive 30+ days |
| **Post-Purchase** | Onboard, reduce refunds, upsell | 4-6 emails | After purchase |

---

## Before Starting: Gather Context

Get these inputs before writing any sequence:

1. **What's the lead magnet?** (Check `workspace/brand/assets.md` and `workspace/campaigns/*/brief.md` for existing lead magnet details. If /lead-magnet was already run, use those specifics instead of asking.)
2. **What's the paid offer?** (What are you eventually selling?)
3. **What's the price point?** (Affects how much trust-building needed)
4. **What's the bridge?** (How does free to paid make logical sense?)
5. **What voice/brand?** (Load from `workspace/brand/voice-profile.md` or ask)
6. **What objections?** (Why might they NOT buy?)

If brand memory provides answers, confirm them with the user rather than re-asking.

---

## The Welcome Sequence (5-7 emails)

This is the most important sequence. First impressions compound.

### The Framework: DELIVER -> CONNECT -> VALUE -> BRIDGE

```
Email 1: DELIVER -- Give them what they came for
Email 2: CONNECT -- Share your story, build rapport
Email 3: VALUE -- Teach something useful (quick win)
Email 4: VALUE -- Teach something else (builds authority)
Email 5: BRIDGE -- Show what's possible with more help
Email 6: SOFT PITCH -- Introduce the offer gently
Email 7: DIRECT PITCH -- Make the ask
```

### Email 1: Delivery (Send immediately)

**Purpose:** Deliver the lead magnet, set expectations, get first micro-engagement.

**Subject line formulas:**
- "[Lead magnet name] is inside"
- "Your [lead magnet] + quick start guide"
- "Here's [what they asked for]"

**Structure:**
```
[Greeting -- keep it simple]
[Deliver the goods -- link to lead magnet]
[Quick start -- one action they can take in next 5 minutes]
[Set expectations -- what emails are coming]
[Micro-CTA -- hit reply, answer a question, or take one action]
[Sign off]
```

### Email 2: Connection (Day 2)

**Purpose:** Build rapport through vulnerability and shared experience.

**Subject line formulas:**
- "Why I created [lead magnet]"
- "The mistake that led to this"
- "Quick story about [topic]"

**Structure:**
```
[Story hook -- specific moment or realization]
[The struggle -- what you went through]
[The insight -- what you learned]
[The connection -- how this relates to them]
[Soft forward reference -- hint at what's coming]
[Sign off]
```

### Email 3: Value (Day 4)

**Purpose:** Teach something useful. Demonstrate expertise. Create a quick win.

**Subject line formulas:**
- "The [X] mistake everyone makes"
- "Try this: [specific tactic]"
- "What [person] discovered about [topic]"

**Structure:**
```
[Hook -- insight or observation]
[The problem -- what most people get wrong]
[The solution -- what to do instead]
[Example or proof -- show it working]
[Action step -- what they can do right now]
[Sign off]
```

### Email 4: More Value (Day 6)

**Purpose:** Continue building trust. Different angle or topic.
Same structure as Email 3, different topic.

### Email 5: Bridge (Day 8)

**Purpose:** Show the gap between where they are and where they could be. Introduce concept of the paid offer without pitching.

**Subject line formulas:**
- "You can [do X] now. But can you [do Y]?"
- "The next step most people miss"
- "What [lead magnet] doesn't do"

**Structure:**
```
[Acknowledge progress -- what they can now do with the lead magnet]
[Reveal the gap -- what they still can't do]
[Paint the picture -- what's possible with the full solution]
[Soft mention -- the offer exists, no hard sell]
[Sign off]
```

### Email 6: Soft Pitch (Day 10)

**Purpose:** Introduce the offer properly. Handle objections. Let them self-select.

**Structure:**
```
[Transition -- building on bridge email]
[The offer -- what it is, what's included]
[Who it's for -- specific situations]
[Who it's NOT for -- disqualification]
[Social proof -- if available]
[The ask -- soft CTA, no urgency yet]
[Sign off]
```

### Email 7: Direct Pitch (Day 12)

**Purpose:** Make the clear ask. Create urgency if authentic.

**Structure:**
```
[Direct opener -- no buildup]
[Restate core value -- one sentence]
[Handle remaining objection -- the big one]
[Urgency -- if real (price increase, bonus deadline, limited)]
[Clear CTA -- exactly what to do]
[Final thought -- personal note]
[Sign off]
```

---

## The Conversion Sequence (4-7 emails)

For when you're ready to pitch -- either after welcome sequence or as a standalone campaign.

### The Framework: OPEN -> DESIRE -> PROOF -> OBJECTION -> URGENCY -> CLOSE

```
Email 1: OPEN -- Introduce the offer, core promise
Email 2: DESIRE -- Paint the transformation, show the gap
Email 3: PROOF -- Testimonials, case studies, results
Email 4: OBJECTION -- Handle the biggest "but..."
Email 5: URGENCY -- Why now matters (if authentic)
Email 6: CLOSE -- Final push, clear CTA
Email 7: LAST CALL -- Deadline reminder (if applicable)
```

### Timing
- Standard: Every 2 days
- Launch: Daily or every other day
- Deadline: Final 3 emails in 3 days

---

## The Launch Sequence (6-10 emails)

For time-bound campaigns: product launches, promotions, cohort opens.

### The Framework: SEED -> OPEN -> VALUE -> PROOF -> URGENCY -> CLOSE

**Pre-Launch (1-2 emails):** Seed interest, build anticipation
**Cart Open (2-3 emails):** Announcement, full details, value deep-dive
**Mid-Launch (2-3 emails):** Objection handling, case study, FAQ
**Cart Close (2-3 emails):** Urgency, final testimonial, last call

### Launch Email Timing
```
Day -3: Seed (optional)
Day -1: Coming tomorrow
Day 0: Cart open (morning + evening, different angle)
Day 2: Deep-dive on value
Day 4: Social proof
Day 5: Objection handling
Day 6: 48-hour warning
Day 7: 24-hour warning (morning) + Final hours (evening) + Last call (before midnight)
```

---

## The Re-engagement Sequence (3-4 emails)

For subscribers who haven't opened in 30+ days.

### The Framework: PATTERN INTERRUPT -> VALUE -> DECISION

```
Email 1: Pattern interrupt -- different subject line style, acknowledge absence
Email 2: Pure value -- best content, no ask
Email 3: Direct question -- do you want to stay?
Email 4: Final -- removing from list (creates urgency)
```

---

## Subject Line Framework

### What Gets Opens

**1. Curiosity Gap:** "The [X] mistake that cost me [Y]"
**2. Direct Benefit:** "How to [outcome] in [timeframe]"
**3. Personal/Story:** "Quick story about [topic]"
**4. Question:** "Can I ask you something?"
**5. Urgency (when real):** "[X] hours left"
**6. Pattern Interrupt:** "." (just a period), "So...", "Bad news"

### What Kills Opens
- ALL CAPS, excessive punctuation, "Newsletter #47", clickbait that doesn't deliver, same format every time

### Three-Variant Framework

For each email, produce exactly 3 subject line variants:

**Variant A -- The Safe Bet:** Proven formula, optimized for open rate.
**Variant B -- The Bold Play:** Higher risk/reward. Pattern interrupt, curiosity, or emotion.
**Variant C -- The Personal Touch:** Feels like a message from a friend.

### Subject Line Rules
- Maximum 50 characters (full mobile display)
- No emoji unless brand voice explicitly calls for it
- Preview text must complement, not repeat, the subject
- Each variant must use a DIFFERENT formula category

---

## Email Copy Principles

### The P.S. Is Prime Real Estate
40% of people read the P.S. first. Use it for the core CTA, a second hook, or a deadline reminder.

### One CTA Per Email
Multiple CTAs = no CTAs. Every email should have ONE clear action.

### Short Paragraphs
1-3 sentences max. Email is scanned, not read.

### Preview Text Matters
First 40-90 characters appear in inbox preview. Make them count.

### Open Loops
Create curiosity within emails: "I'll explain why tomorrow."

### Specificity Creates Credibility
Not "made money" -- "$47,329 in one day". Not "recently" -- "Last Tuesday."

---

## Sequence Architecture Patterns

### The Straight Line
```
Email 1 -> Email 2 -> Email 3 -> Email 4 -> Pitch
```

### The Branch
```
Email 1 -> Email 2 -> [Clicked?] -> YES: Pitch sequence
                                 -> NO: More value sequence
```

### The Hybrid
```
Welcome (5 emails) -> [Wait 7 days] -> Conversion (5 emails) -> [No purchase] -> Nurture (ongoing)
```

---

## Send Timing Recommendations

### Timing by Sequence Type

| Sequence | Frequency | Notes |
|----------|-----------|-------|
| Welcome | Days 0, 2, 4, 6, 8, 10, 12 | Front-load value |
| Nurture | Weekly or 2x/week | Consistent rhythm |
| Conversion | Every 2 days | Enough touch without annoying |
| Launch | Daily or every other day | Intensity justified by deadline |
| Re-engagement | Days 0, 3, 7, 10 | Give time to respond |

### Best Send Times by Audience Type

**B2B:** Tuesday-Thursday, 9:00-10:30 AM recipient's timezone. Second window: 1:00-2:00 PM.
**B2C:** Tuesday-Thursday, 7:00-9:00 AM or 7:00-9:00 PM.
**Creator/solopreneur:** Tuesday-Wednesday, 7:00-8:30 AM.
**Ecommerce:** Thursday-Friday, Sunday. Cart abandonment: 1 hour, 24 hours, 72 hours.

### When to Start Selling
- Low price (<$100): After 3-5 value emails
- Medium price ($100-500): After 5-7 value emails
- High price (>$500): After 7-10 value emails or sales call

---

## Individual File Output

Every email in the sequence is saved as a separate file. This enables the user to iterate on individual emails, import them one at a time into ESPs, and maintain version control.

### Directory Structure

```
workspace/campaigns/{sequence-name}/
  brief.md                           <- Campaign overview
  emails/
    01-delivery.md                   <- Email 1
    02-connection.md                 <- Email 2
    ...
```

### Naming Convention

Files use the pattern: `{nn}-{purpose}.md`

Standard purpose names by sequence type:

**Welcome:** 01-delivery, 02-connection, 03-quick-win, 04-value-story, 05-bridge, 06-soft-pitch, 07-direct-pitch
**Conversion:** 01-open, 02-desire, 03-proof, 04-objection, 05-urgency, 06-close, 07-last-call
**Launch:** 01-seed, 02-announcement, 03-value-dive, 04-social-proof, 05-objection, 06-48hr-warning, 07-24hr-warning, 08-final-hours, 09-last-call
**Re-engagement:** 01-pattern-interrupt, 02-pure-value, 03-direct-question, 04-final-notice
**Post-purchase:** 01-welcome-aboard, 02-quick-start, 03-first-win, 04-advanced-tip, 05-community, 06-upsell

### Individual Email File Format

Each email .md file must contain this frontmatter and structure:

```markdown
---
email: {N}
sequence: {sequence-name}
purpose: {one-line purpose}
send_day: {N}
send_time: "{Day, Time TZ}"
subject_line_a: "{Subject A}"
subject_line_b: "{Subject B}"
subject_line_c: "{Subject C}"
recommended_subject: "a"
preview_text: "{preview text for recommended subject}"
cta: "{what action you want}"
status: draft
---

# Email {N}: {Purpose Title}

## Subject Line Variants

### A: "{Subject A}" -- recommended
{Rationale}

### B: "{Subject B}"
{Rationale}

### C: "{Subject C}"
{Rationale}

**Recommended A/B test:** A vs B
**Reason:** {why testing these two is informative}

## Preview Text
"{preview text -- first 60-90 characters}"

## Send Timing
Day {N} -- {Day of Week} at {Time} {TZ}
{Rationale for this timing}

---

## Email Copy

{FULL EMAIL COPY HERE}

---

**P.S.** {If applicable}
```

---

## Campaign Brief

Every sequence gets a `brief.md` in the campaign directory:

```markdown
# Campaign: {Sequence Name}

## Goal
{What this sequence accomplishes}

## Sequence Type
{Welcome / Nurture / Conversion / Launch / Re-engagement / Post-Purchase}

## Emails
{N} emails over {N} days

## Angle
{The positioning angle being used}

## Audience Segment
{Who receives this sequence}

## Lead Magnet
{What they opted in for}

## Paid Offer
{What we are eventually selling, at what price}

## Bridge Logic
{How free -> paid makes logical sense}

## ESP
{Connected ESP or "manual / copy-paste"}

## Status
draft
```

---

## Campaign Summary Output

After generating the full sequence, display a summary overview showing the bird's-eye view including: sequence overview (each email's subject, purpose, CTA, timing), sequence architecture pattern, ESP status, files saved list, and what's next suggestions.

Suggest chaining to:
- /creative for HTML email templates or visual assets
- /content-atomizer for social promotion of the lead magnet
- /direct-response-copy for the offer landing page
- /lead-magnet if the opt-in asset hasn't been created yet

---

## How This Connects to Other Skills

**email-sequences uses:**
- **brand-voice** -- Ensures email voice matches brand
- **positioning-angles** -- The angle informs the pitch
- **lead-magnet** -- The sequence delivers the lead magnet
- **direct-response-copy** -- Individual emails use copy principles

**email-sequences feeds:**
- **content-atomizer** -- Best emails can become social content
- **newsletter** -- Sequence insights inform newsletter strategy

---

## Recording Feedback

After delivering the sequence, present the standard feedback prompt. Process responses:
- "Great -- shipped as-is": Log to `workspace/brand/learnings.md`
- "Good -- minor edits": Ask what they changed, log the change
- "Rewrote significantly": Ask for the diff, suggest re-running /brand-voice
- "Haven't used yet": Note it, do not log

### Subject Line Performance Tracking

If the user reports A/B test results, log to `workspace/brand/learnings.md`. This data accumulates over time and informs future variant recommendations.

---

## References

For complete example sequences, extended subject line variations, detailed per-ESP setup guides, and A/B testing methodology, see:

- `references/email-templates.md` -- Full example sequences and extended frameworks

---

## The Test

A good email sequence:

1. **Delivers value before asking** -- At least 3-5 value emails before pitch
2. **Has clear purpose per email** -- Each email does ONE job
3. **Sounds human** -- Not corporate, not guru, not AI
4. **Creates momentum** -- Each email makes them want the next
5. **Handles objections** -- Addresses the "but..." before they think it
6. **Has one CTA** -- Every email drives one action
7. **Respects the reader** -- Not manipulative
8. **Has subject line options** -- 3 variants per email
9. **Has specific timing** -- Day, time, and rationale
10. **Lives in individual files** -- Each email standalone, importable, iterable

If the sequence feels like "content, content, content, BUY NOW BUY NOW" -- it failed.
