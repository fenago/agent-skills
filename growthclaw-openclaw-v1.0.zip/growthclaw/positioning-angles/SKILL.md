---
name: positioning-angles
description: "Find the angle that makes something sell. Searches competitor messaging, maps the saturated landscape, then generates 3-5 distinct angles with a starred recommendation."
metadata:
  openclaw:
    emoji: "🎯"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Positioning & Angles

The same product can sell 100x better with a different angle. Not a different product. Not better features. Just a different way of framing what it already does.

This skill finds those angles.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

For positioning theory deep-dives, load the following references as needed:
- For angle generation frameworks (Halbert, Ogilvy, Hopkins, Bencivenga, Kennedy), load `references/angle-frameworks.md`.
- For market sophistication assessment, load `references/schwartz-sophistication.md`.
- For 5-component positioning methodology, load `references/dunford-positioning.md`.
- For value equation and Grand Slam Offer thinking, load `references/hormozi-offer.md`.
- For finding and naming your mechanism, load `references/unique-mechanism.md`.

---

## Brand Memory Integration

**Reads:** `audience.md`, `competitors.md` (if they exist)

On invocation, check for `workspace/brand/` and load available context:

1. **Check for `workspace/brand/positioning.md`** -- if it exists, this is an update session:
   - Read the existing positioning file
   - Display the current primary angle and any saved alternatives
   - Ask: "You already have positioning on file. Do you want to refine it with fresh data, or start from scratch?"
   - "Refine" -- load existing angles, run competitive search for new data, suggest adjustments
   - "Start fresh" -- run the full process below as if no positioning exists

2. **Load `audience.md`** (if exists):
   - Use audience segments, pain points, and language patterns to inform angle generation
   - Show: "I see your audience profile -- [brief summary]. Using that to shape angles."

3. **Load `competitors.md`** (if exists):
   - Use known competitors as starting seeds for the competitive web search step
   - Show: "I found [N] competitors in your brand memory. Starting search from there."

4. **Load `voice-profile.md`** (if exists):
   - Use voice DNA to ensure angle language matches brand tone
   - Show: "Your voice is [tone summary]. Angles will match that register."

5. **If `workspace/brand/` does not exist:**
   - Skip brand loading entirely. Do not error.
   - Note: "No brand profile found -- this skill works standalone. I'll ask what I need. You can run /start-here or /brand-voice later to unlock personalization."

---

## The Core Job

When someone asks about positioning or angles, the goal is not to find THE answer. It is to surface **multiple powerful options** they can choose from.

Every product has several valid angles. The question is which one resonates most with the specific audience at the specific moment.

Output format: **3-5 distinct angle options**, numbered with circled numbers, each with:
- Statement (one sentence positioning)
- Psychology (why this works with this audience)
- Headline direction (how it would sound in copy)
- Best for (market conditions, audience segments)
- One option marked with a star as recommended

---

## The Angle-Finding Process

### Step 1: Identify what they are actually selling

Not the product. The transformation.

Ask: What does the customer's life look like AFTER? What pain disappears? What capability appears? What status changes?

A fitness program does not sell workouts. It sells "fit into your old jeans" or "keep up with your kids."

A SaaS tool does not sell features. It sells "close your laptop at 5pm" or "never lose a lead."

**The transformation is the raw material for angles.**

---

### Step 2: Map the competitive landscape

What would customers do if this did not exist? Not competitors -- alternatives.

- Do nothing (live with the problem)
- DIY (cobble together a solution)
- Hire someone (consultant, freelancer, agency)
- Buy a different category (different approach entirely)
- Buy a direct competitor

Each alternative has weaknesses. Those weaknesses become angle opportunities.

---

### Step 2.5: Competitive web search (live data)

Before generating angles, search the web for real competitor messaging. This grounds the angle work in current market reality rather than assumptions.

**Search process:**

1. **Identify search targets:** Start with competitors from `workspace/brand/competitors.md`, user-named competitors, or search "[product category] + [target market]"
2. **Pull messaging data:** Homepage headlines, taglines, value propositions, key claims, social proof framing, CTA language
3. **Map the landscape:**
   - What claims appear on 3+ competitor sites (saturated territory)
   - What angles only 1 competitor uses (partially claimed)
   - What angles NO competitor uses (white space)
4. **Present findings as a competitive landscape map:**

```
  COMPETITIVE MESSAGING LANDSCAPE

  Competitors Analyzed
  |-- [Competitor 1] -- "[their headline]"
  |-- [Competitor 2] -- "[their headline]"
  |-- [Competitor 3] -- "[their headline]"

  Saturated Claims (everyone says this)
  |-- "[Claim 1]"
  |-- "[Claim 2]"

  Partially Claimed (1-2 competitors)
  |-- "[Claim]" -- used by [Competitor]

  Underexploited Territory
  |-- Nobody is talking about [gap 1]
  |-- The [specific angle] is wide open
```

**Why this matters:** Angles built on white space outperform angles that echo the market.

---

### Step 3: Find the unique mechanism

The mechanism is HOW the product delivers results differently. Not "we help you lose weight" (the promise) but "we help you lose weight through intermittent fasting optimized for your metabolic type" (the mechanism).

The mechanism makes the promise believable. It answers: "Why will this work when other things have not?"

**Questions to surface the mechanism:**
- What is the proprietary process, method, or system?
- What do you do differently than the obvious approach?
- What is the counterintuitive insight that makes this work?
- What is the "secret" ingredient, step, or element?

Even if nothing is truly proprietary, there is always a mechanism. Name it.

---

### Step 4: Assess market sophistication

Where is the market on Schwartz's awareness scale?

**Stage 1 (New category):** Simple announcement. "Now you can [do thing]."
**Stage 2 (Growing awareness):** Claim superiority. "The fastest/easiest way to [outcome]."
**Stage 3 (Crowded):** Explain the mechanism. "Here is WHY this works when others do not."
**Stage 4 (Jaded):** Identity and belonging. "For people who [identity marker]."
**Stage 5 (Iconic):** Exclusive access. "Join the [tribe/movement]."

**The market stage determines which angle TYPE will work.**

---

### Step 5: Run the angle generators

Generate options using multiple frameworks. Each generator is a lens -- run the product through several and keep the 3-5 strongest.

**The Contrarian Angle:** Challenge a common belief. Works when the market is frustrated with conventional approaches.

**The Unique Mechanism Angle:** Lead with the HOW, not the WHAT. Name the proprietary process. Works when the market is sophisticated (Stage 3+).

**The Transformation Angle:** Before and after. The gap between current and desired state. Works when the transformation is dramatic and specific.

**The Enemy Angle:** Position against a common enemy (a problem, mindset, or obstacle -- not a competitor). Works when the audience has shared frustrations.

**The Speed/Ease Angle:** Compress time or reduce effort. Works when alternatives require significant time/effort and speed is genuinely differentiated.

**The Specificity Angle:** Get hyper-specific about who it is for or what it delivers. Works when competing with generic offerings.

**The Social Proof Angle:** Lead with evidence, not claims. Works when you have strong proof and the market is skeptical.

**The Risk Reversal Angle:** Make the guarantee the headline. Works when risk is the primary objection.

---

## Output Format

### Header

```
  POSITIONING ANGLES
  [Product/Offer Name]
  Generated [Month Day, Year]
```

### Content: Competitive Landscape Map

Present the competitive search findings first (see Step 2.5 format above).

### Content: Market Assessment

```
  MARKET ASSESSMENT

  Sophistication: Stage [N] -- [stage name]
  Transformation: [one sentence]
  Mechanism: [the unique how]
  Primary alternative: [what they do instead]
```

### Content: Angle Options

```
  ANGLE OPTIONS

  1.  [ANGLE NAME]                     [star] recommended
     Statement: [one sentence positioning]
     Psychology: [why this works with this audience]
     Headline: "[example headline]"
     Best for: [market conditions, audience segments]

  2.  [ANGLE NAME]
     Statement: [one sentence positioning]
     Psychology: [why this works with this audience]
     Headline: "[example headline]"
     Best for: [market conditions, audience segments]

  [Continue for 3-5 options]

  Why [star] [Angle Name]: [1-2 sentences explaining
  why this is the strongest fit for their market
  stage, audience, and competitive white space]
```

Then ask: "Which angle resonates? Pick a number, or tell me to combine elements from multiple."

### Files Saved

After the user selects an angle, write to `workspace/brand/positioning.md`:
```
  FILES SAVED

  workspace/brand/positioning.md             [check]
```

### What's Next

```
  WHAT'S NEXT

  Your positioning is set. Every downstream
  skill will use this angle. Recommended moves:

  -> /direct-response-copy  Write copy with your
                             winning angle (~15 min)
  -> /lead-magnet            Build a lead gen
                             asset (~10 min)
  -> /keyword-research       Map your content
                             territory (~15 min)

  Or tell me what you're working on and
  I'll route you.
```

---

## File Output Protocol

When the user selects an angle (or confirms the recommended one), write `workspace/brand/positioning.md` with this format:

```markdown
## Last Updated
[Date] by /positioning-angles

## Primary Positioning

Angle: [Selected angle name]
Statement: [One sentence positioning]
Psychology: [Why this works]
Headline direction: "[Example headline]"
Best for: [Market conditions]

## Competitive Landscape Summary

Sophistication: Stage [N] -- [stage name]
Primary alternative: [what customers do instead]

Saturated claims:
- [Claim 1]
- [Claim 2]

White space identified:
- [Gap 1]
- [Gap 2]

## All Angles Explored

### Angle 1: [Name] (selected)
- Statement: [...]
- Headline: "[...]"

### Angle 2: [Name]
- Statement: [...]
- Headline: "[...]"

[Continue for all angles generated]
```

**If `workspace/brand/positioning.md` already exists:**
1. Read the existing file
2. Show the user what will change
3. Ask for confirmation: "Replace the existing file? (y/n)"
4. Only overwrite after explicit confirmation

---

## 12-Ad Matrix Seed (optional)

After the user selects an angle, offer:

"Want me to generate a testing matrix for this angle? I'll map 4 hooks across 3 formats for a 12-ad testing grid."

If yes, produce the matrix:

- **4 rows** = 4 different hooks derived from the selected angle
  - H1: The direct statement hook (lead with the claim)
  - H2: The question hook (lead with curiosity)
  - H3: The proof hook (lead with evidence)
  - H4: The contrarian hook (lead with a challenge)

- **3 columns** = 3 ad formats
  - Format A: Static image (single visual + headline)
  - Format B: Video (talking head or motion + headline)
  - Format C: Carousel (multi-slide story)

Each cell contains: Cell ID for tracking, hook text tailored to the format, visual concept, primary text, and CTA text.

After generating the matrix, suggest picking 3-4 cells to develop first.

---

## The Test

Before delivering angles, verify each one:

1. **Is it specific?** Vague angles fail. Specific angles convert.
2. **Is it differentiated?** Cross-reference against the competitive landscape map -- if a competitor already says it, it fails.
3. **Is it believable?** Does the mechanism or proof support the claim?
4. **Is it relevant to THIS audience?** If audience.md is loaded, verify alignment.
5. **Does it lead somewhere?** Can you imagine the headline, landing page, copy?

---

## Iteration and Update Mode

When `workspace/brand/positioning.md` already exists, the skill enters update mode:

### Display Current State

```
  CURRENT POSITIONING

  Primary angle: [angle name from file]
  Statement: [current statement]
  Last updated: [date from file]

  Options: Refine this, or start fresh?
```

### Refine Mode

1. Load existing angles from positioning.md
2. Run fresh competitive web search to see what has changed
3. Compare new landscape to saved landscape
4. Identify shifts: new competitors, new saturated claims, new white space
5. Suggest specific adjustments
6. Present 1-3 refined angle variations alongside the original
7. Let the user choose to keep, tweak, or replace

### Start Fresh Mode

Run the complete process from Step 1 as if no positioning exists. Previous positioning.md is preserved until the user explicitly confirms replacement.

---

## Feedback Collection

After delivering the final angle selection and writing to positioning.md:

```
  How did this perform?

  a) Great -- using this angle as-is
  b) Good -- tweaked the language slightly
  c) Rewrote significantly
  d) Haven't used yet

  (You can answer later -- just run
  /positioning-angles again and tell me.)
```

**Processing:**

- **(a) Great:** Log to `workspace/brand/learnings.md` under "What Works" with the angle name and context.
- **(b) Good -- tweaked:** Ask what changed. Log the adjustment. If the tweak reveals a voice mismatch, suggest re-running /brand-voice.
- **(c) Rewrote significantly:** Ask for the final version. Analyze differences. Offer to update positioning.md with their version.
- **(d) Haven't used yet:** Note it. Do not log.

---

## How This Skill Gets Invoked

This skill activates when:
- User asks "how should I position X"
- User asks "what's the angle for X"
- User asks "why isn't this selling"
- User asks to "find the hook" or "make this stand out"
- User is about to write copy/landing page but has not established positioning
- Another skill needs an angle to write from

When another skill needs an angle, run this first. The angle informs everything downstream.

---

## What This Skill is NOT

This skill finds positioning and angles. It does NOT:
- Write the actual copy (that is direct-response-copy)
- Build the landing page structure (that is landing-page)
- Research the audience from scratch (assumes you know who you are selling to, or loads audience.md)
- Pick a single "right" answer (it gives options to choose from)
- Replace deep competitive intelligence (this does a messaging-focused scan)

The output is strategic direction, not finished marketing.
