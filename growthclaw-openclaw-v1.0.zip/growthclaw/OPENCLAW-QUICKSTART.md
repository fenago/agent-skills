# GrowthClaw — OpenClaw-native Quick Start

This zip is designed for **OpenClaw**.

## Install (recommended)

1) Upload/extract this folder somewhere on your machine
2) Run:

```bash
cd growthclaw
./install.sh
```

This installs to:

- `~/.openclaw/skills/growthclaw/`

and creates (if missing):

- `~/.openclaw/workspace/brand/`
- `~/.openclaw/workspace/campaigns/`

## Verify

```bash
./doctor.sh
openclaw skills check
```

## First commands to try

- `/start-here`
- `/stack-key-advisor`

## Optional API keys

All skills work without keys, but these unlock more:

- `BRAVE_API_KEY` — live web search/SERP data for research skills
- `REPLICATE_API_TOKEN` — enables image/video generation in `/creative`

## Uninstall

```bash
cd growthclaw
./uninstall.sh
```

By default this **does not delete** your generated brand/campaign files.

To also purge workspace memory folders:

```bash
./uninstall.sh --purge-workspace
```
