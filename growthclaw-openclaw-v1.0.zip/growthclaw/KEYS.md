# GrowthClaw API Key Reference

Which keys unlock which capabilities, and what happens without them.

## Key Matrix

| Key | Skills Enhanced | What It Unlocks | Without It | Cost |
|-----|----------------|-----------------|------------|------|
| `REPLICATE_API_TOKEN` | creative | AI image/video generation | Prompt-only mode (optimized prompts for external tools) | ~$0.02/image, $0.30-1.50/video |
| `BRAVE_API_KEY` | seo-content, keyword-research, positioning-angles, lead-magnet, newsletter, brand-voice | Live SERP data, competitor research, trending topics | Estimated data flagged with `~` prefix | Free tier: 2,000 queries/mo |
| `MAILCHIMP_API_KEY` | email-sequences | Direct list management, sequence automation | Portable email files for manual import | Free tier: 500 contacts |
| `CONVERTKIT_API_KEY` | email-sequences | Creator-focused email automation | Portable email files | Paid plans from $29/mo |
| `HUBSPOT_ACCESS_TOKEN` | email-sequences | CRM + email automation | Portable email files | Free CRM tier available |
| `BUFFER_ACCESS_TOKEN` | content-atomizer | Direct social media scheduling | Ready-to-paste platform content | Free tier: 3 channels |
| `HOOTSUITE_API_KEY` | content-atomizer | Enterprise social scheduling | Ready-to-paste platform content | Paid plans |

## Setup By Goal

### "I want to write marketing content" (free)
No keys needed. brand-voice, positioning-angles, direct-response-copy, email-sequences, lead-magnet, newsletter, and content-atomizer all work without any API keys.

### "I want SEO-driven content" (free-$0)
- `BRAVE_API_KEY` (free tier) — enables live SERP analysis in keyword-research and seo-content

### "I want AI visuals" (~$5-20/month)
- `REPLICATE_API_TOKEN` — enables the creative skill to generate images and video

### "I want full automation" (~$30-50/month)
- `BRAVE_API_KEY` — live research
- `REPLICATE_API_TOKEN` — visual generation
- One ESP key (Mailchimp/ConvertKit/HubSpot) — email automation
- One scheduler key (Buffer/Hootsuite) — social scheduling

## Key Detection

Every skill checks for its relevant keys at startup and displays status:
- Present + valid: skill uses the enhanced path
- Present + invalid: skill warns and falls back
- Not present: skill uses graceful degradation with clear messaging

Run `/stack-key-advisor` to get a personalized recommendation based on your goals.
