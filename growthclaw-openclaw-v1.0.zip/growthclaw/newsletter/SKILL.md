---
name: newsletter
description: "Create best-in-class newsletters people actually want to read -- deep-dives, news briefings, curated links, personal essays, builder updates, and irreverent news."
metadata:
  openclaw:
    emoji: "\U0001F4F0"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Newsletter Skill

Most newsletters are forgettable. Subscribers open them once, skim the first paragraph, delete.

The newsletters that build loyal audiences -- and businesses -- do something different. They have a format readers can rely on. A voice that's recognizable. Content worth opening.

This skill helps you create newsletters people actually look forward to.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

For detailed breakdowns of top newsletters' structure, voice markers, and sample formats, load `references/newsletter-examples.md`.

---

## Brand Memory Integration

**Reads:** `voice-profile.md`, `positioning.md`, `audience.md`, `keyword-plan.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

1. **`voice-profile.md`** -- Match tone, vocabulary, sentence rhythm. Show: "Your voice is [tone summary]."
2. **`audience.md`** -- Match content depth to sophistication; use audience language. Show: "Writing for [audience summary]."
3. **`keyword-plan.md`** -- Use keyword themes for topic alignment with SEO strategy. Show: "Keyword plan loaded."
4. **Check `workspace/campaigns/newsletters/`** -- Scan past editions for format consistency and topic overlap. Show: "Found [N] editions. Avoiding overlap."
5. **If `workspace/brand/` does not exist** -- skip, proceed standalone. Note: "No brand profile yet. Run /start-here or /brand-voice first, or I'll work without it."

### Context Loading Display

```
Brand context loaded:
+-- Voice Profile     {Y/X} {summary}
+-- Audience          {Y/X} {summary}
+-- Keyword Plan      {Y/X} {summary}
+-- Past Editions     {Y/X} {summary}
```

---

## The Core Job

Transform content, curation, or ideas into **publication-ready newsletters** that:
- Get opened (subject line + sender reputation)
- Get read (hook + scannability)
- Get remembered (voice + value)
- Get shared (insight worth passing on)

---

## Newsletter Archetypes

### 1. Deep-Dive / Framework (Lenny Rachitsky style)
**Best for:** Expertise, thought leadership, premium positioning
**Frequency:** Weekly | **Length:** 1,500-3,000 words | **Revenue:** Premium subs ($15-30/mo)

### 2. News Briefing (Morning Brew style)
**Best for:** Daily habit, broad audience, ad revenue
**Frequency:** Daily or 3x/week | **Length:** 500-1,000 words | **Revenue:** Sponsorships

### 3. Curated Links + Commentary (Ben's Bites style)
**Best for:** Niche expertise, building in public
**Frequency:** Daily or weekly | **Length:** 500-1,500 words | **Revenue:** Affiliate, sponsorships

### 4. Personal Essay / Reflection (Sahil Bloom style)
**Best for:** Personal brand, coaching/courses
**Frequency:** Weekly | **Length:** 1,000-2,000 words | **Revenue:** Courses, coaching

### 5. Startup/Builder Updates (Greg Isenberg style)
**Best for:** Founder audience, community building
**Frequency:** Weekly | **Length:** 800-1,500 words | **Revenue:** Community, advisory

### 6. Irreverent News + Stories (The Hustle style)
**Best for:** Broad business audience, entertainment + education
**Frequency:** Daily | **Length:** 800-1,200 words | **Revenue:** Sponsorships, subs

---

## Format Templates

### Template 1: Deep-Dive Framework

```
SUBJECT: [Specific question] -- [Hint at framework]

[PERSONAL OPENER - 2-3 sentences]
**[THE QUESTION you're answering]**
[CONTEXT - why this matters]

## [FRAMEWORK NAME]
### [Component 1] - [Explanation + example]
### [Component 2] - [Explanation + example]
### [Component 3] - [Explanation + example]

## How to Apply This
1. [Step 1]  2. [Step 2]  3. [Step 3]

## The Bottom Line
[2-3 sentence summary]
[Sign-off + P.S.]
```

### Template 2: News Briefing

```
SUBJECT: [Day/Date]: [Hook about biggest story]

Today: [Teaser]

## TOP STORIES
### [STORY 1 - Intriguing headline]
[2-3 sentences] **Why it matters:** [implication]

### [STORY 2]
[2-3 sentences] **Bottom line:** [takeaway]

## QUICK HITS
- [One-liner 1]  - [One-liner 2]  - [One-liner 3]

## [ENGAGEMENT SECTION - quiz/poll]
[Footer]
```

### Template 3: Curated Links + Commentary

```
SUBJECT: [N] things worth your time: [Hook]

[Personal opener]

## The Big One
**[Link Title](URL)** - [2-3 sentence take]

## Worth Reading
**[Link 1](URL)** - [commentary]
**[Link 2](URL)** - [commentary]
**[Link 3](URL)** - [commentary]

## Tools & Resources
**[Tool](URL)** -- [what + opinion]

## One Thing I'm Thinking About
[2-3 sentence reflection]

[Sign-off]
```

### Template 4: Personal Essay

```
SUBJECT: [Philosophical hook or contrarian take]

[OPENING HOOK - story or provocative statement, 2-4 sentences]

## [CORE IDEA]
[Thesis + personal experience]

## The Framework
**[Element 1]:** [Explanation]
**[Element 2]:** [Explanation]

## Questions to Ask Yourself
1. [Question]  2. [Question]  3. [Question]

## The Takeaway
[1-2 sentences]
[Sign-off + P.S.]
```

### Template 5: Builder/Startup Update

```
SUBJECT: [Contrarian observation]

Look...
[Hook observation - 2-3 sentences]

## The Idea
**[Pattern 1]** -- [real example]
**[Pattern 2]** -- [real example]

## Why This Matters Now
[Market context]

## What I'm Doing About It
[Personal application]

Reply if you're building in this space.
```

### Template 6: Irreverent News

```
SUBJECT: [Unexpected angle]

[HOOK HEADLINE]
[Opening anecdote - 3-4 sentences]

**What happened:** [facts]
**Why it's weird:** [angle]
**The bigger picture:** [implication]

## Also Worth Knowing
[Story 2 + 3 with personality]

## The Number of the Day
**[Stat]** - [context]

## One More Thing
[Lighter item]
```

---

## Voice & Tone Guide

**The sweet spot:** Professional but personable. Smart friend, not professor. Opinions with reasoning. Direct, not corporate.

**Five principles:**
1. **Write like you talk** (but tighter). Read it out loud.
2. **Have opinions.** "I think X because Y" beats hedging.
3. **Be specific.** Not "recently" but "Last Tuesday." Not "a lot" but "47%."
4. **Show your work.** Not "this is important" but "I spent 3 hours on this because..."
5. **Admit uncertainty.** "I'm not sure but..." builds trust.

**Avoid:** "In today's edition...", "Without further ado...", corporate jargon, excessive exclamation marks.
**Use:** Jump into content, "Here's what I found...", conversational transitions.

---

## Subject Line Formulas

**What works:**
1. **Specific + Curiosity:** "The $47K email mistake (and how to avoid it)"
2. **Their question:** "Should you raise prices in a recession?"
3. **Contrarian take:** "Why I stopped using [popular tool]"
4. **Number + Specificity:** "7 newsletter formats that actually work"
5. **Direct value:** "The framework I use for every product decision"

**What fails:** Clickbait, ALL CAPS, [NEWSLETTER NAME] in subject, vague topics, too-clever wordplay.

---

## Hook Patterns

1. **Direct Question:** "How do you make decisions without enough data?"
2. **Contrarian Statement:** "Most SEO advice is wrong."
3. **Personal Story:** "Last week I made a $40K mistake."
4. **Surprising Stat:** "73% of newsletters get deleted unread."
5. **Observation:** "I noticed something weird in my analytics..."
6. **Promise:** "By the end of this email, you'll know exactly how to..."

---

## Scannability Checklist

- Headers every 200-300 words
- Bold marks key insights (not everything -- under 30% of text)
- Short paragraphs (1-3 sentences)
- Bullet points for lists of 3+
- White space between sections
- Mobile-friendly preview
- One clear CTA
- Above-fold content hooks reader

---

## Content Sourcing with Web Search

For news briefing and curated link formats, use web search to pull current content.

**When it activates:** News Briefing (latest stories), Curated Links (quality articles/tools), Irreverent News (surprising angles), any topic-specified format (supporting data).

**Search strategy:** Identify terms from request + brand memory -> search "[niche] news this week", "[topic] trends", "[topic] tools" -> filter by relevance, recency, authority, uniqueness -> summarize in your own words with commentary + source links.

**Attribution:** Always link originals, summarize in your own words, add "why it matters" the source doesn't provide, credit authors by name.

**When NOT to search:** Deep-Dive (original thought leadership), Personal Essay (personal reflection), Builder Update (personal experience -- search only for supporting data).

---

## Platform Guidance

| Need | Platform |
|------|----------|
| Just write | Substack |
| Grow fast | Beehiiv |
| Sell digital products | ConvertKit |
| Full ownership | Ghost |
| Advanced automations | ConvertKit |
| Built-in monetization | Beehiiv or Substack |
| Media company | Beehiiv |

**Formatting notes:** Beehiiv = full HTML. Substack = basic markdown only. ConvertKit = plain text best. Ghost = full editorial design with card system.

---

## Growth Strategy

### Referral Programs
Highest-leverage growth tactic. Structure reward tiers:
- 1 referral: digital reward (template, exclusive article)
- 3-5: community access (private channel, AMA)
- 10+: tangible reward (merch, free subscription month)
- 25+: premium (annual sub, co-creation, mastermind)

Best practices: frictionless sharing, show progress, reward referrer, match rewards to audience identity, place CTA after best content.

### Cross-Promotions
Partner with similar-size newsletters in adjacent (not competing) niches. Formats: swap mentions, co-authored edition, guest spotlight, shared resource.

### Lead Magnet Integration
Use newsletter to distribute lead magnets; use lead magnets as signup incentive. If /lead-magnet has been run, reference the asset. If not, suggest it.

### Growth Channels
| Channel | Effort | Timeline | Impact |
|---------|--------|----------|--------|
| Referral program | Medium | Ongoing | High |
| Cross-promotions | Low | 1-2 weeks | Medium |
| Social clips | Medium | Ongoing | Medium |
| SEO repurposing | High | 3-6 months | High |
| Lead magnets | Medium | 1-2 weeks | High |

---

## Monetization Framework

### Sponsorships
Primary ($25-75 CPM), Mid-roll ($15-40), Classified ($5-15), Dedicated ($50-150+).
**Formula:** Subscribers x CPM / 1,000. Only accept relevant sponsors. Write ads in your voice. Limit 1-2 per edition.

### Paid Subscriptions
Free tier: core content, frameworks, enough to share. Paid ($5-30/mo): deep-dive extras, templates, archive, community, ad-free. Target 2-5% conversion, under 5% monthly churn.

### Product Funnel
Newsletter -> lead magnet -> low-ticket ($27-97) -> core product ($197-997) -> premium ($1,000+). Ratio: 80% value / 20% promotion max.

---

## The Newsletter Creation Workflow

1. **Gather:** What happened, what you learned, reader questions, links worth sharing. Run web search for news/curated formats.
2. **Select:** Pick 1 main topic OR 3-5 items. "Would I forward this?" Cut anything mediocre.
3. **Structure:** Choose template, outline, front-load best stuff.
4. **Write:** Hook first (25% of time), draft fast, add personality in editing.
5. **Polish:** Read aloud, cut 20%, check scannability, mobile preview.
6. **Send:** Tuesday-Thursday 6-10am, A/B test subject lines, preview to yourself.

---

## File Output

### Output Path
```
workspace/campaigns/newsletters/{YYYY-MM-DD}-{topic}.md
```

### File Format
```markdown
# Newsletter: {Title}

## Metadata
- **Type:** {archetype}
- **Date:** {YYYY-MM-DD}
- **Subject Line:** {chosen}
- **Subject Line Variants:** 1. {v1} 2. {v2} 3. {v3}
- **Read Time:** {X} min
- **Platform:** {platform}

---

## Newsletter Content
{Full body per template}

---

## Send Notes
- **Time:** {day + time}
- **A/B test:** {recommendation}

## Sources
{Links if web search used}
```

### Asset Registry
Append to `workspace/brand/assets.md`:
```
| {date}-{topic} | Newsletter ({type}) | {date} | newsletters | draft | {subject line} |
```

---

## Output Format

```
NEWSLETTER EDITION
Generated {date}

TYPE: {archetype}  |  TOPIC: {topic}

SUBJECT LINE VARIANTS
1. "{v1}"                    * recommended
   -> {why this works}
2. "{v2}"  -> {strength}
3. "{v3}"  -> {strength}
A/B test: 1 vs 2

----------------------------------------------

NEWSLETTER CONTENT
{Full body per template}

----------------------------------------------

SEND RECOMMENDATIONS
Best time: {day}, {time}
A/B test: Subject lines 1 vs 2

SOURCES
{Links if applicable}

FILES SAVED
workspace/campaigns/newsletters/{file}.md    Y
workspace/brand/assets.md                    Y (appended)

WHAT'S NEXT
-> /creative           HTML template, visuals (~15 min)
-> /content-atomizer   Atomize for social (~10 min)
-> /email-sequences    Welcome sequence (~15 min)
-> "Iterate"           Revise sections or subject
-> "Different format"  Try another archetype
```

---

## Chain to /content-atomizer

After every edition, offer atomization:

```
Newsletter saved. Ready to promote it?
-> /content-atomizer    Atomize for social (~5 min)
   Generates: Twitter thread, LinkedIn post,
   short-form hooks, pull quotes
```

**Strategy by type:** Deep-Dive = thread + LinkedIn long post. News = quick hits + carousel. Curated = thread with takes. Essay = thread + quote cards. Builder = thread + contrarian post. Irreverent = individual posts + TikTok script.

---

## How This Connects to Other Skills

**Input from:** brand-voice (voice), keyword-research (topics), positioning-angles (angles), start-here (audience)

**Uses:** direct-response-copy (CTAs), seo-content (blog repurposing), lead-magnet (newsletter CTAs)

**Chains to:** content-atomizer (social promotion)

---

## The Test

1. Would I open this? (Subject line)
2. Would I read past paragraph one? (Hook)
3. Would I remember this tomorrow? (Value)
4. Would I forward this? (Share)
5. Does this sound like me? (Voice)

---

## Feedback Collection

```
How did this perform?
a) Great -- shipped as-is
b) Good -- minor edits
c) Rewrote significantly
d) Haven't used yet
```

Log to `workspace/brand/learnings.md` with `[/newsletter]` tag. Track subject line performance, send-time data, and format preferences.
