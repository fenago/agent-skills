---
name: content-atomizer
description: "Transform one piece of content into platform-optimized assets across LinkedIn, Twitter/X, Instagram, TikTok, and YouTube."
metadata:
  openclaw:
    emoji: "â¡"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Content Atomizer Skill

One piece of content should become ten. The best creators don't create more -- they distribute better.

This skill transforms any source content into platform-optimized assets. Not generic repurposing. Platform-native content that performs.

**The math:** A single blog post can become 1 LinkedIn carousel + 2 LinkedIn text posts + 1 Twitter thread + 3 single tweets + 2 Instagram carousels + 1 Reel script + 2 TikTok scripts + 1 YouTube Short script + 1 Threads mini-thread + 1 Bluesky post + 1 Reddit value post = 16 pieces of content from one source.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

For extended platform deep-dives, complete example transformations, detailed algorithm optimization guides, and creator-tested patterns, load `references/atomizer-methodology.md`.

For detailed platform algorithm signals, format specs, and creator examples, load `references/platform-playbook.md`.

---

## Brand Memory Integration

This skill reads brand context to ensure every atomized piece sounds like the user's brand, adapts tone per platform, and builds on what has worked before. It also checks the learnings journal for platform performance data and the stack file for scheduling tool availability.

**Reads:** `voice-profile.md`, `creative-kit.md`, `learnings.md`, `stack.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

1. **Load `voice-profile.md`** (if exists):
   - Extract tone DNA, vocabulary, sentence patterns, and formality level
   - Apply the platform adaptation table (see below) to adjust voice per platform
   - A "direct, proof-heavy" voice sounds different on LinkedIn vs TikTok vs Reddit
   - Use vocabulary lists to stay on-brand: preferred words, banned words, signature phrases
   - Show: "Your voice is [tone summary]. Adapting for each platform."

2. **Load `creative-kit.md`** (if exists):
   - Use brand colors, fonts, and visual identity for carousel slide direction
   - Reference logo placement and design system for visual content notes
   - Show: "Creative kit loaded. Visual notes will reference your brand system."

3. **Load `learnings.md`** (if exists):
   - Check for platform-specific performance data
   - Check for hook patterns that have worked or failed on specific platforms
   - Check for optimal posting times per platform
   - Check for format preferences (carousels vs text, threads vs single tweets)
   - Show: "Found [N] platform learnings. Applying: [key insight]."

4. **Load `stack.md`** (if exists):
   - Check for Buffer, Hootsuite, or other scheduling tool API keys
   - Check for connected social accounts
   - Show: "Scheduling via [tool] available." or "No scheduler detected. Including recommended post times."

5. **If `workspace/brand/` does not exist:**
   - Skip brand loading entirely. Do not error.
   - Proceed without it -- this skill works standalone.
   - Note: "I don't see a brand profile yet. You can run /start-here or /brand-voice first to set one up, or I'll work without it."

### Context Loading Display

Show the user what was loaded using the standard tree format:

```
Brand context loaded:
+-- Voice Profile     Y "{tone summary}"
+-- Creative Kit      Y loaded
+-- Learnings         Y {N} entries ({M} platform-specific)
+-- Stack             Y Buffer connected
+-- Past Atomizations Y {N} found
```

If items are missing:

```
Brand context loaded:
+-- Voice Profile     X not found (run /brand-voice)
+-- Creative Kit      X not found (run /creative)
+-- Learnings         X none yet
+-- Stack             X not found
+-- Past Atomizations X first run
```

---

## Platform Voice Adaptation Table

The same insight needs different energy per platform. When a voice profile is loaded, apply these adjustments:

| Platform | Formality | Energy | Length Bias | Audience Expectation |
|----------|-----------|--------|-------------|----------------------|
| LinkedIn | Professional, thoughtful | Medium-high | Longer, detailed | Expertise, credibility |
| Twitter/X | Punchy, direct | High | Short, dense | Speed, wit, conviction |
| Instagram | Visual, inspirational | Medium | Caption-length | Visual-first, story |
| TikTok | Casual, energetic | Very high | Spoken-word short | Authenticity, entertainment |
| YouTube | Conversational, thorough | Medium | Script-length | Depth, personality |
| Threads | Conversational, warm | Medium | Medium text | Thoughtful discussion |
| Bluesky | Substantive, measured | Medium-low | Concise text | Nuance, substance |
| Reddit | Detailed, transparent | Low-key | Long-form text | Value, specificity, proof |

---

## Web Search for Algorithm Updates

Before generating content for any platform, perform a live web search to check for recent algorithm changes.

### Search Protocol

For each target platform, search for:

```
"{platform name} algorithm update {current month} {current year}"
"{platform name} algorithm changes {current year}"
"{platform name} reach engagement changes {current year}"
```

### What to Look For

1. **New ranking signals** -- Any officially announced or widely reported changes
2. **Format preference shifts** -- Are carousels still outperforming? Has video priority changed?
3. **Reach changes** -- Reports of organic reach increasing or decreasing
4. **New features** -- Features that affect content distribution
5. **Policy changes** -- New content policies, monetization changes, or API restrictions

### How to Apply Findings

After searching, compare findings against the reference playbook at `./references/platform-playbook.md`:

- **If no changes found:** Proceed with playbook data. Note: "Algorithm check: no significant changes since playbook was written."
- **If changes found:** Flag them explicitly before generating:

```
Algorithm updates detected:

+-- LinkedIn    No changes since playbook
+-- Twitter/X   UPDATE: [description]
+-- Instagram   UPDATE: [description]
+-- TikTok      No changes since playbook
+-- YouTube     No changes since playbook
+-- Threads     UPDATE: [description]
+-- Bluesky     No changes since playbook
+-- Reddit      No changes since playbook

Adjusting output for flagged platforms.
```

---

## The Core Job

Transform source content into **platform-native assets** that:
- Match each platform's algorithm signals
- Use format-specific best practices
- Include hooks proven to stop the scroll
- Feel native, not repurposed
- Respect brand voice with per-platform adaptation
- Land in organized, publishable file structure

---

## Input Types

### What Can Be Atomized

| Source Type | Best Outputs | Atomization Potential |
|-------------|--------------|----------------------|
| **Blog Post** | All platforms | High (lots of material) |
| **Newsletter** | LinkedIn, Twitter, Instagram, Threads | High |
| **Podcast Episode** | Short-form video, threads, carousels, Reddit | Very High |
| **Long-form Video** | Shorts, Reels, TikToks, carousels | Very High |
| **Webinar/Talk** | All platforms | Very High |
| **Case Study** | LinkedIn, Twitter threads, Reddit | High |
| **Data/Research** | Carousels, threads, single posts, Reddit, Bluesky | Medium-High |
| **Framework/Process** | Carousels, threads, video scripts | High |

### What to Extract

From any source, identify:

1. **The Core Insight** -- The one thing someone should remember
2. **Supporting Points** -- 3-7 sub-points that build the argument
3. **Stories/Examples** -- Concrete illustrations
4. **Data Points** -- Stats, numbers, proof
5. **Contrarian Takes** -- Opinions that challenge conventional wisdom
6. **Actionable Steps** -- What someone can do with this
7. **Quotable Lines** -- Punchy phrases that stand alone

---

## Platform Quick Reference (February 2026)

| Platform | Optimal Length | Best Format | Hook Window | Top Signal |
|----------|---------------|-------------|-------------|------------|
| LinkedIn | 1,200-1,500 chars | Carousel | First 3 lines | Dwell time + topic authority |
| Twitter/X | <100 chars (single) | Thread (8-15) | First tweet | Replies + early engagement |
| Instagram | 6-10 slides | Carousel | First slide | DM shares ("sends per reach") |
| TikTok | 30-60 seconds | Short video | First 3 seconds | Completion + niche alignment |
| YouTube (Shorts) | 10-35 seconds | Vertical video | First 2 seconds | Completion rate |
| YouTube (Long) | 8-12 minutes | Horizontal | First 30 seconds | Satisfaction + session time |
| Threads | 200-400 chars | Single post / mini-thread | First post | Reply depth + reshares |
| Bluesky | 150-280 chars | Single post | First line | Likes + custom feed placement |
| Reddit | 500-2000 words | Text post | Title + first paragraph | Upvote velocity + comment depth |

---

## Platform Templates

### LinkedIn

**Carousel Template:**
- Slide 1: Hook Slide -- bold claim or question, "Swipe to learn [outcome]"
- Slides 2-6: Content -- one numbered point per slide with 2-3 sentences
- Slide 7: Summary -- quick recap, 5 words max per point
- Final Slide: CTA -- follow, repost, save

**Text Post Template:**
- Hook (first line must stop the scroll)
- Context (why this matters, 2-3 lines)
- 5 numbered points with brief explanations
- Takeaway (the "so what")
- CTA (question or action)
- 3-5 hashtags at the bottom

**Hook Formulas:**
- Contrarian: "Stop [thing everyone does]. It's killing your [result]."
- Story: "Last week, I [did something]. What happened next changed how I think about [topic]."
- List Preview: "[Number] [things] that [outcome]. (Number [X] is the one no one talks about.)"
- Credibility: "After [impressive stat/experience], here's what I know for sure about [topic]:"
- Question: "Why do [surprising thing happen]? I finally figured it out."
- Bold Claim: "[Counterintuitive claim]. Here's the proof:"

### Twitter/X

**Thread Template:**
- Tweet 1: Bold claim or promise + "Thread:"
- Tweets 2-X: Numbered points with 2-3 sentences each
- Final Tweet: TL;DR bullets + follow/RT CTA

**Single Tweet Templates:**
- Insight: Counterintuitive observation + "Most people think X. But Y is actually true."
- List: "[Number] [things] that [outcome]:" + bullet items + "Which one hits different?"
- Hot Take: "Unpopular opinion:" + contrarian statement + one-line reasoning
- Proof: "[Impressive result]" + "Here's exactly how:" + 3-5 bullets

**Hook Formulas:**
- "[Thing] is dead. Here's what's replacing it:"
- "I [did X] for [time period]. Here's what happened:"
- "This will piss off [group], but [claim]."
- "The [industry] secret no one talks about:"

### Instagram

**Carousel:** 6-10 slides at 1080x1350px. Cover = bold hook. One point per slide. Summary optional. CTA = save/share/follow.

**Reel Script (15-30s):**
- 0-3s: Pattern interrupt hook
- 3-20s: 3 points delivered with momentum
- 20-30s: CTA (follow/save/send)

**Caption:** Hook first line (works in preview) + 2-4 paragraph body + save/share/comment CTA + 3 hashtags.

### TikTok

**Script (15-30s):**
- 0-3s: Visual + verbal hook simultaneously ("Stop scrolling if you...", "POV: You just realized...", "I'm about to save you...")
- 3-25s: 3 points delivered fast with momentum
- 25-30s: CTA ("Follow for more", "Part 2?", "Save this")

**Content Patterns:** Before/After, Green Screen, Stitch/Duet, Day in the Life, POV, Listicle, Myth Busting.

### YouTube

**Shorts (10-35s):** Immediate value promise hook + deliver fast + subscribe/full video CTA or end abruptly for rewatch.

**Long-Form (HIVES Framework):**
- H: Hook (0-30s) -- pattern interrupt, credibility, preview
- I: Intro (30s-1m) -- context, who it's for, what you'll cover
- V: Value (main content) -- deliver on promise with clear sections
- E: Engagement (throughout) -- prompts every 2-3 minutes
- S: Strong CTA (final 30s) -- summarize, next action, end screen

### Threads

**Post Templates:**
- Conversational Take: Opinion + context + "The thing nobody mentions: [insight]" + "What's your experience?"
- Mini-Thread: Bold claim (post 1) + supporting point (post 2) + deeper insight (post 3) + takeaway (post 4)
- Quote-Post: Reshare + "This is underrated. Here's why:" + 2-3 sentence take

### Bluesky

**Post Templates (300 char limit):**
- Thoughtful Observation: Nuanced take + "The thing that gets lost in the discourse:" + substance
- Link Post: Context + link + "Key takeaway:" + one-line
- Community Question: "Genuine question for [group]:" + specific question + context

### Reddit

**Value Post:** Specific descriptive title (no clickbait) + who you are/why qualified + detailed value + step-by-step if applicable + transparency disclaimer

**Rules:** Read subreddit rules first. 90/10 rule (90% value, 10% self-reference). Disclose affiliations. Long-form wins. Stay active in comments.

---

## The Atomization Workflow

### Step 1: Extract

From source content, pull out: Core Insight, Supporting Points (3-7), Stories/Examples, Data/Proof, Quotable Lines, Contrarian Takes.

### Step 2: Search for Algorithm Updates

Run the web search protocol above. Flag any changes that affect format choices or hook strategy.

### Step 3: Load Brand Voice + Platform Adaptation

If voice profile exists, load it and apply the platform adaptation table. Each platform version should feel like the same person speaking in a different room.

### Step 4: Map to Platforms

| Content Element | Best Platforms | Best Formats |
|-----------------|----------------|--------------|
| Core insight | All | Single posts, hooks |
| Supporting points (together) | LinkedIn, Twitter, Threads | Carousel, thread, mini-thread |
| Individual points | All | Single posts |
| Stories | Instagram, TikTok, Threads | Reels, Stories, conversational posts |
| Data points | LinkedIn, Twitter, Bluesky, Reddit | Image posts, carousels, detailed posts |
| Quotable lines | Twitter, Instagram, Bluesky | Quote graphics |
| Contrarian takes | Twitter, TikTok, Threads, Reddit | Single tweets, video hooks, value posts |

### Step 5: Transform

For each platform, apply: Format (use templates above), Hook (platform-specific formula), Length (match norms), CTA (platform-appropriate), Voice (per adaptation table).

### Step 6: Sequence

**Optimal posting sequence:**
1. LinkedIn carousel -- Day 1 (longest shelf life)
2. Twitter thread -- Day 1-2 (good for discussion)
3. Threads mini-thread -- Day 2 (conversational take)
4. Instagram carousel -- Day 2-3 (repurpose LinkedIn design)
5. Bluesky post -- Day 3 (substantive angle)
6. TikTok/Reel -- Day 3-4 (needs video production)
7. YouTube Short -- Day 4-5 (can repurpose TikTok)
8. Reddit value post -- Day 5-7 (detailed, value-first version)
9. Single posts -- Ongoing (extract individual points)

---

## Per-Platform File Output

### Directory Structure

```
workspace/campaigns/{source-slug}/
  brief.md                    <- Extraction summary
  social/
    linkedin/
      carousel.md
      text-post-01.md
      text-post-02.md
    twitter/
      thread.md
      single-01.md
      single-02.md
      single-03.md
    instagram/
      carousel.md
      carousel-02.md
      reel-script.md
      story-sequence.md
    tiktok/
      script-01.md
      script-02.md
    youtube/
      short-script.md
      long-form-outline.md
    threads/
      post-01.md
      mini-thread.md
    bluesky/
      post-01.md
      thread.md
    reddit/
      value-post.md
      comment-strategy.md
  schedule.md
```

### Source Slug Convention

Lowercase, kebab-case, max 40 characters. Example: "5 Pricing Mistakes That Kill SaaS Growth" becomes `5-pricing-mistakes-saas-growth`.

### File Header Format

```
---
platform: linkedin
format: carousel
source: "5 Pricing Mistakes That Kill SaaS Growth"
created: 2026-02-16
status: draft
recommended_post_time: "Tuesday 8:00 AM EST"
---
```

### Output Confirmation

After writing all files, display the tree showing all saved files with checkmarks.

---

## Scheduling Integration

### Detection Protocol

On invocation, check for scheduling tool availability:
1. Check `workspace/brand/stack.md` for connected scheduling tools
2. Check environment for API keys: `BUFFER_ACCESS_TOKEN`, `HOOTSUITE_API_KEY`, `LATER_API_KEY`, `SPROUT_API_KEY`

### If Scheduler Detected

Display connected accounts, offer to schedule compatible posts, note which platforms require manual posting.

### If No Scheduler Detected

Include recommended post times in every content file and in the schedule overview:

| Platform | Best Time | Timezone |
|----------|-----------|----------|
| LinkedIn | Tue/Thu 8-10 AM | User local |
| Twitter/X | Mon-Fri 12-1 PM | User local |
| Instagram | Mon/Wed/Fri 11 AM | User local |
| TikTok | Tue/Thu 7-9 PM | User local |
| YouTube | Sat 9-11 AM | User local |
| Threads | Daily 9-11 AM | User local |
| Bluesky | Weekdays 10-12 PM | User local |
| Reddit | Mon/Wed 9 AM | EST |

---

## Content Calendar Mode

When the user requests a content calendar (trigger phrases: "create content calendar from this," "generate a week of posts from this," "schedule this across platforms"), generate a full week's posting schedule.

### Calendar Generation Process

1. Extract all atomizable elements from the source
2. Search for algorithm updates on all target platforms
3. Load brand voice and platform adaptation
4. Map content to optimal platform-day-format combinations
5. Generate all content pieces
6. Assign specific dates and times
7. Write all files plus a master `schedule.md`

### Calendar Customization

Honor user preferences:
- "Only LinkedIn and Twitter" -- Generate for those platforms only
- "3 posts per day max" -- Cap daily output
- "No weekends" -- Skip Saturday and Sunday
- "Focus on video" -- Prioritize TikTok, Reels, Shorts
- "I want 2 weeks" -- Extend the calendar and remix content angles

---

## Anti-Patterns

**Don't:**
1. Copy-paste across platforms (cross-posted content performs 40-60% worse)
2. Use the same hook everywhere
3. Ignore platform-native features
4. Post everything at once -- stagger across days/weeks
5. Forget the CTA
6. Treat Threads like Twitter/X (different cultures)
7. Self-promote on Reddit (value first, always)
8. Use Twitter tone on Bluesky (substance and nuance win)

**Do:**
1. Lead with the best hook per platform
2. Adapt length to platform norms
3. Use native formatting (threads, carousels, etc.)
4. Front-load value (especially for video)
5. Adjust voice using the platform adaptation table
6. Check algorithm updates before generating
7. Write files to organized per-platform directories

---

## The Test

Good atomization means:
1. Each piece stands alone -- makes sense without the source
2. Each piece feels native -- doesn't feel "repurposed"
3. Hooks match the platform -- right energy, right format
4. Value is front-loaded -- best stuff first
5. CTAs are appropriate -- platform-native actions
6. Quality over quantity -- 5 great pieces > 15 mediocre ones
7. Voice adapts per platform -- same person, different room
8. Files are organized -- per-platform directories, ready to publish

---

## Feedback Collection

After delivering atomized content, collect feedback:

```
How did these perform?

a) Great -- published as-is across platforms
b) Good -- minor edits on some platforms
c) Rewrote significantly for some platforms
d) Haven't published yet

(You can answer later. Tell me which platforms
worked best and I'll optimize for those next time.)
```

Platform-specific feedback is especially valuable. Log entries like:
- `[date] [/content-atomizer] LinkedIn carousels shipped as-is. Twitter thread needed punchier hooks.`
- `[date] [/content-atomizer] Reddit post in r/SaaS got 200+ upvotes. Detailed breakdown format works.`

---

## How This Connects to Other Skills

**Input from:**
- **seo-content** -- Blog posts to atomize
- **newsletter** -- Newsletter editions to atomize
- **direct-response-copy** -- Landing page insights to distribute
- **brand-voice** -- Ensures consistent voice across platforms
- **creative** -- Visual assets for carousels, thumbnails, social graphics

**Output to:**
- **creative** -- Request visual assets for carousel slides, thumbnails
- **workspace/brand/assets.md** -- Register all created content
- **workspace/brand/learnings.md** -- Log platform performance data

**The flow:**
1. Create source content (blog, newsletter, video)
2. **content-atomizer transforms into platform pieces**
3. Each piece drives back to source or offer
4. Collect feedback on platform performance
5. Learnings feed into next atomization
6. Repeat with next piece of source content

---

## What's Next After Atomization

```
WHAT'S NEXT

Your content is atomized and saved. Next moves:

-> /creative          Generate platform visuals --
                     carousel graphics, thumbnails,
                     video assets (~15 min)
-> /newsletter        Bundle these insights into your
                     next newsletter edition (~15 min)
-> /email-sequences   Nurture social followers into
                     subscribers with a sequence (~15 min)
-> /seo-content       Create the source blog post
                     if you started from an idea (~20 min)
-> /start-here        Review your full project status

Or tell me what you're working on and I'll route you.
```
