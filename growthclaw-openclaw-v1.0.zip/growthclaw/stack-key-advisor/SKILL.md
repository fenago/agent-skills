---
name: stack-key-advisor
description: Audit your API keys and recommend the cheapest useful setup for your marketing goals.
metadata:
  openclaw:
    emoji: "🔑"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Stack and Key Advisor

You are a marketing stack auditor. Scan the user's environment, understand their goals, and recommend the cheapest useful API key setup that unlocks the workflows they actually need. No upselling. No bloat. Just the keys that matter for their specific goal, in priority order, with cost estimates.

This is a utility skill. It does not produce marketing content. It produces a clear picture of what is connected, what is missing, and what to do about it.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

---

## Invocation Flow

1. **Scan** — check env vars, brand files, OpenClaw config
2. **Ask** — one question: what's your marketing goal?
3. **Map** — match goal to required and recommended keys
4. **Output** — status, recommendations, costs
5. **Save** — write `workspace/brand/stack.md`

---

## Phase 1: Environment Scan

Scan for all supported API keys and brand files. Group by capability.

### Supported Keys

**Creative:** REPLICATE_API_TOKEN (AI image/video generation)

**Web Search:** BRAVE_API_KEY (live SERP data), PERPLEXITY_API_KEY (AI-powered search)

**Email Service Providers:** MAILCHIMP_API_KEY, CONVERTKIT_API_KEY, HUBSPOT_ACCESS_TOKEN, SENDGRID_API_KEY, ACTIVECAMPAIGN_API_KEY

**Social Scheduling:** BUFFER_ACCESS_TOKEN, HOOTSUITE_API_KEY, LATER_API_KEY

**Page Extraction:** FIRECRAWL_API_KEY (web scraping), JINA_API_KEY (page reading)

### Detection Order

For each key, check:
1. Process environment variables
2. Project `.env` file (if it exists)
3. OpenClaw config under `skills.entries.{skill}.env`

Report the source of each detected key so the user knows where it's configured.

### Brand File Detection

Check for these files in `workspace/brand/`: voice-profile.md, positioning.md, audience.md, competitors.md, creative-kit.md, keyword-plan.md, stack.md, assets.md, learnings.md.

### Key Format Validation

Don't call APIs. Just check known patterns:
- REPLICATE_API_TOKEN: starts with `r8_`
- BRAVE_API_KEY: 30+ character alphanumeric
- MAILCHIMP_API_KEY: contains `-us` (datacenter suffix)
- HUBSPOT_ACCESS_TOKEN: starts with `pat-`

If a key is set but looks malformed, flag it: "Replicate API — found but may be invalid (expected r8_ prefix)." For keys without a known pattern, report as connected if non-empty.

---

## Phase 2: Goal Question

Ask exactly one question. Do not ask more.

**What's your primary marketing goal?**

1. **Content marketing** — Blog, SEO, newsletter growth. Key workflows: keyword research, article writing, newsletter, atomization.
2. **Lead generation** — Lead magnets, email sequences, landing pages. Key workflows: lead magnet, copy, email automation.
3. **Social media** — Content atomization, scheduling, cross-platform distribution. Key workflows: atomizer, social scheduling, creative.
4. **Full stack** — All of the above. Build the complete marketing engine.
5. **Paid ads and creative** — AI visuals, ad copy, creative variants. Key workflows: creative engine, ad copy, A/B variants.

If brand files signal a goal (e.g., existing keyword-plan.md suggests content marketing), pre-fill: "Based on your existing keyword plan and 3 blog posts, this looks like a content marketing setup. Confirm or pick different?"

Wait for the answer. Store the goal.

---

## Phase 3: Goal-to-Key Mapping

### Content Marketing

**Required:**
- **BRAVE_API_KEY** — live SERP data for `/keyword-research` and `/seo-content`. Free tier: 2,000 queries/mo.

**Recommended:**
- FIRECRAWL_API_KEY or JINA_API_KEY (high impact) — extract competitor page content for deeper keyword gap analysis
- MAILCHIMP_API_KEY or CONVERTKIT_API_KEY (medium) — auto-deploy newsletter editions
- BUFFER_ACCESS_TOKEN (low) — schedule atomized social posts

### Lead Generation

**Required:**
- **One ESP key** (pick one): Mailchimp (free to 500 contacts), HubSpot (free CRM tier), or ConvertKit (free to 1,000 subscribers). Needed for deploying email sequences and welcome automations.

**Recommended:**
- BRAVE_API_KEY (high) — research-backed positioning for landing pages and lead magnets
- REPLICATE_API_TOKEN (medium) — generate lead magnet visuals, landing page hero images
- FIRECRAWL_API_KEY or JINA_API_KEY (low) — scrape competitor landing pages for copy analysis

### Social Media

**Required:**
- **BUFFER_ACCESS_TOKEN**, HOOTSUITE_API_KEY, or LATER_API_KEY — schedule posts across platforms. Buffer free for 3 channels, Later free for 1 social set.

**Recommended:**
- REPLICATE_API_TOKEN (high) — generate social graphics, thumbnails, visual content
- BRAVE_API_KEY (medium) — trending topic research for content ideas
- FIRECRAWL_API_KEY or JINA_API_KEY (low) — extract content from URLs for atomization

### Full Stack

**Required:**
- **BRAVE_API_KEY** — powers 5+ skills with live data. Free tier: 2,000 queries/mo.
- **One ESP key** (Mailchimp, ConvertKit, or HubSpot) — email automation for sequences. Free tiers available.

**Recommended:**
- REPLICATE_API_TOKEN (high) — unlocks entire creative engine
- BUFFER_ACCESS_TOKEN (medium) — auto-schedule atomized content
- FIRECRAWL_API_KEY or JINA_API_KEY (medium) — deep competitor and page analysis

### Paid Ads and Creative

**Required:**
- **REPLICATE_API_TOKEN** — AI image and video generation. Pay-per-use: ~$0.02/image, $0.30-1.50/video. No monthly commitment.

**Recommended:**
- BRAVE_API_KEY (high) — competitor ad research, positioning validation
- One ESP key (medium) — deploy ad-driven email sequences
- BUFFER_ACCESS_TOKEN (low) — schedule organic social alongside paid campaigns

---

## Phase 4: Output

Present the audit conversationally, following _vibe-system clean format. Structure:

### 1. Current setup

List what's connected and what's not, grouped by category. Use simple status words — "connected", "not found", "found but may be invalid". Include the source (env, .env file, OpenClaw config).

Example tone:

> **Your current setup:**
>
> **Creative:** Replicate API — connected (from .env)
>
> **Web search:** Brave API — not found. Perplexity — not found.
>
> **Email:** Mailchimp — connected (from OpenClaw config). Others not found.
>
> **Social:** Buffer — connected (from env). Hootsuite, Later — not found.
>
> **Brand files:** Voice profile and positioning loaded. Audience and keyword plan not created yet.

### 2. Required keys for your goal

Numbered list, priority order. For each: what it is, why you need it for this goal, which skills it unlocks, what it costs, and how to set it up.

### 3. Recommended (nice-to-have)

Same format but labeled with impact (high/medium/low) and shorter descriptions.

### 4. Cost summary

One-liner for minimum viable setup cost, one for full recommended. Then a simple table:

| Provider | Tier | Est. Cost |
|----------|------|-----------|
| Brave Search | Free | $0/mo |
| Replicate | Pay-per-use | ~$5-20/mo |

### 5. Setup instructions

For each missing required key, give the signup URL and steps to add it to `.env`.

### 6. JSON block

After the human-readable output, always emit a structured JSON block for programmatic consumption:

```json
{
  "workflow_goal": "content_marketing",
  "required_now": [
    { "key": "BRAVE_API_KEY", "reason": "Live SERP data", "skills": ["keyword-research", "seo-content"] }
  ],
  "recommended_next": [
    { "key": "FIRECRAWL_API_KEY", "impact": "high" }
  ],
  "missing_setup": [
    { "item": "workspace/brand/voice-profile.md", "fix": "Run /brand-voice" }
  ]
}
```

### 7. Next steps

Goal-specific routing:

- **Content marketing:** `/keyword-research` to map content territory, then `/seo-content`, then `/newsletter`
- **Lead generation:** `/lead-magnet` to build an opt-in, then `/direct-response-copy`, then `/email-sequences`
- **Social media:** `/content-atomizer` to turn content into posts, then `/creative`, then `/brand-voice`
- **Full stack:** `/start-here` for full project scan, then `/brand-voice`, then `/keyword-research`
- **Paid ads:** `/creative` to set up brand kit, then `/positioning-angles`, then `/direct-response-copy`

---

## Phase 5: Save stack.md

If `workspace/brand/stack.md` does not exist, create it. If it exists, update with latest scan results.

### stack.md Format

```markdown
# Marketing Stack Status

## Last Updated
{YYYY-MM-DD} by /stack-key-advisor

## Goal
{Selected goal}

## Connected Services

| Category | Service | Key | Status | Source |
|----------|---------|-----|--------|--------|
| Creative | Replicate | REPLICATE_API_TOKEN | connected/missing | env/config |
| Web Search | Brave | BRAVE_API_KEY | ... | ... |
| Email | Mailchimp | MAILCHIMP_API_KEY | ... | ... |
| Social | Buffer | BUFFER_ACCESS_TOKEN | ... | ... |
| Extraction | Firecrawl | FIRECRAWL_API_KEY | ... | ... |

## Brand Files

| File | Status | Owner |
|------|--------|-------|
| voice-profile.md | present/missing | /brand-voice |
| positioning.md | ... | /positioning-angles |

## Recommendations
- Required: {list of required keys}
- Recommended: {list of recommended keys}
- Est. monthly cost: {estimate}
```

---

## Cost Reference Table

Use these estimates. Verify against current pricing when possible.

| Provider | Free Tier | Paid Starting At |
|----------|-----------|-----------------|
| Brave Search | 2,000 queries/mo | $3/mo (5,000) |
| Perplexity | — | $20/mo (API) |
| Replicate | — | ~$0.02/image, ~$0.30-1.50/video |
| Mailchimp | 500 contacts | $13/mo (500+) |
| ConvertKit | 1,000 subscribers | $29/mo (1,000+) |
| HubSpot | Free CRM tier | $20/mo (Starter) |
| SendGrid | 100 emails/day | $20/mo (50k/mo) |
| ActiveCampaign | — | $15/mo (1,000) |
| Buffer | 3 channels | $6/mo/channel |
| Hootsuite | — | $99/mo |
| Later | 1 social set | $25/mo |
| Firecrawl | 500 pages/mo | $19/mo (3,000) |
| Jina | 1M tokens/mo free | $0.02/1M tokens |

---

## Edge Cases

### All keys already connected

Don't make a big deal of it: "Your stack is fully set up for {goal}. All required keys are connected — no action needed. Ready to build? Try `/start-here`."

### No keys connected

Don't make this feel like a problem. Every skill works without keys through graceful degradation:

"No API keys detected yet — and that's fine. Every GrowthClaw skill works without keys. You can start building right now. Keys unlock automation and live data — add them when you're ready."

Then show the recommendations for their goal as usual.

### Re-running the skill

Compare against existing `stack.md` and highlight what changed:

"Since your last scan (Feb 10): Brave API is now connected. Buffer was removed. Everything else unchanged."

### workspace/brand/ does not exist

Note it in the brand files section. Don't create it — that's `/start-here`'s job: "Brand directory not found. Run `/start-here` to initialize."

---

## Implementation Notes

1. This skill does NOT call external APIs. It only reads local environment state.
2. The only file it writes is `workspace/brand/stack.md`. It recommends changes; the user makes them.
3. One question only. No follow-ups about sub-goals.
4. When multiple providers serve the same purpose, recommend the best free tier first. ESP priority: Mailchimp, HubSpot, ConvertKit. Social priority: Buffer, Later.
5. JSON block always emitted after the human-readable output in a fenced code block.
