# Model Registry — Vibe Marketing Skills v2

**Single source of truth for all AI model configurations used in the creative engine.**

Every payload in this document has been verified against the Replicate API. If you are building prompts, making API calls, or debugging failures — this is the file you check first.

Last verified: 2026-02-16. Models change. If a call fails, check `replicate.com/[owner]/[model]` for the current schema.

---

## Table of Contents

1. [Image Generation](#image-generation)
2. [Video Generation](#video-generation)
3. [Lip-Sync](#lip-sync)
4. [Model Selection Logic](#model-selection-logic)
5. [Cost Reference](#cost-reference)
6. [Troubleshooting](#troubleshooting)

---

## Image Generation

### Default Model: Nano Banana Pro

| Field | Value |
|-------|-------|
| **Model ID** | `google/nano-banana-pro` |
| **Underlying Model** | Google Gemini 2.5 Flash Image ("nano-banana") |
| **Why Default** | Best-in-class typography, photorealism, and style control. Handles product photos, social graphics, text rendering, and artistic styles in one model. Generates at 2-3x the speed of comparable models. |
| **Typical Latency** | 15-40 seconds |
| **Cost** | ~$0.02-0.04 per image |

### Verified API Payload

```json
{
  "model": "google/nano-banana-pro",
  "input": {
    "prompt": "{{prompt}}",
    "aspect_ratio": "{{ratio}}",
    "output_format": "jpg",
    "resolution": "2K"
  }
}
```

### Parameter Reference

| Parameter | Type | Required | Default | Options / Range | Notes |
|-----------|------|----------|---------|-----------------|-------|
| `prompt` | string | **Yes** | — | Free text | The image description. Be specific. See VISUAL_INTELLIGENCE.md for prompt construction guidance. |
| `aspect_ratio` | string | No | `"match_input_image"` | `"1:1"`, `"16:9"`, `"9:16"`, `"4:3"`, `"3:4"`, `"3:2"`, `"2:3"`, `"4:5"`, `"5:4"`, `"21:9"`, `"match_input_image"` | Controls output dimensions. Defaults to matching input image ratio if `image_input` is provided. See aspect ratio table below. |
| `output_format` | string | No | `"jpg"` | `"png"`, `"jpg"`, `"webp"` | JPG is default. PNG for quality/transparency. WebP for web delivery. |
| `resolution` | string | No | `"2K"` | `"1K"`, `"2K"` | Output resolution tier. 2K produces higher-quality images. |
| `image_input` | array | No | `[]` | Up to 14 image URLs | Input images for editing, style transfer, or reference. Supports up to 14 images in a single call. |
| `safety_filter_level` | string | No | `"block_only_high"` | `"block_low_and_above"`, `"block_medium_and_above"`, `"block_only_high"` | Content safety filter. `block_only_high` is most permissive. Do not change unless you have a specific reason. |

### Aspect Ratio Quick Reference

| Ratio | Orientation | Best For | Platform Examples |
|-------|-------------|----------|-------------------|
| `1:1` | Square | Product shots, Instagram feed, LinkedIn, profile images | Instagram posts, Facebook, LinkedIn |
| `16:9` | Landscape | Hero banners, YouTube thumbnails, web headers, presentations | YouTube, website heroes, OG images |
| `9:16` | Portrait tall | Stories, Reels, TikTok, vertical ads | Instagram Stories, TikTok, Snapchat |
| `4:3` | Landscape | Blog images, slide decks, classic photo format | Blog posts, PowerPoint |
| `3:4` | Portrait | Pinterest pins, portrait photos | Pinterest, portrait displays |
| `3:2` | Landscape | Classic photography, print | DSLR standard, print media |
| `2:3` | Portrait | Posters, magazine covers, tall pins | Print posters, Pinterest |
| `4:5` | Portrait | Instagram feed (maximum height), Facebook ads | Instagram feed optimal, Facebook |
| `5:4` | Landscape | Wider product photos | Product catalogs |
| `21:9` | Ultrawide | Cinematic headers, ultrawide displays | Website hero sections, cinematic banners |

### Common Mistakes — Image Generation

1. **Do NOT use `width` / `height` parameters.** They are not supported. Use `aspect_ratio` only. The model calculates pixel dimensions internally based on the ratio and its `resolution` tier.

2. **Do NOT pass `negative_prompt`.** This parameter does not exist on Nano Banana Pro. To avoid unwanted elements, use explicit positive language in the prompt: say what you want, not what you do not want.

3. **`image_input` is an array, not a string.** Even for a single reference image, wrap it in an array: `"image_input": ["https://..."]`. Supports up to 14 images for multi-reference generation.

4. **The model owner changed from `fofr` to `google`.** The model ID is `google/nano-banana-pro`. The old `google/nano-banana-pro` endpoint returns 404.

5. **Do NOT exceed aspect ratio options.** The supported set is fixed. Passing `"2:1"` or `"1:2"` or pixel dimensions will cause an error or unpredictable behavior.

6. **`output_format` defaults to `"jpg"`, not `"png"`.** If you need transparency, explicitly set `"png"`.

7. **JSON prompt escaping.** Prompts that contain quotes must be escaped (`\"`) in the JSON body. Prefer single quotes inside prompts or avoid special characters.

---

## Video Generation

### Default Model: Kling 2.5 Turbo Pro

| Field | Value |
|-------|-------|
| **Model ID** | `kwaivgi/kling-v2.5-turbo-pro` |
| **Why Default** | Best motion control, cinematic depth, and consistent quality at reasonable speed. Strong prompt adherence. Supports both text-to-video and image-to-video. |
| **Typical Latency** | 2-5 minutes (5s clip), 4-8 minutes (10s clip) |
| **Cost** | ~$0.40 per 5s clip, ~$0.80 per 10s clip |

### Verified API Payload — Image-to-Video (I2V)

```json
{
  "model": "kwaivgi/kling-v2.5-turbo-pro",
  "input": {
    "prompt": "{{motion_description}}",
    "start_image": "{{image_url}}",
    "duration": 5,
    "aspect_ratio": "16:9"
  }
}
```

### Verified API Payload — Text-to-Video (T2V)

```json
{
  "model": "kwaivgi/kling-v2.5-turbo-pro",
  "input": {
    "prompt": "{{video_description}}",
    "duration": 5,
    "aspect_ratio": "16:9"
  }
}
```

### Parameter Reference — Kling 2.5

| Parameter | Type | Required | Default | Options / Range | Notes |
|-----------|------|----------|---------|-----------------|-------|
| `prompt` | string | **Yes** | — | Max 2500 characters | Describe the motion and scene. For I2V, describe what should happen in the video, not the image content. |
| `start_image` | string (URI) | No | — | Image URL | Starting frame for image-to-video. When provided, `aspect_ratio` is overridden by the image dimensions. Preferred over `image`. |
| `image` | string (URI) | No | — | Image URL | Alias for `start_image`. Either works; prefer `start_image` for clarity. |
| `end_image` | string (URI) | No | — | Image URL | Target final frame. Creates interpolation between start and end. Only works in pro mode. |
| `duration` | integer | No | `5` | `5`, `10` | Video length in seconds. 10s costs roughly 2x. |
| `aspect_ratio` | string | No | `"16:9"` | `"16:9"`, `"9:16"`, `"1:1"` | Ignored when `start_image` is provided. |
| `negative_prompt` | string | No | — | Free text | Elements to exclude from the video. Unlike Nano Banana Pro, this model DOES support negative prompts. |

### Common Mistakes — Kling 2.5

1. **Use `start_image` for the starting frame.** Both `start_image` and `image` work, but `start_image` is the canonical parameter name. Use it for consistency.

2. **When providing `start_image`, the `aspect_ratio` parameter is ignored.** The video inherits its aspect ratio from the input image. If you need a specific ratio, resize the image first.

3. **Duration is an integer, not a string.** Pass `5` not `"5"`. Only 5 and 10 are supported. Passing other values will error.

4. **`guidance_scale` has been removed.** This parameter no longer exists in the API. Remove it from any existing payloads.

5. **Do NOT describe the static scene in the prompt for I2V.** The model can see the start_image. Describe the MOTION: "camera slowly orbits right, product rotates to reveal label" not "a bottle of wine on a table."

---

### Comparison Model: Google Veo 3.1

| Field | Value |
|-------|-------|
| **Model ID** | `google/veo-3.1` |
| **Why Use** | Highest fidelity video, context-aware audio generation, reference image support. Best for hero/flagship content where quality justifies cost and wait time. |
| **Typical Latency** | 3-8 minutes |
| **Cost** | ~$0.80-1.50 per clip |

### Verified API Payload — Veo 3.1 I2V

```json
{
  "model": "google/veo-3.1",
  "input": {
    "prompt": "{{motion_description}}",
    "image": "{{image_url}}",
    "duration": 8,
    "aspect_ratio": "16:9",
    "resolution": "1080p",
    "generate_audio": true
  }
}
```

### Parameter Reference — Veo 3.1

| Parameter | Type | Required | Default | Options / Range | Notes |
|-----------|------|----------|---------|-----------------|-------|
| `prompt` | string | **Yes** | — | Free text | Describe the scene and motion. |
| `image` | string (URI) | No | — | Image URL | Starting frame. Best results at 1280x720 or 720x1280. |
| `last_frame` | string (URI) | No | — | Image URL | Ending frame for interpolation between two images. |
| `reference_images` | array of strings | No | — | 1-3 image URLs | Guide subject consistency. Reference-to-video (R2V) mode only. |
| `duration` | integer | No | `8` | `4`, `6`, `8` | Video length in seconds. |
| `aspect_ratio` | string | No | `"16:9"` | `"16:9"`, `"9:16"` | Only landscape or portrait. No square. |
| `resolution` | string | No | `"720p"` | `"720p"`, `"1080p"` | Higher resolution = slower + more expensive. |
| `generate_audio` | boolean | No | `false` | `true`, `false` | Generate synchronized audio. Adds processing time but produces native sound. |
| `negative_prompt` | string | No | — | Free text | Content to exclude. |
| `seed` | integer | No | random | 0-4294967295 | For reproducibility. |

### Common Mistakes — Veo 3.1

1. **The starting image parameter is `image`, NOT `start_image`.** Different name than Kling. This is the most common cross-model mistake.

2. **No square aspect ratio.** Only `"16:9"` and `"9:16"` are supported. For square content, crop the output in post.

3. **Duration values are 4, 6, or 8 — not 5 or 10.** Different from Kling. Do not pass Kling duration values.

4. **`generate_audio` defaults to false.** If you want audio (dialogue, ambient sound, music), you must explicitly set it to `true`.

5. **Reference images are not the same as start_image.** `reference_images` guide style/subject consistency but do not set the starting frame. Use `image` for the starting frame.

---

### Comparison Model: OpenAI Sora 2

| Field | Value |
|-------|-------|
| **Model ID** | `openai/sora-2` |
| **Why Use** | Strong prompt adherence, native audio generation, good for character-driven content. Use for hero content comparison alongside Veo 3.1. |
| **Typical Latency** | 3-10 minutes |
| **Cost** | ~$0.60-1.20 per clip |

### Verified API Payload — Sora 2 I2V

```json
{
  "model": "openai/sora-2",
  "input": {
    "prompt": "{{motion_description}}",
    "input_reference": "{{image_url}}",
    "seconds": 8,
    "aspect_ratio": "landscape"
  }
}
```

### Parameter Reference — Sora 2

| Parameter | Type | Required | Default | Options / Range | Notes |
|-----------|------|----------|---------|-----------------|-------|
| `prompt` | string | **Yes** | — | Free text | Describe the scene and motion. |
| `input_reference` | string (URI) | No | — | Image URL | Reference image for I2V. Must match the video aspect ratio. |
| `seconds` | integer | No | `8` | 4-12 | Video length in seconds. More granular than Kling/Veo. |
| `aspect_ratio` | string | No | `"landscape"` | `"landscape"` (1280x720), `"portrait"` (720x1280) | Uses words, not ratios. |
| `openai_api_key` | string | No | — | API key string | Optional. If you want to use your own OpenAI key instead of Replicate billing. |

### Common Mistakes — Sora 2

1. **The image parameter is `input_reference`, NOT `image`, `start_image`, or `image_url`.** Every video model uses a different parameter name. Check this file.

2. **Aspect ratio uses words, not numbers.** Pass `"landscape"` or `"portrait"`, not `"16:9"` or `"9:16"`. This is unique to Sora 2 on Replicate.

3. **Duration parameter is `seconds`, NOT `duration`.** Different from both Kling and Veo.

4. **No square aspect ratio.** Like Veo 3.1, only landscape and portrait are supported.

5. **Reference image must match aspect ratio.** If you set `"portrait"` but provide a landscape image, results will be poor. Resize the image to match.

---

### Cross-Model Parameter Cheat Sheet

This table exists because every model uses different parameter names for the same concept. Consult this before writing any API call.

| Concept | Kling 2.5 | Veo 3.1 | Sora 2 |
|---------|-----------|---------|--------|
| **Starting image** | `start_image` | `image` | `input_reference` |
| **Duration** | `duration` (5, 10) | `duration` (4, 6, 8) | `seconds` (4-12) |
| **Aspect ratio** | `aspect_ratio` ("16:9") | `aspect_ratio` ("16:9") | `aspect_ratio` ("landscape") |
| **Prompt adherence** | *(removed)* | — | — |
| **Negative prompt** | `negative_prompt` | `negative_prompt` | — |
| **Audio generation** | Not native | `generate_audio` | Native (always on) |
| **Ending frame** | `end_image` | `last_frame` | — |
| **Resolution control** | Fixed 1080p | `resolution` ("720p", "1080p") | Fixed |
| **Reproducibility** | — | `seed` | — |

---

## Lip-Sync

### Model: Kling Lip-Sync

| Field | Value |
|-------|-------|
| **Model ID** | `kwaivgi/kling-lip-sync` |
| **What It Does** | Takes a video of a person and syncs their lip movements to match provided audio or text. |
| **Typical Latency** | 1-3 minutes |
| **Cost** | ~$0.30-0.60 per clip |

### Verified API Payload — Audio-Driven Lip-Sync

```json
{
  "model": "kwaivgi/kling-lip-sync",
  "input": {
    "video_url": "{{source_video_url}}",
    "audio_file": "{{audio_url}}"
  }
}
```

### Verified API Payload — Text-Driven Lip-Sync (Model TTS)

```json
{
  "model": "kwaivgi/kling-lip-sync",
  "input": {
    "video_url": "{{source_video_url}}",
    "text": "{{spoken_text}}",
    "voice_id": "en_AOT",
    "voice_speed": 1
  }
}
```

### Parameter Reference — Kling Lip-Sync

| Parameter | Type | Required | Default | Options / Range | Notes |
|-----------|------|----------|---------|-----------------|-------|
| `video_url` | string (URI) | **Yes*** | — | .mp4, .mov | Source video. Must be 2-10 seconds, 720p-1080p, under 100MB. Mutually exclusive with `video_id`. |
| `video_id` | string | **Yes*** | — | Kling video ID | Use if the source video was generated by Kling. Mutually exclusive with `video_url`. |
| `audio_file` | string (URI) | **Yes*** | — | .mp3, .wav, .m4a, .aac | Audio to sync to. Under 5MB. Mutually exclusive with `text`. |
| `text` | string | **Yes*** | — | Free text | Text to synthesize and sync. Mutually exclusive with `audio_file`. |
| `voice_id` | string | No | — | Voice identifier string | Which TTS voice to use. Only applies when using `text` input. Example: `"en_AOT"`. |
| `voice_speed` | number | No | `1` | 0.5-2.0 | Speech rate multiplier. Only applies when using `text` input. |

*One of `video_url` or `video_id` is required. One of `audio_file` or `text` is required.

### When to Use Model TTS vs. External Audio

| Scenario | Approach | Why |
|----------|----------|-----|
| Quick talking head prototype | Use `text` + `voice_id` | Fastest path. One API call does everything. |
| Brand-specific voice required | Use external TTS (ElevenLabs, etc.) then pass `audio_file` | Model TTS voices are limited. External gives you voice cloning, brand voices, etc. |
| Voiceover already recorded | Use `audio_file` | You have the audio. No synthesis needed. |
| Multiple languages | Use external TTS then `audio_file` | Model TTS language/accent options are limited. |
| Testimonial/UGC content | Use `audio_file` with real voice recording | Authenticity matters. Real voices convert better. |

### Common Mistakes — Lip-Sync

1. **`audio_file` and `text` are mutually exclusive.** Providing both will error. Pick one input method.

2. **`video_url` and `video_id` are mutually exclusive.** Use `video_url` for external videos, `video_id` only for Kling-generated videos.

3. **Video must be 2-10 seconds.** Shorter or longer videos will be rejected. If your source is longer, trim it first.

4. **Video resolution must be 720p-1080p.** Lower resolution videos will produce poor results. Higher resolution videos may be rejected or downscaled.

5. **Audio file must be under 5MB.** Compress or trim audio that exceeds this limit.

---

## Model Selection Logic

The creative engine picks the right model automatically. This is the decision tree:

```
WHAT IS BEING MADE?
│
├─ Still image (any kind)
│  └─ Nano Banana Pro (google/nano-banana-pro)
│     Always. No exceptions unless user requests a specific model.
│
├─ Video (standard production)
│  ├─ Has a starting image? → Kling 2.5 I2V
│  └─ Text only? → Kling 2.5 T2V
│
├─ Video (hero/flagship content)
│  └─ Generate with ALL THREE in parallel:
│     ├─ Kling 2.5
│     ├─ Veo 3.1 (with generate_audio: true)
│     └─ Sora 2
│     Then present all three for user selection.
│
├─ Talking head / lip-sync
│  ├─ Have audio? → Kling Lip-Sync with audio_file
│  └─ Text script only? → Kling Lip-Sync with text + voice_id
│
└─ User requests specific model
   └─ Use what they asked for. Check this registry for the payload.
```

### Hero Content: Parallel Generation Pattern

For flagship content where quality matters most, run all three video models simultaneously:

```
Task 1: Kling 2.5 → cost ~$0.40, time ~3min
Task 2: Veo 3.1  → cost ~$1.00, time ~5min
Task 3: Sora 2   → cost ~$0.80, time ~6min
─────────────────────────────────────────────
Total:              ~$2.20, ~6min (parallel)
```

Present all three results. Let the user pick. The best model for any given prompt varies — running all three eliminates guessing.

---

## Cost Reference

### Per-Generation Estimates

| Model | Output | Estimated Cost | Typical Time |
|-------|--------|---------------|--------------|
| Nano Banana Pro | 1 image | $0.02-0.04 | 15-40s |
| Nano Banana Pro | 4 images | $0.08-0.16 | 20-60s |
| Kling 2.5 | 5s video | $0.30-0.50 | 2-5min |
| Kling 2.5 | 10s video | $0.60-1.00 | 4-8min |
| Veo 3.1 | 8s video (720p) | $0.60-0.80 | 3-6min |
| Veo 3.1 | 8s video (1080p) | $1.00-1.50 | 5-8min |
| Sora 2 | 8s video | $0.60-1.20 | 3-10min |
| Kling Lip-Sync | 2-10s clip | $0.30-0.60 | 1-3min |

### Campaign Cost Estimates

| Campaign Scale | Assets | Estimated Total |
|----------------|--------|-----------------|
| Social post (3 image variants) | 3 images | ~$0.10 |
| Product launch (10 images + 2 videos) | 12 assets | ~$2-4 |
| Full campaign (20 images + 5 videos + 2 lip-sync) | 27 assets | ~$8-15 |
| Hero content comparison (3 video models) | 3 videos | ~$2-3 |

Costs are approximate and depend on Replicate's current pricing. Check replicate.com for up-to-date rates.

---

## Troubleshooting

### API Call Fails Immediately

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| 401 Unauthorized | Missing or invalid API token | Check `REPLICATE_API_TOKEN` in .env |
| 422 Unprocessable Entity | Invalid parameter value | Check parameter name and type against this registry |
| Model not found | Typo in model ID | Copy the model ID exactly from this file |
| Input validation error | Wrong parameter for this model | Check the cross-model cheat sheet above |

### Generation Completes But Output Is Wrong

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Wrong aspect ratio | Passed pixel dimensions instead of ratio string | Use `"16:9"` not `1920x1080` |
| Image looks generic | Prompt too vague | See VISUAL_INTELLIGENCE.md for prompt construction |
| Video has no motion | I2V prompt describes static scene | Describe the MOTION, not the scene |
| Lip-sync mismatch | Audio too long or video too short | Ensure video is 2-10s and audio matches |
| Output URL is null | Generation failed silently | Check Replicate dashboard for error logs |

### Model-Specific Known Issues

**Nano Banana Pro:**
- Occasionally produces images with subtle text artifacts on complex typography. For text-heavy designs, generate multiple variants and pick the cleanest.
- Very long prompts (500+ words) may be truncated. Keep prompts under 300 words for best results.

**Kling 2.5:**
- Fast camera movements can cause warping artifacts at edges. Use moderate camera motion descriptions.
- 10-second clips sometimes have a quality dip in the middle. For critical content, use 5-second clips and stitch.

**Veo 3.1:**
- Audio generation significantly increases processing time. Only enable when audio is actually needed.
- Portrait aspect ratio (9:16) sometimes crops subjects unexpectedly. Review results carefully.

**Sora 2:**
- Aspect ratio must be "landscape" or "portrait" as strings — not numeric ratios.
- Generation times are the most variable of all models. Allow extra buffer for timeouts.

**Kling Lip-Sync:**
- Works best with front-facing, well-lit videos of a single person.
- Side profiles and multiple people in frame produce poor results.
- Audio with heavy background music interferes with sync quality.

---

*This registry is maintained as part of the Vibe Marketing Skills v2 creative engine. When model schemas change upstream, update this file first, then update any mode files that reference the changed model.*
