---
name: direct-response-copy
description: "Write landing pages, sales pages, emails, and ads that convert using proven direct response methodology."
metadata:
  openclaw:
    emoji: "âï¸"
    user-invocable: true
    homepage: https://thevibemarketer.com
    requires:
      env: []
---

# Direct Response Copy

Here's what separates copy that converts from copy that just exists: the good stuff sounds like a person talking to you. Not a marketing team. Not a guru. Not a robot. A person who figured something out and wants to share it.

That's what this skill does. It writes copy that feels natural while deploying the persuasion principles that actually work. The reader shouldn't notice the technique. They should just find themselves nodding along and clicking the button.

Read `workspace/brand/` per the _vibe-system protocol

Follow all output formatting rules from the _vibe-system output format

---

## Brand Memory Integration

This skill reads brand context to make every piece of copy consistent with the brand's established identity.

**Reads:** `voice-profile.md`, `positioning.md`, `audience.md`, `creative-kit.md` (all optional)

On invocation, check for `workspace/brand/` and load available context:

1. **Load `voice-profile.md`** (if exists):
   - Match the brand's tone, vocabulary, rhythm in all copy output
   - Apply the voice DNA: sentence length patterns, jargon level, formality register
   - Show: "Your voice is [tone summary]. All copy will match that register."

2. **Load `positioning.md`** (if exists):
   - Use the chosen angle as the copy's foundation
   - The positioning angle determines the lead, the proof hierarchy, the CTA framing
   - Show: "Your positioning angle is '[angle]'. Building copy around that frame."

3. **Load `audience.md`** (if exists):
   - Know who you are writing to: their awareness level, sophistication, pain points
   - Match Schwartz awareness level to headline approach
   - Show: "Writing for [audience summary]. Awareness level: [level]."

4. **Load `creative-kit.md`** (if exists):
   - Visual consistency for landing pages: color palette, typography, image style
   - Ensure copy references match the visual system
   - Show: "Creative kit loaded -- copy will reference your visual system."

5. **If `workspace/brand/` does not exist:**
   - Skip brand loading entirely. Do not error.
   - Proceed without it -- this skill works standalone.
   - The copy will be excellent either way; brand memory makes it consistent.

---

## What Are We Writing?

Before diving into frameworks, establish the format. Ask the user or infer from context:

  1  LANDING PAGE
     Hero, problem, solution, proof, CTA sections.
     Typically 800-2000 words.
     Structure: The Full Sequence (see below).
     Constraints: Mobile-first formatting, scannable, one primary CTA.

  2  SALES PAGE
     Long-form. Full objection handling.
     Story-driven. Typically 2000-5000 words.
     Structure: Extended Full Sequence with founder story, extended proof, FAQ.
     Constraints: Multiple CTA placements, risk reversal prominent.

  3  EMAIL
     Single idea, single CTA.
     Subject line + body. Under 500 words.
     Structure: Hook, value, CTA. That is it.
     Constraints: Subject line is the headline. Preview text matters. No images required.

  4  AD COPY
     Platform-specific (Meta, Google, LinkedIn, TikTok).
     Character limits apply. Hook-focused.
     Constraints by platform:
       Meta primary text: 125 chars (visible), 1000 max
       Google responsive: 30-char headlines, 90-char descriptions
       LinkedIn: 150 chars intro, 600 max
       TikTok: 100 chars overlay, hook in first 2 seconds

  5  SOCIAL POST
     Platform-native. Under 300 words typically.
     Hook + value + CTA.
     Constraints by platform:
       LinkedIn: 1300 chars for engagement, 3000 max
       Twitter/X: 280 chars, or thread format
       Instagram: 2200 chars caption max

  6  GENERAL / OTHER
     Any persuasive writing. Custom format.
     Apply methodology below with user-specified constraints.

Each mode applies the SAME methodology below but with format-specific
constraints on length, structure, and CTA placement. State which mode
you are using before generating copy.

---

## Iteration Detection

Before starting, check if copy already exists for this project:

### If campaign files exist in `workspace/campaigns/{name}/`

Do not start from scratch. Instead:

1. Read the existing copy files.
2. Present a summary of what exists:
   ```
   Existing copy found:
   |- landing-page.md    Y  (1,247 words, last updated Feb 10)
   |- emails/            Y  (3 emails in sequence)
   |- ads/               N  (none yet)
   ```
3. Ask: "Do you want to revise the existing copy, add a new piece, or start fresh?"
   - **Revise** -- load existing copy, apply scoring rubric, identify weak spots, rewrite
   - **Add new** -- use existing copy as context for consistency, write new piece
   - **Start fresh** -- run the full process below as if nothing exists

### If no campaign files exist

Proceed directly to copy generation using the methodology below.

---

## The core principle

Write like you're explaining to a smart friend who's skeptical but curious. Back up every claim with specifics. Make the transformation viscerally clear.

That's it. Everything else flows from there.

---

## Headlines

The headline does 80% of the work. One headline can outpull another by 19.5x. Same product, same offer, different headline.

### The master formula

> **[Action verb] + [specific outcome] + [timeframe or contrast]**

- "Ship your startup in days, not weeks"
- "Save 4 hours per person every single week"

The contrast version ("days, not weeks") creates before/after in six words.

### Headline patterns

**Story headline:** "They [doubted] when I [action]... But when I [result]..."
**Specificity headline:** [Specific number/metric] + [Unexpected comparison or detail]
**Question headline:** "Do you [common struggle]?" or "What if you could [desirable outcome]?"
**Transformation headline:** "From [bad state] to [good state]"

### What makes headlines fail

- Trying to be clever instead of clear
- Forgetting self-interest (what's in it for them?)
- Vague claims instead of specific benefits
- No curiosity gap (tells everything, nothing left to discover)

---

## Opening Lines and Flow

The first sentence has one job: get them to read the second sentence.

**The direct challenge:** "You've been using Claude wrong."
**The story opening:** "Last Tuesday, I opened my laptop and saw a number I couldn't believe."
**The confession:** "I'll be honest with you. I almost gave up three times."
**The specific result:** "In 9 months, we did $400k+ using these exact methods."
**The short sentence:** "It's simple." / "Here's the truth." / "This works."

### Openings to avoid

- "In today's fast-paced world..."
- "Are you ready to take your business to the next level?"
- "Welcome! I'm so glad you're here."
- "Let's dive in!"

### The slippery slide

Every element pulls them to the next. Use bucket brigades (And, So, Now, But, Look, Here's why, Truth is, Turns out). Vary paragraph length. Short first sentences in each section. Close every loop you open.

---

## Pain Quantification and the So What? Chain

**Pain quantification:** Don't just describe the pain. Do the math. "22+ hours of headaches" turns abstract frustration into a number they can weigh against your price.

**The So What? Chain:** For every feature, ask "so what?" until you hit something emotional or financial:

> Feature: Fast database -> Queries load in milliseconds -> Users don't bounce, revenue doesn't leak -> You stop waking up stressed about churn

Three levels deep. Then write from there.

---

## The Full Sequence

When building a complete landing page:

1. **Hook** -- Outcome headline with specific number or timeframe
2. **Problem** -- Quantify the pain (hours wasted, money lost)
3. **Agitate** -- Scenario or story that makes the problem vivid
4. **Credibility** -- Founder story, authority endorsements, or proof numbers
5. **Solution** -- What the product does, framed as transformation
6. **Proof** -- Testimonials with specific outcomes
7. **Objections** -- FAQ or "fit/not fit" section
8. **Offer** -- Pricing with value justification
9. **Urgency** -- Only if authentic
10. **Final CTA** -- Benefit-oriented, friction reducers below

You don't need all ten every time. But this is the complete arc when you need it.

---

## CTAs

Weak CTAs command action. Strong CTAs describe the benefit:

| Weak | Strong |
|------|--------|
| "Sign Up" | "Get ShipFast" |
| "Learn More" | "See the exact template I used" |
| "Subscribe" | "Send me the first lesson free" |
| "Buy Now" | "Start building" |

Below the CTA, add friction reducers:
> "$199 once. Join 2,600+ marketers. 2 minutes to install."

Pattern: **[Risk reversal] + [Social proof] + [Speed/ease]**

---

## Internet-Native Voice Markers

Patterns that signal "written by someone who lives online, not a marketing team":

- **Revenue transparency:** Specific numbers that would make corporate uncomfortable
- **Honest limitations:** "One note: 3D model generation isn't great yet"
- **Strategic emoji:** Use sparingly but deliberately
- **In-group language:** "Ship like a madman" / "Indie hacker" / language your audience uses with each other

---

## AI Tells to Avoid

Readers are getting better at spotting AI-generated content. These patterns destroy trust instantly.

**Overused words:**
- "delve" / "dive into" / "dig into"
- "comprehensive" / "robust" / "cutting-edge"
- "utilize" (just say "use")
- "leverage" (as a verb)
- "crucial" / "vital" / "essential"
- "unlock" / "unleash" / "supercharge"
- "game-changer" / "revolutionary"
- "landscape" / "navigate" / "streamline"

**Overused phrases:**
- "In today's fast-paced world..."
- "It's important to note that..."
- "When it comes to..."
- "In order to..." (just say "to")
- "Whether you're a... or a..."
- "Are you ready to take your X to the next level?"
- "Let's dive in" / "Without further ado"

**Punctuation tells:**
- Too many em-dashes (limit to 1-2 per piece)
- Long sentences with 4+ commas (break them up)
- Semicolons where periods would work

**Structural tells:**
- Every paragraph is the same length
- Every bullet point starts the same way
- Overly organized with too many headings
- Bold on every key term

**Voice tells:**
- Passive voice throughout
- No "I" or "you" anywhere
- Hedging: "some may find," "it's possible that," "can potentially"
- No contractions
- Perfectly grammatical but lifeless

**The fix:** Read your copy out loud. Real humans use contractions, write sentence fragments sometimes, have opinions without hedging, use "I" and "you" freely, and make unexpected word choices.

---

## Reference Loading

When deeper methodology is needed, read the relevant reference:
- For deep copywriting frameworks (Schwartz awareness levels, Hopkins scientific advertising, Ogilvy principles, Halbert/Caples/Sugarman/Collier methods, headline formulas, opening line patterns, curiosity gap techniques, flow methods, and modern internet-native examples): read references/COPYWRITING_PLAYBOOK.md

Load the playbook when:
- Writing long-form copy (landing pages, sales pages) -- load the full playbook
- Writing headlines -- load the Headlines and Opening Lines sections
- Scoring or reviewing copy -- the methodology above is sufficient
- Quick copy tasks (social posts, short emails) -- the methodology above is sufficient

---
---

# Variant Generation Protocol

Great copy is never one-shot. Generate variants for testing.

---

## Headlines: Generate 5-10

For every copy project, generate a minimum of 5 headline variants:

  1  The Direct Benefit headline -- master formula, maximum clarity
  2  The Curiosity Gap headline -- opens a loop, implies hidden knowledge
  3  The Social Proof headline -- leads with a number, name, or result
  4  The Contrarian headline -- challenges conventional wisdom
  5  The Story headline -- setup, tension, resolution implied

Plus 2-5 additional variants mixing frameworks.

Present as a numbered list. Mark the recommended pick with a star.

Always lead with a QUICK PICK summary:

```
  QUICK PICK
  * "{Recommended headline}"
    -> Best for: {audience awareness level}
    -> Why: {one-sentence rationale}

  See all {N} variants below.
```

---

## Body Copy: Generate 2-3 Variants

For landing pages and sales pages, generate at least 2 complete body copy variants:

### Variant A: Control
The strongest version of the primary angle. Plays it straight. Uses the most proven framework for the format.

### Variant B: Contrarian
Leads with a counterintuitive or challenging take. Opens with a pattern interrupt or direct challenge.

### Variant C: Proof-Led
Opens with the strongest evidence. No warmup. Testimonial, case study, or specific result upfront.

Present each variant as a complete piece with variant notes (angle, best for, tone, recommended test).

---

## Email Subject Lines: Generate 5-7

When writing emails, generate 5-7 subject line variants:
1. Direct benefit subject
2. Curiosity gap subject
3. Story teaser subject
4. Question subject
5. Contrarian subject
6. (Optional) Personalized subject using audience data
7. (Optional) Urgency subject (only if authentic)

---
---

# Copy Scoring Rubric

When asked to evaluate existing copy OR to self-score generated copy,
rate on these 7 dimensions (1-10 each).

## The 7 Dimensions

| # | Dimension | What It Measures | 10 Looks Like |
|---|-----------|-----------------|---------------|
| 1 | Clarity | Can a 12-year-old understand the core message? | Crystal clear in one read. Zero re-reading required. |
| 2 | Specificity | Real numbers, details, concrete proof? | Every claim has a specific number or example attached. |
| 3 | Voice | Sounds like a person, not a brand? | Unmistakably human. Distinctive. Could not be anyone else. |
| 4 | Desire | Does it make them WANT the thing? | Reader feels FOMO by paragraph 2. Visceral pull toward CTA. |
| 5 | Proof | Is there evidence for every claim? | Specific testimonials, data, case studies. Nothing unsubstantiated. |
| 6 | Urgency | Is there a reason to act now? | Time-bound offer + clear consequence of inaction. Authentic, not manufactured. |
| 7 | Flow | Does each line pull to the next? | Impossible to stop reading. Slippery slide from headline to CTA. |

## Score Format

```
  COPY SCORECARD

  Clarity:      8/10   "Clear on the offer, vague on the mechanism"
  Specificity:  6/10   "Uses 'many customers' instead of actual numbers"
  Voice:        7/10   "Conversational but could be any SaaS brand"
  Desire:       5/10   "Lists benefits but doesn't make them visceral"
  Proof:        4/10   "One testimonial, no data, no case study"
  Urgency:      3/10   "No reason to act now vs next month"
  Flow:         7/10   "Good transitions, but paragraph 3 is a wall"

  TOTAL:       40/70   (57%)

  Verdict: Needs rewrite. Below 70% threshold.

  Priority fixes:
  1. Add 2-3 specific testimonials with numbers (Proof: 4 -> 7)
  2. Quantify the pain -- do the math for them (Desire: 5 -> 8)
  3. Add authentic urgency (limited spots, price increase) (Urgency: 3 -> 6)
```

## Scoring Thresholds

| Range | Percentage | Verdict |
|-------|-----------|---------|
| 63-70 | 90-100% | Exceptional. Ship it. Minor polish only. |
| 56-62 | 80-89% | Strong. Ship with small tweaks noted. |
| 49-55 | 70-79% | Passing. Functional but leaving performance on the table. |
| 42-48 | 60-69% | Weak. Rewrite priority areas before shipping. |
| Below 42 | Below 60% | Needs full rewrite. Core issues in multiple dimensions. |

---
---

# A/B Testing Suggestions

After generating copy, suggest 3-5 specific tests to optimize performance.

## Test Suggestion Format

```
  Test [N]: [Element] -- [Version A] vs [Version B]
  Why:     [Hypothesis based on copywriting principles]
  Metric:  [Which metric this targets: CTR, conversion, engagement, etc.]
  Impact:  [Expected direction and magnitude]
  Priority: [HIGH / MEDIUM / LOW] -- [Reasoning]
```

## What to Test (Priority Order)

**HIGH priority:** Headlines (+15-50% CTR difference), Opening line/Hook (+10-30% scroll depth), CTA copy and placement (+5-20% click-through)

**MEDIUM priority:** Proof structure (+5-15% conversion rate), Length (+5-25% conversion)

**LOW priority:** Body copy angle (+3-10% conversion), Friction reducer copy (+2-8% CTA clicks)

---
---

# File Output Protocol

Write completed copy to the campaign directory structure.

## Directory Structure

```
workspace/campaigns/{campaign-name}/
|- landing-page.md
|- sales-page.md
|- emails/
|  |- welcome-sequence-1.md
|  |- welcome-sequence-2.md
|  |- {subject-slug}.md
|- ads/
|  |- meta-benefit-v1.md
|  |- meta-story-v1.md
|  |- google-responsive-v1.md
|  |- {platform}-{variant}.md
|- social/
   |- linkedin-launch-post.md
   |- twitter-thread-v1.md
   |- {platform}-{description}.md
```

## File Frontmatter

Every copy file includes frontmatter:

```yaml
---
type: [landing-page | sales-page | email | ad | social]
campaign: {campaign-name}
target_audience: [from brand memory or stated by user]
positioning_angle: [from brand memory or stated by user]
awareness_level: [unaware | problem-aware | solution-aware | product-aware | most-aware]
variant: [control | contrarian | proof-led | (custom label)]
platform: [web | meta | google | linkedin | tiktok | twitter | instagram]
word_count: [number]
date: [YYYY-MM-DD]
status: draft
score: [total/70 if scored]
---
```

## After Writing

1. **Save the file(s)** to the campaign directory.
2. **Update `workspace/brand/assets.md`** with the new asset entry.
3. **Report what was saved** in the output.

---
---

# Output Formatting

Follow the _vibe-system output format -- all 4 required sections.

## Section 1: Header

```
  DIRECT RESPONSE COPY
  Generated [Month Day, Year]
```

## Section 2: Content

The copy itself, beautifully formatted. Structure depends on format:
- **Landing page / Sales page:** Full copy in reading order with section dividers.
- **Email:** Subject line, preview text, then body.
- **Ad copy:** Per-platform with character counts noted.
- **Headlines / Variants:** Numbered list with star recommendation.
- **Copy Scorecard:** The scoring rubric output.

## Section 3: Files Saved

```
  Files saved

  Y workspace/campaigns/{name}/landing-page.md
  Y workspace/brand/assets.md (updated)
```

## Section 4: What's Next

Suggest logical follow-up skills based on what was just created.

---
---

# Feedback Collection

After delivering copy, collect feedback to improve future output.

## Standard Feedback Prompt

```
  Before I close out, two quick questions:

  1. Does this sound like you / your brand?
     (If not, what feels off? I'll adjust.)

  2. Which variant or headline direction resonates most?
     (I'll note this in your brand learnings for next time.)
```

## Recording Feedback

If the user provides feedback:

1. **Voice adjustments** -> Note in `workspace/brand/voice-profile.md` under a "Copy Feedback" section.
2. **Angle/variant preferences** -> Note in `workspace/brand/learnings.md`.
3. **Specific edits** -> Apply immediately and re-save the file.

---
---

# Appendix: Quick-Reference Checklists

## Pre-Generation Checklist

- [ ] Format established (landing page, email, ad, social, sales page, other)
- [ ] Brand memory loaded (or noted as absent)
- [ ] Audience awareness level identified (Schwartz 1-5)
- [ ] Core transformation identified (not features -- the "so what?" chain result)
- [ ] Proof inventory taken (testimonials, data, case studies available)
- [ ] Positioning angle clear (from brand memory or stated)

## Post-Generation Checklist

- [ ] Read it out loud -- does it sound human?
- [ ] Every claim has a specific number or proof point
- [ ] Rhythm alternates (short punchy + longer breathing room)
- [ ] Open loops are all closed
- [ ] CTA is benefit-oriented with friction reducers
- [ ] No AI tells (check the avoid list)
- [ ] Voice matches brand profile (if loaded)
- [ ] Headlines: minimum 5 variants generated
- [ ] Body: minimum 2 variants for landing/sales pages
- [ ] Files saved to correct campaign directory
- [ ] assets.md updated
